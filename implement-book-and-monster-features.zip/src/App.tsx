import { useCallback, useEffect, useRef, useState } from 'react';
import AdminPanel from './components/AdminPanel';
import GuideBook from './components/GuideBook';
import type { AdminSnapshot } from './game/admin';
import { createGame } from './game/game';
import type { GameHandle } from './game/game';
import { GUIDE } from './game/guide';

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const handleRef = useRef<GameHandle | null>(null);
  const [adminOpen, setAdminOpen] = useState(false);
  const [snap, setSnap] = useState<AdminSnapshot | null>(null);
  const [guideOpen, setGuideOpen] = useState(false);
  const [guidePage, setGuidePage] = useState(0);

  const refresh = useCallback(() => {
    const h = handleRef.current;
    if (h) setSnap(h.admin.getSnapshot());
  }, []);

  const closeAdmin = useCallback(() => {
    setAdminOpen(false);
    handleRef.current?.admin.setAdminOpen(false);
  }, []);

  const closeGuide = useCallback(() => {
    handleRef.current?.guide.close();
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const handle = createGame(canvas, {
      onAdminChange: (open) => {
        setAdminOpen(open);
        if (open) setSnap(handle.admin.getSnapshot());
      },
      onGuideChange: setGuideOpen,
      onGuidePage: (dir) => setGuidePage((p) => (p + dir + GUIDE.length) % GUIDE.length),
    });
    handleRef.current = handle;
    return () => {
      handle.destroy();
      handleRef.current = null;
    };
  }, []);

  useEffect(() => {
    if (!adminOpen) return;
    refresh();
    const id = window.setInterval(refresh, 200);
    const onKey = (e: KeyboardEvent) => {
      if (e.code === 'Escape') {
        e.preventDefault();
        closeAdmin();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => {
      window.clearInterval(id);
      window.removeEventListener('keydown', onKey);
    };
  }, [adminOpen, refresh, closeAdmin]);

  return (
    <main className="fixed inset-0 overflow-hidden bg-[#070616]">
      <h1 className="sr-only">Emberling — a pixel art game about keeping the dark at bay</h1>
      <canvas
        ref={canvasRef}
        role="img"
        aria-label="Emberling game screen. Move with WASD or arrow keys, hold the mouse button, use a gamepad stick, or drag on a touch screen. Space or the flame button flares. Shift or the dash button dashes."
        className="game-canvas absolute left-0 top-0 block"
      />
      {guideOpen && handleRef.current && (
        <GuideBook guide={handleRef.current.guide} page={guidePage} onPage={setGuidePage} onClose={closeGuide} />
      )}
      {adminOpen && handleRef.current && snap && (
        <AdminPanel admin={handleRef.current.admin} snap={snap} onRefresh={refresh} onClose={closeAdmin} />
      )}
    </main>
  );
}
