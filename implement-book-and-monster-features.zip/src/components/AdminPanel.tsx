import { useEffect, useState } from 'react';
import type { SyntheticEvent } from 'react';
import type { AdminBridge, AdminSnapshot, ForcedInput } from '../game/admin';
import { Frames, getFrames, PxIcon, PxText, u } from '../ui/pixel';
import type { IconName, Vars } from '../ui/pixel';
import {
  Btn,
  Chips,
  CYAN,
  DIM,
  GOLD,
  Grid,
  Info,
  measure,
  Meter,
  mult,
  MUTED,
  pct,
  ScrollBody,
  Section,
  Stat,
  Stepper,
  Toggle,
} from '../ui/widgets';

type Tab = 'player' | 'world' | 'mobs' | 'input' | 'system';

const TABS: { id: Tab; label: string; icon: IconName }[] = [
  { id: 'player', label: 'PLAYER', icon: 'flame' },
  { id: 'world', label: 'WORLD', icon: 'gate' },
  { id: 'mobs', label: 'MOBS', icon: 'octo' },
  { id: 'input', label: 'INPUT', icon: 'stick' },
  { id: 'system', label: 'SYSTEM', icon: 'gear' },
];

const STATE_NAME: Record<AdminSnapshot['state'], string> = {
  title: 'TITLE',
  play: 'PLAY',
  pause: 'PAUSE',
  settings: 'MENU',
  over: 'OVER',
  transition: 'WARP',
};

interface Props {
  admin: AdminBridge;
  snap: AdminSnapshot;
  onRefresh: () => void;
  onClose: () => void;
}

// ------------------------------------------------------------------ panel

export default function AdminPanel({ admin, snap, onRefresh, onClose }: Props) {
  const [tab, setTab] = useState<Tab>('mobs');
  const [peek, setPeekState] = useState(false);
  const [lay, setLay] = useState(measure);

  useEffect(() => {
    const on = () => setLay(measure());
    window.addEventListener('resize', on);
    return () => window.removeEventListener('resize', on);
  }, []);

  const frames = getFrames(lay.px);
  const root: Vars = {
    '--px': lay.px + 'px',
    '--s3': String(lay.px * 3),
    '--s4': String(lay.px * 4),
    '--dither': frames.dither,
  };
  const cols = lay.cols;

  /** Runs an admin action, then refreshes the readout straight away. */
  const act = (fn: () => void) => () => {
    fn();
    onRefresh();
  };
  const stop = (e: SyntheticEvent) => e.stopPropagation();
  const setPeek = (next: boolean) => {
    setPeekState(next);
    admin.setModalLock(!next);
    onRefresh();
  };

  if (peek) {
    const bar: Vars = { '--frame': frames.tone.stone.up, gap: u(3), padding: u(1), pointerEvents: 'auto' };
    return (
      <Frames.Provider value={frames}>
        <div
          className="pxui"
          style={{
            ...root,
            position: 'fixed',
            left: 0,
            right: 0,
            top: 'max(6px, env(safe-area-inset-top))',
            zIndex: 50,
            display: 'flex',
            justifyContent: 'center',
            pointerEvents: 'none',
          }}
        >
          <div className="px-box px-row" style={bar} onPointerDown={stop} onTouchStart={stop} onMouseDown={stop}>
            <PxIcon name="crown" box={9} />
            <PxText text={'D' + snap.depth} color={GOLD} />
            <PxText text={snap.fps + 'FPS'} color={CYAN} />
            <Btn icon="open" name="OPEN" square onClick={() => setPeek(false)} />
            <Btn icon="close" name="CLOSE" tone="red" square onClick={onClose} />
          </div>
        </div>
      </Frames.Provider>
    );
  }

  const big = lay.inner >= 154 && !lay.short;
  const holdBtn = (
    <Btn
      icon={snap.pauseOnAdmin ? 'pause' : 'play'}
      label={snap.pauseOnAdmin ? 'PAUSED' : 'LIVE'}
      tone={snap.pauseOnAdmin ? 'gold' : 'cyan'}
      onClick={act(() => admin.setPauseOnAdmin(!snap.pauseOnAdmin))}
    />
  );
  const strip: Vars = { '--frame': frames.well, flex: 1, alignSelf: 'stretch', gap: u(3), padding: `0 ${u(2)}`, overflow: 'hidden' };

  const player = (
    <>
      <Section icon="flame" title="FLAME" note={snap.dead ? 'OUT' : snap.grabbed ? 'HELD' : snap.wet ? 'WET' : undefined}>
        <div className="px-box px-row" style={{ '--frame': frames.well, padding: u(2), gap: u(3), overflow: 'hidden' } as Vars}>
          <Meter value={snap.fuel} />
          <PxText text={snap.fuel + '/100'} color={GOLD} />
        </div>
        <Grid cols={4}>
          <Btn label="FULL" name="FLAME FULL" tone="gold" center onClick={act(() => admin.setFuel(100))} />
          <Btn label="+10" name="FLAME +10" center onClick={act(() => admin.addFuel(10))} />
          <Btn label="-10" name="FLAME -10" center onClick={act(() => admin.addFuel(-10))} />
          <Btn label="LOW" name="FLAME LOW" tone="red" center onClick={act(() => admin.setFuel(15))} />
        </Grid>
      </Section>
      <Section icon="shield" title="POWERS">
        <Grid cols={cols}>
          <Toggle icon="shield" label="GOD MODE" sub="NO DRAIN, NO DAMAGE" tone="gold" on={snap.godMode} onClick={act(() => admin.toggleGodMode())} />
          <Toggle icon="glass" label="NO BURN" sub="FLAME STOPS BURNING DOWN" tone="gold" on={snap.noBurn} onClick={act(() => admin.toggleNoBurn())} />
          <Toggle icon="bolt" label="NO COOLDOWNS" sub="FREE FLARE AND DASH" tone="gold" on={snap.noCooldowns} onClick={act(() => admin.toggleNoCooldowns())} />
          <Toggle icon="ghost" label="NO CLIP" sub="WALK THROUGH WALLS" tone="gold" on={snap.noClip} onClick={act(() => admin.toggleNoClip())} />
        </Grid>
      </Section>
      <Section icon="tune" title="TUNING">
        <Grid cols={cols}>
          <Stepper
            icon="speed"
            label="WALK SPEED"
            value={mult(snap.speedMult)}
            canDec={snap.speedMult > 0.5}
            canInc={snap.speedMult < 2.5}
            onDec={act(() => admin.setSpeedMult(snap.speedMult - 0.25))}
            onInc={act(() => admin.setSpeedMult(snap.speedMult + 0.25))}
          />
          <Stepper
            icon="sun"
            label="LIGHT SIZE"
            value={mult(snap.lightMult)}
            canDec={snap.lightMult > 0.5}
            canInc={snap.lightMult < 3}
            onDec={act(() => admin.setLightMult(snap.lightMult - 0.25))}
            onInc={act(() => admin.setLightMult(snap.lightMult + 0.25))}
          />
        </Grid>
      </Section>
      <Section icon="star" title="ACTIONS">
        <Grid cols={cols * 2}>
          <Btn icon="ring" label="FREE FLARE" tone="gold" onClick={act(() => admin.flareNow())} />
          <Btn icon="ember" label="+50 EMBERS" tone="gold" onClick={act(() => admin.addEmbers(50))} />
          <Btn icon="octo" label="BREAK FREE" tone="pink" disabled={!snap.grabbed} onClick={act(() => admin.freeFromOcto())} />
          {snap.dead ? (
            <Btn icon="heart" label="REKINDLE" tone="cyan" onClick={act(() => admin.revive())} />
          ) : (
            <Btn icon="skull" label="SNUFF OUT" tone="red" onClick={act(() => admin.killPlayer())} />
          )}
        </Grid>
      </Section>
      <Section icon="target" title="TELEPORT">
        <Grid cols={cols * 2}>
          <Btn icon="brazier" label="TO BRAZIER" onClick={act(() => admin.teleport('brazier'))} />
          <Btn icon="gate" label="TO GATE" onClick={act(() => admin.teleport('gate'))} />
          <Btn icon="octo" label="TO OCTOPUS" onClick={act(() => admin.teleport('octopus'))} />
          <Btn icon="redo" label="TO START" onClick={act(() => admin.teleport('start'))} />
        </Grid>
      </Section>
    </>
  );

  const world = (
    <>
      <Section icon="stairs" title="DEPTH" note={'NOW ' + snap.depth}>
        <Grid cols={cols}>
          <Stepper
            icon="stairs"
            label="DEPTH"
            value={String(snap.depth)}
            canDec={snap.depth > 1}
            onDec={act(() => admin.setDepth(snap.depth - 1))}
            onInc={act(() => admin.setDepth(snap.depth + 1))}
          />
          <Chips
            icon="down"
            label="JUMP TO"
            options={[1, 2, 3, 5, 6, 10].map((d) => ({ label: 'D' + d, on: snap.depth === d, onClick: act(() => admin.setDepth(d)) }))}
          />
        </Grid>
        <Info lines={['D2 WATER - D3 MOTHS - D5 BOOK', 'D6-10 OCTOPUS, UP TO 5']} />
        <Grid cols={cols * 2}>
          <Btn icon="redo" label="NEW CAVE" tone="cyan" onClick={act(() => admin.regenLevel())} />
          <Btn icon="down" label="DESCEND" tone="gold" onClick={act(() => admin.descendNow())} />
        </Grid>
      </Section>
      <Section icon="brazier" title="BRAZIERS" note={snap.litBraziers + '/' + snap.totalBraziers + (snap.gateOpen ? ' GATE OPEN' : '')}>
        <Grid cols={cols * 2}>
          <Btn icon="brazier" label="LIGHT ALL" tone="gold" onClick={act(() => admin.lightAllBraziers())} />
          <Btn icon="cold" label="SNUFF ALL" onClick={act(() => admin.unlightBraziers())} />
        </Grid>
      </Section>
      <Section icon="eye" title="VISION">
        <Grid cols={cols}>
          <Toggle icon="sun" label="FULLBRIGHT" sub="NO DARKNESS AT ALL" on={snap.fullBright} onClick={act(() => admin.toggleFullBright())} />
          <Toggle icon="map" label="REVEAL MAP" sub="CLEAR THE CAVE FOG" on={snap.revealMap} onClick={act(() => admin.toggleRevealMap())} />
        </Grid>
      </Section>
      <Section icon="puddle" title="TERRAIN">
        <Grid cols={cols * 2}>
          <Btn icon="puddle" label="ADD PUDDLE" tone="cyan" onClick={act(() => admin.addPuddle())} />
          <Btn icon="ember" label="DROP EMBERS" tone="gold" onClick={act(() => admin.dropEmbers(6))} />
        </Grid>
      </Section>
      <Section icon="book" title="GUIDE BOOK" note={snap.hasBook ? 'IN THIS CAVE' : 'AT DEPTH 5'}>
        <Grid cols={cols * 2}>
          <Btn icon="book" label="READ IT NOW" tone="gold" onClick={act(() => admin.openGuide())} />
          <Btn icon="target" label="GO TO BOOK" disabled={!snap.hasBook} onClick={act(() => admin.teleport('book'))} />
        </Grid>
      </Section>
    </>
  );

  const mobs = (
    <>
      <Grid cols={4}>
        <Stat icon="shade" label="SHADES" value={snap.shades} color="#b08cff" />
        <Stat icon="moth" label="MOTHS" value={snap.moths} color="#e6d8b8" />
        <Stat icon="octo" label="OCTOS" value={snap.octos} color="#eb77a8" />
        <Stat icon="drop" label="WATER" value={snap.waterTiles} color="#6fb6e0" />
      </Grid>
      <Section icon="octo" title="OCTOPUS" note={snap.packed > 0 ? snap.packed + ' IN A PACK' : undefined}>
        <Grid cols={cols * 2}>
          <Btn icon="octo" label="+1 OCTOPUS" tone="pink" onClick={act(() => admin.spawnOcto())} />
          <Btn icon="pack" label="+3 OCTO PACK" tone="pink" onClick={act(() => admin.spawnOctoPack())} />
          <Btn icon="target" label="TEST GRAB" tone="pink" onClick={act(() => admin.triggerOctoGrab())} />
          <Btn icon="eye" label="MAKE PEEK" onClick={act(() => admin.peekOctos())} />
          <Btn icon="wave" label="MOVE ALL" onClick={act(() => admin.relocateOctos())} />
          <Btn icon="octo" label="BREAK FREE" disabled={!snap.grabbed} onClick={act(() => admin.freeFromOcto())} />
        </Grid>
        <Grid cols={cols}>
          <Chips
            icon="pack"
            label="PACK OF 3 ODDS"
            note="NEXT CAVE"
            tone="pink"
            options={[
              { label: 'AUTO', on: snap.trioChance < 0, onClick: act(() => admin.setTrioChance(-1)) },
              { label: '0%', on: snap.trioChance === 0, onClick: act(() => admin.setTrioChance(0)) },
              { label: '50%', on: snap.trioChance === 0.5, onClick: act(() => admin.setTrioChance(0.5)) },
              { label: '100%', on: snap.trioChance === 1, onClick: act(() => admin.setTrioChance(1)) },
            ]}
          />
          <Toggle icon="eye" label="SHOW OCTOPUS" sub="MARK EVERY HIDDEN ONE" tone="pink" on={snap.revealOctos} onClick={act(() => admin.toggleRevealOctos())} />
        </Grid>
      </Section>
      <Section icon="shade" title="SHADES + MOTHS" note={snap.oshades > 0 ? `${snap.oshades} O-SHADE${snap.oshades > 1 ? 'S' : ''} ABOUT` : undefined}>
        <Grid cols={cols * 2}>
          <Btn icon="shade" label="+1 SHADE" onClick={act(() => admin.spawnShade(1))} />
          <Btn icon="shade" label="+5 SHADES" onClick={act(() => admin.spawnShade(5))} />
          <Btn icon="oshade" label="+1 O-SHADE" tone="cyan" onClick={act(() => admin.spawnOshade(1))} />
          <Btn icon="oshade" label="+3 O-SHADES" tone="cyan" onClick={act(() => admin.spawnOshade(3))} />
          <Btn icon="soul" label="HYPER SOUL" tone="cyan" onClick={act(() => admin.spawnSoul())} />
          <Btn icon="bolt" label="OVERCHARGE ME" tone="cyan" onClick={act(() => admin.overchargeNow())} />
          <Btn icon="moth" label="+1 MOTH" onClick={act(() => admin.spawnMoth(1))} />
          <Btn icon="moth" label="+3 MOTHS" onClick={act(() => admin.spawnMoth(3))} />
          <Btn icon="flame" label="BURN SHADES" tone="gold" onClick={act(() => admin.igniteAllShades())} />
          <Btn icon="trash" label="CLEAR ALL" tone="red" onClick={act(() => admin.clearMonsters())} />
        </Grid>
        <Toggle icon="frost" label="FREEZE MOBS" sub="STOP ALL MONSTER AI" on={snap.freezeEnemies} onClick={act(() => admin.toggleFreezeEnemies())} />
      </Section>
    </>
  );

  const input = (
    <>
      <Section icon="stick" title="JOYSTICK">
        <Grid cols={cols}>
          <Toggle icon="stick" label="STATIC STICK" sub="FIXED IN PLACE, BIGGER" on={snap.staticJoy} onClick={act(() => admin.setStaticJoy(!snap.staticJoy))} />
          <Stepper
            icon="tune"
            label="STICK SIZE"
            value={mult(snap.joyScale)}
            canDec={snap.joyScale > 0.86}
            canInc={snap.joyScale < 1.34}
            onDec={act(() => admin.setJoyScale(snap.joyScale - 0.05))}
            onInc={act(() => admin.setJoyScale(snap.joyScale + 0.05))}
          />
          <Stepper
            icon="ring"
            label="DEAD ZONE"
            value={pct(snap.deadzone)}
            canDec={snap.deadzone > 0.06}
            canInc={snap.deadzone < 0.39}
            onDec={act(() => admin.setDeadzone(snap.deadzone - 0.05))}
            onInc={act(() => admin.setDeadzone(snap.deadzone + 0.05))}
          />
        </Grid>
      </Section>
      <Section icon="sound" title="FEEDBACK">
        <Grid cols={cols}>
          <Toggle icon="buzz" label="VIBRATION" sub="HAPTIC BUZZ ON HITS" on={snap.haptics} onClick={act(() => admin.setHaptics(!snap.haptics))} />
          <Toggle icon="sound" label="SOUND" sub="MUSIC AND EFFECTS" on={!snap.muted} onClick={act(() => admin.setMuted(!snap.muted))} />
        </Grid>
      </Section>
      <Section icon="keys" title="HUD">
        <Grid cols={cols}>
          <Chips
            icon="keys"
            label="BUTTON HINTS"
            tone="cyan"
            options={(['auto', 'touch', 'keys'] as ForcedInput[]).map((m) => ({
              label: m.toUpperCase(),
              on: snap.forcedInput === m,
              onClick: act(() => admin.setForcedInput(m)),
            }))}
          />
          <Toggle icon="crown" label="ADMIN BUTTON" sub="CROWN BUTTON IN PLAY" tone="gold" on={snap.showHudAdmin} onClick={act(() => admin.setShowHudAdmin(!snap.showHudAdmin))} />
        </Grid>
      </Section>
    </>
  );

  const system = (
    <>
      <Section icon="clock" title="TIME">
        <Grid cols={cols}>
          <Toggle icon="pause" label="PAUSE WHILE OPEN" sub="FREEZE GAME UNDER PANEL" tone="gold" on={snap.pauseOnAdmin} onClick={act(() => admin.setPauseOnAdmin(!snap.pauseOnAdmin))} />
          <Chips
            icon="clock"
            label="GAME SPEED"
            tone="cyan"
            options={[0.25, 0.5, 1, 2].map((v) => ({ label: v + 'X', on: snap.timeScale === v, onClick: act(() => admin.setTimeScale(v)) }))}
          />
        </Grid>
        <Grid cols={cols * 2}>
          <Btn icon="step" label="STEP 1 FRAME" disabled={!snap.pauseOnAdmin} onClick={act(() => admin.stepFrame(1))} />
          <Btn icon="step" label="STEP 10" disabled={!snap.pauseOnAdmin} onClick={act(() => admin.stepFrame(10))} />
        </Grid>
      </Section>
      <Section icon="bug" title="DEBUG">
        <Grid cols={cols}>
          <Toggle icon="bug" label="DEBUG HUD" sub="FPS AND COUNTS ON SCREEN" on={snap.debugHud} onClick={act(() => admin.toggleDebugHud())} />
          <Toggle icon="box" label="HITBOXES" sub="SHOW TOUCH RADIUS RINGS" on={snap.hitboxes} onClick={act(() => admin.toggleHitboxes())} />
          <Toggle icon="drop" label="POOL MASK" sub="WHERE AN OCTOPUS CAN SHOW" on={snap.poolMask} onClick={act(() => admin.togglePoolMask())} />
        </Grid>
      </Section>
      <Section icon="disk" title="DATA">
        <Info
          lines={[
            `POS ${snap.playerX},${snap.playerY}  TILE ${snap.tileX},${snap.tileY}`,
            `CAVE ${snap.levelW}X${snap.levelH}  SPARKS ${snap.particles}`,
            `BEST DEPTH ${snap.best}  EMBERS ${snap.embers}`,
          ]}
        />
        <Grid cols={cols * 2}>
          <Btn icon="redo" label="RESET CHEATS" tone="cyan" onClick={act(() => admin.resetCheats())} />
          <Btn icon="trash" label="RESET BEST" tone="red" onClick={act(() => admin.resetBest())} />
        </Grid>
      </Section>
    </>
  );

  const body = tab === 'player' ? player : tab === 'world' ? world : tab === 'mobs' ? mobs : tab === 'input' ? input : system;
  const edge = lay.px * 2 + 'px';

  return (
    <Frames.Provider value={frames}>
      <div
        className="pxui px-backdrop"
        style={{
          ...root,
          position: 'fixed',
          inset: 0,
          zIndex: 50,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          padding: `max(${edge}, env(safe-area-inset-top)) max(${edge}, env(safe-area-inset-right)) max(${edge}, env(safe-area-inset-bottom)) max(${edge}, env(safe-area-inset-left))`,
        }}
        onPointerDown={stop}
        onTouchStart={stop}
        onMouseDown={stop}
      >
        <section
          aria-label="Admin panels"
          className="px-panel px-col"
          style={{ '--frame': frames.panel, width: u(lay.inner + 14), maxHeight: '100%', padding: `${u(2)} ${u(3)}`, gap: u(2) } as Vars}
        >
          <header className="px-col" style={{ gap: u(2), flex: 'none' }}>
            <div className="px-row" style={{ gap: u(2) }}>
              <PxIcon name="crown" scale={big ? 2 : 1} />
              <span style={{ width: u(big ? 2 : 1), flex: 'none' }} />
              <PxText text="ADMIN PANELS" color={GOLD} scale={big ? 2 : 1} />
              <span style={{ flex: 1 }} />
              {lay.short && holdBtn}
              <Btn icon="peek" name="PEEK" square onClick={() => setPeek(true)} />
              <Btn icon="close" name="CLOSE" tone="red" square onClick={onClose} />
            </div>
            {!lay.short && (
              <div className="px-row" style={{ gap: u(2) }}>
                <div className="px-box px-row" style={strip}>
                  <PxIcon name={snap.pauseOnAdmin ? 'lampHold' : 'lampOn'} />
                  <PxText text={STATE_NAME[snap.state]} />
                  <span className="px-row" style={{ gap: u(1) }}>
                    <PxIcon name="stairs" box={9} />
                    <PxText text={String(snap.depth)} color={GOLD} />
                  </span>
                  <span className="px-row" style={{ gap: u(1) }}>
                    <PxIcon name="flame" box={9} />
                    <PxText text={String(snap.fuel)} color="#ff9a3c" />
                  </span>
                </div>
                {holdBtn}
              </div>
            )}
          </header>

          <nav className="px-grid" style={{ gridTemplateColumns: 'repeat(5, minmax(0, 1fr))', gap: u(1), flex: 'none' }}>
            {TABS.map((t) => {
              const on = tab === t.id;
              const style: Vars = { '--frame': on ? frames.tabOn : frames.tabOff, '--frame-down': frames.tabOn };
              return (
                <button key={t.id} type="button" className="px-box px-btn px-tab" style={style} aria-label={t.label} aria-pressed={on} onClick={() => setTab(t.id)}>
                  <PxIcon name={t.icon} box={9} />
                  <PxText text={t.label} color={on ? GOLD : MUTED} />
                </button>
              );
            })}
          </nav>

          <ScrollBody key={tab} px={lay.px}>
            {body}
          </ScrollBody>

          {!lay.short && (
            <footer className="px-row" style={{ justifyContent: 'space-between', gap: u(3), flex: 'none', overflow: 'hidden' }}>
              <PxText text={snap.fps + ' FPS'} color={CYAN} />
              <PxText text={lay.touch ? 'DRAG THE LIST TO SCROLL' : 'F2 TOGGLE - ESC CLOSE'} color={DIM} />
            </footer>
          )}
        </section>
      </div>
    </Frames.Provider>
  );
}
