import { useEffect, useMemo, useRef, useState } from 'react';
import type { MouseEvent, SyntheticEvent } from 'react';
import { GUIDE } from '../game/guide';
import type { CreatureId, GuideBridge } from '../game/guide';
import { Frames, getFrames, PxIcon, PxText, u } from '../ui/pixel';
import type { IconName, Vars } from '../ui/pixel';
import { Btn, CYAN, DIM, GOLD, measure, MUTED, ScrollBody, Section, useFrames } from '../ui/widgets';

const TAB: Record<CreatureId, { icon: IconName; label: string }> = {
  emberling: { icon: 'flame', label: 'YOU' },
  shade: { icon: 'shade', label: 'SHADE' },
  moth: { icon: 'moth', label: 'MOTH' },
  octopus: { icon: 'octo', label: 'OCTO' },
  oshade: { icon: 'oshade', label: 'O-SHADE' },
};

const RATING_COLOR: Record<string, string> = {
  DANGER: '#ff4d6d',
  SPEED: '#6fe3d2',
  STEALTH: '#b08cff',
  LIGHT: '#ffd15c',
  ARMOUR: '#9a9fb8',
};

const PAGE = '#e6d8b8';

interface Props {
  guide: GuideBridge;
  page: number;
  onPage: (page: number) => void;
  onClose: () => void;
}

/** A score out of five, as a row of pips. */
function Pips({ label, value }: { label: string; value: number }) {
  const color = RATING_COLOR[label] ?? GOLD;
  const cells = [];
  for (let i = 0; i < 5; i++) {
    const on = i < value;
    cells.push(
      <g key={i}>
        <rect x={i * 6} y={0} width={5} height={5} fill={on ? color : '#2b2648'} />
        {on && <rect x={i * 6} y={0} width={5} height={1} fill="#fff1c2" />}
      </g>,
    );
  }
  return (
    <div className="px-row" style={{ gap: u(3) }}>
      <span className="sr-only">{`${label}: ${value} out of 5`}</span>
      <span style={{ width: u(30), flex: 'none' }}>
        <PxText text={label} color={MUTED} />
      </span>
      <svg aria-hidden="true" viewBox="0 0 29 5" shapeRendering="crispEdges" style={{ width: u(29), height: u(5) }}>
        {cells}
      </svg>
    </div>
  );
}

/** Running text. Each word is its own image, so the paragraph wraps to whatever width it has. */
function Para({ text, color = PAGE }: { text: string; color?: string }) {
  return (
    <p className="px-para">
      <span className="sr-only">{text}</span>
      {text.split(' ').map((word, i) => (
        <PxText key={i} text={word} color={color} />
      ))}
    </p>
  );
}

function Facts({ rows }: { rows: [string, string][] }) {
  const f = useFrames();
  const style: Vars = { '--frame': f.well, padding: u(2), gap: u(3), margin: '0' };
  return (
    <dl className="px-box px-col" style={style}>
      {rows.map(([label, value]) => (
        <div key={label} className="px-row" style={{ gap: u(3) }}>
          <dt style={{ width: u(42), flex: 'none' }}>
            <span className="sr-only">{label}</span>
            <PxText text={label} color={MUTED} />
          </dt>
          <dd style={{ margin: 0, minWidth: 0, overflow: 'hidden' }}>
            <span className="sr-only">{value}</span>
            <PxText text={value} />
          </dd>
        </div>
      ))}
    </dl>
  );
}

export default function GuideBook({ guide, page, onPage, onClose }: Props) {
  const [lay, setLay] = useState(measure);
  const [tick, setTick] = useState(0);
  const shots = useMemo(() => guide.portraits(), [guide]);
  const count = GUIDE.length;
  const entry = GUIDE[page] ?? GUIDE[0];
  const frames = getFrames(lay.px);

  useEffect(() => {
    const on = () => setLay(measure());
    window.addEventListener('resize', on);
    return () => window.removeEventListener('resize', on);
  }, []);

  // the portraits move, unless the player has asked for less motion
  useEffect(() => {
    if (typeof window.matchMedia === 'function' && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const id = window.setInterval(() => setTick((t) => t + 1), 170);
    return () => window.clearInterval(id);
  }, []);

  // a page-turn sound whenever the page changes (opening the book already made one)
  const first = useRef(true);
  useEffect(() => {
    if (first.current) first.current = false;
    else guide.turn();
  }, [page, guide]);

  useEffect(() => {
    const on = (e: KeyboardEvent) => {
      if (e.metaKey || e.ctrlKey || e.altKey || e.repeat) return;
      const c = e.code;
      if (c === 'Escape') onClose();
      else if (c === 'ArrowRight' || c === 'KeyD') onPage((page + 1) % count);
      else if (c === 'ArrowLeft' || c === 'KeyA') onPage((page + count - 1) % count);
      else if ((c === 'Space' || c === 'Enter') && !(document.activeElement instanceof HTMLButtonElement)) onClose();
      else return;
      e.preventDefault();
    };
    window.addEventListener('keydown', on);
    return () => window.removeEventListener('keydown', on);
  }, [page, count, onPage, onClose]);

  const root: Vars = {
    '--px': lay.px + 'px',
    '--s3': String(lay.px * 3),
    '--s4': String(lay.px * 4),
    '--dither': frames.dither,
  };
  const stop = (e: SyntheticEvent) => e.stopPropagation();
  const outside = (e: MouseEvent) => {
    if (e.target === e.currentTarget) onClose();
  };

  const wide = lay.cols === 2;
  // Keep the entire O-SHADE label visible instead of squeezing five tabs into a phone width.
  const tabColumns = lay.inner >= 200 ? count : lay.inner >= 130 ? 3 : 2;
  const big = lay.inner >= 154 && !lay.short;
  // beside the stats on a wide page the portrait stays small; on a narrow page it gets the full width
  const zoom = wide ? 2 : lay.inner >= 150 ? 3 : 2;
  const pics = shots[entry.id];
  const edge = lay.px * 2 + 'px';

  const portrait = (
    <div className="px-box" style={{ '--frame': frames.well, padding: u(1), flex: 'none', alignSelf: 'center' } as Vars}>
      <img
        className="px-shot"
        src={pics[tick % pics.length]}
        alt={`The ${entry.name.toLowerCase()} as it looks in the caves`}
        draggable={false}
        style={{ width: u(44 * zoom), height: u(30 * zoom) }}
      />
    </div>
  );

  const title = (
    <h2 className="px-col" style={{ gap: u(2), margin: 0 }}>
      <span className="sr-only">{`${entry.name}, ${entry.epithet}`}</span>
       <PxText text={entry.name} color={entry.id === 'oshade' ? '#9fe4ff' : GOLD} scale={2} />
      <PxText text={entry.epithet} color={CYAN} />
    </h2>
  );

  const pips = (
    <div className="px-col" style={{ gap: u(3) }}>
      {entry.ratings.map((r) => (
        <Pips key={r.label} label={r.label} value={r.value} />
      ))}
    </div>
  );

  const stats = (
    <Section icon="tune" title="STATS">
      <Facts rows={entry.facts} />
    </Section>
  );

  const about = (
    <Section icon="eye" title="ABOUT">
      <Para text={entry.about} />
    </Section>
  );

  const tip = (
    <Section icon="shield" title={entry.id === 'emberling' ? 'HOW TO LAST' : 'HOW TO SURVIVE IT'}>
      <Para text={entry.tip} color="#fff1c2" />
    </Section>
  );

  return (
    <Frames.Provider value={frames}>
      <div
        className="pxui px-backdrop"
        style={{
          ...root,
          position: 'fixed',
          inset: 0,
          zIndex: 50,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          padding: `max(${edge}, env(safe-area-inset-top)) max(${edge}, env(safe-area-inset-right)) max(${edge}, env(safe-area-inset-bottom)) max(${edge}, env(safe-area-inset-left))`,
        }}
        onPointerDown={stop}
        onTouchStart={stop}
        onMouseDown={stop}
        onClick={outside}
      >
        <section
          role="dialog"
          aria-modal="true"
          aria-label="Guide book: the creatures of the caves"
          className="px-panel px-col"
          style={{ '--frame': frames.panel, width: u(lay.inner + 14), maxHeight: '100%', padding: `${u(2)} ${u(3)}`, gap: u(2) } as Vars}
        >
          <header className="px-row" style={{ gap: u(2), flex: 'none' }}>
            <PxIcon name="book" scale={big ? 2 : 1} />
            <span style={{ width: u(big ? 2 : 1), flex: 'none' }} />
            <h1 style={{ margin: 0 }}>
              <span className="sr-only">Guide book</span>
              <PxText text="GUIDE BOOK" color={GOLD} scale={big ? 2 : 1} />
            </h1>
            <span style={{ flex: 1 }} />
            {wide && !lay.touch && <PxText text="ARROWS TURN PAGES - ESC SHUTS" color={DIM} />}
            <Btn icon="close" name="CLOSE" tone="red" square onClick={onClose} />
          </header>

           <nav className="px-grid" style={{ gridTemplateColumns: `repeat(${tabColumns}, minmax(0, 1fr))`, gap: u(1), flex: 'none' }} aria-label="Creatures">
            {GUIDE.map((g, i) => {
              const on = i === page;
              const style: Vars = { '--frame': on ? frames.tabOn : frames.tabOff, '--frame-down': frames.tabOn };
              return (
                <button key={g.id} type="button" className="px-box px-btn px-tab" style={style} aria-label={g.name} aria-pressed={on} onClick={() => onPage(i)}>
                  <PxIcon name={TAB[g.id].icon} box={9} />
                  <PxText text={TAB[g.id].label} color={on ? GOLD : MUTED} />
                </button>
              );
            })}
          </nav>

          <ScrollBody key={entry.id} px={lay.px}>
            {wide ? (
              <>
                <div className="px-row" style={{ gap: u(4), alignItems: 'flex-start' }}>
                  <div className="px-col" style={{ gap: u(4), flex: 'none' }}>
                    {portrait}
                    {pips}
                  </div>
                  <div className="px-col" style={{ gap: u(4), flex: 1 }}>
                    {title}
                    {stats}
                  </div>
                </div>
                <div className="px-grid" style={{ gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: u(4) }}>
                  {about}
                  {tip}
                </div>
              </>
            ) : (
              <>
                {portrait}
                {title}
                {pips}
                {stats}
                {about}
                {tip}
              </>
            )}
          </ScrollBody>

          {!wide && (
            <footer className="px-row" style={{ gap: u(2), flex: 'none' }}>
              <Btn icon="left" label="BACK" name="PREVIOUS CREATURE" onClick={() => onPage((page + count - 1) % count)} />
              <span className="px-row" style={{ flex: 1, justifyContent: 'center', overflow: 'hidden' }}>
                <PxText text={`PAGE ${page + 1} OF ${count}`} color={DIM} />
              </span>
              <Btn icon="right" label="NEXT" name="NEXT CREATURE" onClick={() => onPage((page + 1) % count)} />
            </footer>
          )}
        </section>
      </div>
    </Frames.Provider>
  );
}
