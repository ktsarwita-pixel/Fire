// The contract between the game and the admin panels drawn over it.

export type ForcedInput = 'auto' | 'touch' | 'keys';
export type TeleportTarget = 'brazier' | 'gate' | 'octopus' | 'start' | 'book';

export interface AdminSnapshot {
  state: 'title' | 'play' | 'pause' | 'settings' | 'over' | 'transition';
  depth: number;
  fuel: number;
  embers: number;
  best: number;
  litBraziers: number;
  totalBraziers: number;
  gateOpen: boolean;
  shades: number;
  /** How many of those shades are overcharge shades. */
  oshades: number;
  /** Seconds of overcharge left on the emberling, 0 when it burns its usual gold. */
  overT: number;
  moths: number;
  octos: number;
  /** Octopuses currently sharing a puddle with packmates. */
  packed: number;
  waterTiles: number;
  grabbed: boolean;
  dead: boolean;
  wet: boolean;
  fps: number;
  particles: number;
  godMode: boolean;
  noCooldowns: boolean;
  noClip: boolean;
  noBurn: boolean;
  fullBright: boolean;
  revealMap: boolean;
  freezeEnemies: boolean;
  revealOctos: boolean;
  debugHud: boolean;
  hitboxes: boolean;
  poolMask: boolean;
  /** Whether this cave holds the guide book. */
  hasBook: boolean;
  speedMult: number;
  lightMult: number;
  timeScale: number;
  /** Chance that the next cave puts three octopuses in one puddle; -1 means the game's own odds. */
  trioChance: number;
  staticJoy: boolean;
  joyScale: number;
  deadzone: number;
  haptics: boolean;
  forcedInput: ForcedInput;
  muted: boolean;
  showHudAdmin: boolean;
  pauseOnAdmin: boolean;
  playerX: number;
  playerY: number;
  tileX: number;
  tileY: number;
  levelW: number;
  levelH: number;
}

export interface AdminBridge {
  getSnapshot(): AdminSnapshot;
  setAdminOpen(open: boolean): void;
  setModalLock(locked: boolean): void;

  // player
  setFuel(fuel: number): void;
  addFuel(delta: number): void;
  addEmbers(delta: number): void;
  flareNow(): void;
  killPlayer(): void;
  revive(): void;
  freeFromOcto(): void;
  teleport(where: TeleportTarget): void;
  toggleGodMode(): void;
  toggleNoCooldowns(): void;
  toggleNoClip(): void;
  toggleNoBurn(): void;
  setSpeedMult(v: number): void;
  setLightMult(v: number): void;

  // world
  setDepth(depth: number): void;
  regenLevel(): void;
  descendNow(): void;
  lightAllBraziers(): void;
  unlightBraziers(): void;
  toggleFullBright(): void;
  toggleRevealMap(): void;
  addPuddle(): void;
  dropEmbers(count: number): void;
  /** Shuts the panel and opens the guide book, wherever the emberling is. */
  openGuide(): void;

  // monsters
  spawnShade(count?: number): void;
  spawnOshade(count?: number): void;
  /** Drops a hyper soul beside the emberling. */
  spawnSoul(): void;
  /** Lights the blue fire right now, as if a soul had just been caught. */
  overchargeNow(): void;
  spawnMoth(count?: number): void;
  spawnOcto(): void;
  spawnOctoPack(): void;
  triggerOctoGrab(): void;
  relocateOctos(): void;
  peekOctos(): void;
  setTrioChance(v: number): void;
  clearMonsters(): void;
  igniteAllShades(): void;
  toggleFreezeEnemies(): void;
  toggleRevealOctos(): void;

  // input
  setStaticJoy(v: boolean): void;
  setJoyScale(v: number): void;
  setDeadzone(v: number): void;
  setHaptics(v: boolean): void;
  setForcedInput(mode: ForcedInput): void;
  setMuted(m: boolean): void;
  setShowHudAdmin(v: boolean): void;

  // system
  setPauseOnAdmin(v: boolean): void;
  setTimeScale(v: number): void;
  stepFrame(count: number): void;
  toggleDebugHud(): void;
  toggleHitboxes(): void;
  togglePoolMask(): void;
  resetCheats(): void;
  resetBest(): void;
}
