// Chiptune-style sound effects and a sparse ambient tune, all synthesised.

const SCALE = [220, 261.63, 293.66, 329.63, 392, 440, 523.25, 587.33, 659.25];
const MELODY = [
  5, -1, -1, 3, -1, -1, 4, -1, 5, -1, 6, -1, -1, 3, -1, -1,
  2, -1, -1, 3, -1, 5, -1, -1, 4, -1, -1, 2, -1, -1, -1, -1,
  5, -1, -1, 6, -1, 7, -1, -1, 6, -1, 5, -1, -1, 3, -1, -1,
  4, -1, 3, -1, 2, -1, -1, 0, -1, -1, -1, 2, -1, -1, -1, -1,
];
const BASS = [110, 87.31, 130.81, 98, 110, 87.31, 73.42, 98];
const STEP = 0.3;

export class Sfx {
  muted = false;
  private ac: AudioContext | null = null;
  private master: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  private timer: number | null = null;
  private step = 0;
  private nextT = 0;

  constructor() {
    try {
      this.muted = localStorage.getItem('emberling_mute') === '1';
    } catch {
      /* storage unavailable */
    }
  }

  /** Must be called from a user gesture. */
  init(): void {
    if (!this.ac) {
      const w = window as unknown as { AudioContext?: typeof AudioContext; webkitAudioContext?: typeof AudioContext };
      const AC = w.AudioContext ?? w.webkitAudioContext;
      if (!AC) return;
      try {
        this.ac = new AC();
      } catch {
        return;
      }
      this.master = this.ac.createGain();
      this.master.gain.value = this.muted ? 0 : 0.5;
      this.master.connect(this.ac.destination);
      const len = this.ac.sampleRate;
      this.noiseBuf = this.ac.createBuffer(1, len, len);
      const d = this.noiseBuf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    }
    if (this.ac.state === 'suspended') void this.ac.resume();
  }

  setMuted(m: boolean): void {
    this.muted = m;
    if (this.master && this.ac) this.master.gain.setTargetAtTime(m ? 0 : 0.5, this.ac.currentTime, 0.02);
    try {
      localStorage.setItem('emberling_mute', m ? '1' : '0');
    } catch {
      /* storage unavailable */
    }
  }

  private tone(freq: number, dur: number, type: OscillatorType, vol: number, slide = 0, delay = 0): void {
    const ac = this.ac;
    if (!ac || !this.master) return;
    const t = ac.currentTime + delay;
    const o = ac.createOscillator();
    const g = ac.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, slide), t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g);
    g.connect(this.master);
    o.start(t);
    o.stop(t + dur + 0.03);
  }

  private noise(dur: number, vol: number, freq: number, sweep = 0, delay = 0): void {
    const ac = this.ac;
    if (!ac || !this.master || !this.noiseBuf) return;
    const t = ac.currentTime + delay;
    const src = ac.createBufferSource();
    src.buffer = this.noiseBuf;
    const f = ac.createBiquadFilter();
    f.type = 'bandpass';
    f.frequency.setValueAtTime(freq, t);
    if (sweep) f.frequency.exponentialRampToValueAtTime(Math.max(40, sweep), t + dur);
    const g = ac.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f);
    f.connect(g);
    g.connect(this.master);
    src.start(t, Math.random() * 0.5);
    src.stop(t + dur + 0.03);
  }

  pickup(): void {
    this.tone(880, 0.07, 'square', 0.08);
    this.tone(1318, 0.12, 'square', 0.08, 0, 0.06);
  }
  light(): void {
    this.noise(0.5, 0.25, 500, 2400);
    [392, 523.25, 659.25, 783.99].forEach((f, i) => this.tone(f, 0.22, 'square', 0.08, 0, 0.08 + i * 0.08));
  }
  flare(): void {
    this.noise(0.4, 0.3, 1800, 200);
    this.tone(220, 0.3, 'sawtooth', 0.1, 55);
  }
  hurt(): void {
    this.tone(300, 0.28, 'sawtooth', 0.16, 60);
    this.noise(0.2, 0.2, 300);
  }
  burn(): void {
    this.noise(0.3, 0.18, 2600, 500);
    this.tone(180, 0.2, 'square', 0.05, 520);
  }
  steal(): void {
    this.tone(1200, 0.08, 'triangle', 0.12, 700);
    this.tone(700, 0.12, 'triangle', 0.1, 400, 0.07);
  }
  deny(): void {
    this.tone(140, 0.12, 'square', 0.08);
  }
  dash(): void {
    this.noise(0.16, 0.16, 900, 3200);
    this.tone(330, 0.12, 'triangle', 0.08, 660);
  }
  splash(): void {
    this.noise(0.22, 0.14, 700, 250);
  }
  spawn(): void {
    this.noise(0.25, 0.1, 400, 2000);
    this.tone(440, 0.1, 'square', 0.05, 880, 0.05);
  }
  page(): void {
    this.noise(0.14, 0.1, 3200, 1400);
    this.noise(0.08, 0.06, 1800, 2600, 0.07);
  }
  grab(): void {
    this.noise(0.28, 0.2, 520, 140);
    this.tone(180, 0.24, 'sawtooth', 0.13, 75);
    this.tone(130, 0.2, 'triangle', 0.12, 65, 0.06);
  }
  low(): void {
    this.tone(196, 0.1, 'triangle', 0.12, 150);
  }
  gate(): void {
    [329.63, 440, 523.25, 659.25, 880].forEach((f, i) => this.tone(f, 0.4, 'triangle', 0.14, 0, i * 0.1));
  }
  descend(): void {
    [659.25, 523.25, 440, 329.63, 220].forEach((f, i) => this.tone(f, 0.2, 'square', 0.07, 0, i * 0.09));
  }
  over(): void {
    this.noise(0.9, 0.2, 900, 80);
    [330, 262, 220, 165, 110].forEach((f, i) => this.tone(f, 0.45, 'triangle', 0.16, 0, 0.15 + i * 0.22));
  }

  startMusic(): void {
    if (this.timer !== null || !this.ac) return;
    this.nextT = this.ac.currentTime + 0.1;
    this.timer = window.setInterval(() => this.schedule(), 100);
  }

  stopMusic(): void {
    if (this.timer !== null) {
      window.clearInterval(this.timer);
      this.timer = null;
    }
  }

  private schedule(): void {
    const ac = this.ac;
    if (!ac) return;
    if (this.nextT < ac.currentTime) this.nextT = ac.currentTime + 0.05;
    while (this.nextT < ac.currentTime + 0.35) {
      const delay = this.nextT - ac.currentTime;
      const n = MELODY[this.step % MELODY.length];
      if (n >= 0) this.tone(SCALE[n], 1.1, 'triangle', 0.05, 0, delay);
      if (this.step % 8 === 0) {
        const b = BASS[((this.step / 8) | 0) % BASS.length];
        this.tone(b, 2.3, 'sine', 0.09, 0, delay);
        this.tone(b * 2, 1.6, 'triangle', 0.025, 0, delay);
      }
      this.step++;
      this.nextT += STEP;
    }
  }

  dispose(): void {
    this.stopMusic();
    if (this.ac) void this.ac.close().catch(() => undefined);
    this.ac = null;
    this.master = null;
  }
}
