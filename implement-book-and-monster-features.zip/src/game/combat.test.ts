import { strict as assert } from 'node:assert';
import { test } from 'node:test';
import { absorbDamage, burnOrange, flareImpact } from './combat';
import { glyphBits } from './font';
import { GUIDE } from './guide';
import { SOUL_BARS } from './rules';

const shade = (oc: boolean) => ({ oc, hits: 0, state: 'hunt' as const });
const flare = (overcharged: boolean) => ({ overcharged, hitShades: new WeakSet<ReturnType<typeof shade>>() });

test('one normal flare can only stagger the same O-shade once', () => {
  const target = shade(true);
  const first = flare(false);
  assert.equal(flareImpact(first, target), 'stun');
  for (let frame = 0; frame < 35; frame++) assert.equal(flareImpact(first, target), null);
  assert.equal(target.hits, 1);
  assert.equal(flareImpact(flare(false), target), 'burn');
  assert.equal(target.hits, 2);
});

test('an overcharged flare burns an O-shade in one hit', () => {
  const target = shade(true);
  assert.equal(flareImpact(flare(true), target), 'burn');
  assert.equal(target.hits, 0);
});

test('ordinary shades still burn to either kind of flare', () => {
  assert.equal(flareImpact(flare(false), shade(false)), 'burn');
  assert.equal(flareImpact(flare(true), shade(false)), 'burn');
});

test('blue bars absorb hits before orange fuel, with damage overflow', () => {
  const first = absorbDamage(60, SOUL_BARS * 10, 16);
  assert.deepEqual(first, { fuel: 60, shield: 14 });
  assert.deepEqual(absorbDamage(first.fuel, first.shield, 20), { fuel: 54, shield: 0 });
});

test('blue health keeps the emberling alive when orange fuel runs out', () => {
  const burntOrange = 0;
  const hit = absorbDamage(burntOrange, 30, 16);
  assert.deepEqual(hit, { fuel: 0, shield: 14 });
  assert.deepEqual(absorbDamage(hit.fuel, hit.shield, 14), { fuel: 0, shield: 0 });
});

test('time and water burn down orange fuel without draining blue health', () => {
  let orange = 80;
  const blueHealth = SOUL_BARS * 10;
  for (let i = 0; i < 40; i++) orange = burnOrange(orange, 3.5);
  assert.equal(orange, 0);
  assert.equal(blueHealth, 30);
  assert.equal(burnOrange(orange, 10), 0);
});

test('the guide clearly names the O-shade, not an I-shade', () => {
  const entry = GUIDE.find((page) => page.id === 'oshade');
  assert.equal(entry?.name, 'O-SHADE');
  assert.notEqual(glyphBits('O'), glyphBits('I'));
  assert.ok(entry?.facts.some(([label, value]) => label === 'FLARES' && value.includes('1 BLUE')));
});