import { OSHADE_FLARES } from './rules';

/** Only distinct flare casts can build up hits on an O-shade. */
export interface FlareTarget {
  oc: boolean;
  hits: number;
  state: 'idle' | 'hunt' | 'burn' | 'gone';
}

export function flareImpact<T extends FlareTarget>(
  flare: { overcharged: boolean; hitShades: WeakSet<T> },
  shade: T,
): 'burn' | 'stun' | null {
  if ((shade.state !== 'idle' && shade.state !== 'hunt') || flare.hitShades.has(shade)) return null;
  flare.hitShades.add(shade);
  if (!shade.oc || flare.overcharged) return 'burn';
  shade.hits++;
  return shade.hits >= OSHADE_FLARES ? 'burn' : 'stun';
}

/** Blue health absorbs direct hits; ordinary fuel alone pays movement and time costs. */
export function absorbDamage(fuel: number, shield: number, damage: number): { fuel: number; shield: number } {
  const blocked = Math.min(Math.max(0, shield), Math.max(0, damage));
  return { fuel: fuel - Math.max(0, damage - blocked), shield: shield - blocked };
}

/** Passive cave/water burn can only consume the orange flame, not blue health. */
export function burnOrange(fuel: number, amount: number): number {
  return Math.max(0, fuel - Math.max(0, amount));
}