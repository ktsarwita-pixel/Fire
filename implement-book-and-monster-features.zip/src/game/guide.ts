// What the guide book says. Every number is read from rules.ts, the same place the game
// reads it from, so an entry cannot disagree with how its creature really behaves.

import {
  DASH_COST,
  FLARE_COST,
  flameBurn,
  MOTH_DEPTH,
  MOTH_FLEE_T,
  MOTH_STEAL,
  mothCount,
  OCTO_DEPTH_MAX,
  OCTO_DEPTH_MIN,
  OCTO_DRAIN,
  OCTO_HOLD_T,
  OCTO_MAX,
  OCTO_PACK_CHANCE,
  octoCount,
  OSHADE_BITE,
  OSHADE_BRAZIER_T,
  OSHADE_DEPTH,
  OSHADE_EMBER,
  OSHADE_FLARES,
  OSHADE_SOUL_CHANCE,
  OSHADE_SPEED,
  oshadeCount,
  PLAYER_SPEED,
  SHADE_BITE,
  SHADE_EMBER,
  SHADE_SPEED_LIT,
  shadeCount,
  shadeSpeed,
  SOUL_FUEL,
  SOUL_SPEED,
  SOUL_T,
  WATER_BURN,
  WATER_SPEED,
} from './rules';

export type CreatureId = 'emberling' | 'shade' | 'moth' | 'octopus' | 'oshade';

export interface GuideEntry {
  id: CreatureId;
  name: string;
  epithet: string;
  /** Three scores out of five. */
  ratings: { label: string; value: number }[];
  /** Label and value pairs, shown as a table. */
  facts: [string, string][];
  about: string;
  /** How to deal with it. */
  tip: string;
}

/** What the game hands the guide book's pages. */
export interface GuideBridge {
  /** Frames of each creature's portrait, as image addresses. */
  portraits(): Record<CreatureId, string[]>;
  close(): void;
  /** The sound of a page turning. */
  turn(): void;
}

const DEEP = 99;

export const GUIDE: GuideEntry[] = [
  {
    id: 'emberling',
    name: 'EMBERLING',
    epithet: 'THAT IS YOU',
    ratings: [
      { label: 'LIGHT', value: 5 },
      { label: 'SPEED', value: 4 },
      { label: 'ARMOUR', value: 1 },
    ],
    facts: [
      ['FLAME', '100 AT MOST'],
      ['BURNS DOWN', `${flameBurn(1).toFixed(1)} TO ${flameBurn(DEEP).toFixed(1)} A SECOND`],
      ['IN WATER', `${WATER_BURN} TIMES FASTER`],
      ['SPEED', `${PLAYER_SPEED} (${WATER_SPEED} WADING)`],
      ['FLARE', `COSTS ${FLARE_COST} FLAME`],
      ['DASH', `COSTS ${DASH_COST} FLAME`],
      ['BLUE BARS', 'TAKE HITS, NEVER BURN'],
    ],
    about:
      'A LIVING SPARK. YOUR FLAME IS YOUR LIFE, YOUR LIGHT AND YOUR CLOCK ALL AT ONCE. IT BURNS DOWN EVERY SECOND, AND AS IT SHRINKS THE DARK CLOSES IN.',
    tip: 'GATHER EMBERS AND LIGHT EVERY BRAZIER. INSIDE THE GLOW OF A LIT BRAZIER YOUR FLAME STOPS BURNING DOWN AND MENDS ITSELF TO HALF.',
  },
  {
    id: 'shade',
    name: 'SHADE',
    epithet: 'HUNTER IN THE DARK',
    ratings: [
      { label: 'DANGER', value: 3 },
      { label: 'SPEED', value: 3 },
      { label: 'STEALTH', value: 2 },
    ],
    facts: [
      ['FOUND', 'EVERY DEPTH'],
      ['NUMBERS', `${shadeCount(1)} TO ${shadeCount(DEEP)} A CAVE`],
      ['BITE', `-${SHADE_BITE} FLAME`],
      ['SPEED', `${Math.round(shadeSpeed(1))} TO ${shadeSpeed(DEEP)} (YOU ${PLAYER_SPEED})`],
      ['IN LIGHT', `SLOWS TO ${SHADE_SPEED_LIT}`],
      ['LEAVES', `EMBER +${SHADE_EMBER}`],
    ],
    about:
      'A HOODED WRAITH THAT SENSES YOUR FLAME FROM FAR OFF AND FOLLOWS THE TUNNELS TO REACH YOU. IN THE DARK YOU SEE ONLY ITS RED EYES. AFTER ONE BITE IT MELTS AWAY AND RISES AGAIN SOMEWHERE ELSE.',
    tip: 'YOUR OWN LIGHT SLOWS IT TO A CRAWL, SO KEEP YOUR FLAME BIG. A FLARE BURNS IT TO AN EMBER, AND SO DOES THE GLOW OF A LIT BRAZIER.',
  },
  {
    id: 'moth',
    name: 'MOTH',
    epithet: 'THIEF OF LIGHT',
    ratings: [
      { label: 'DANGER', value: 2 },
      { label: 'SPEED', value: 3 },
      { label: 'STEALTH', value: 1 },
    ],
    facts: [
      ['FOUND', `DEPTH ${MOTH_DEPTH} AND BELOW`],
      ['NUMBERS', `${mothCount(MOTH_DEPTH)} TO ${mothCount(DEEP)} A CAVE`],
      ['STEALS', `-${MOTH_STEAL} FLAME`],
      ['THEN', `FLEES ${MOTH_FLEE_T} SECONDS`],
      ['FLIES', 'OVER WALLS AND WATER'],
      ['LEAVES', 'EMBER +6 (+12 FULL)'],
    ],
    about:
      'A PALE MOTH DRAWN TO ANY FLAME. IT DRIFTS UNTIL YOUR LIGHT TOUCHES IT, THEN DARTS IN, SNATCHES A MOUTHFUL OF FIRE AND FLUTTERS OFF WITH IT GLOWING IN ITS GRIP.',
    tip: 'MOTHS LOVE A LIT BRAZIER MORE THAN THEY LOVE YOU. THEY CIRCLE IT AND LEAVE YOU ALONE. A FLARE BURNS THEM, AND ONE CARRYING YOUR FIRE DROPS A BIGGER EMBER.',
  },
  {
    id: 'octopus',
    name: 'WATER OCTOPUS',
    epithet: 'AMBUSH IN THE POOL',
    ratings: [
      { label: 'DANGER', value: 5 },
      { label: 'SPEED', value: 0 },
      { label: 'STEALTH', value: 5 },
    ],
    facts: [
      ['FOUND', `DEPTH ${OCTO_DEPTH_MIN} TO ${OCTO_DEPTH_MAX}`],
      ['NUMBERS', `${octoCount(OCTO_DEPTH_MIN)} TO ${OCTO_MAX} A CAVE`],
      ['HOLDS', `${OCTO_HOLD_T} SECONDS`],
      ['DRAINS', `-${OCTO_DRAIN} EACH SECOND`],
      ['PACK OF 3', `${Math.round(OCTO_PACK_CHANCE * 100)}% OF CAVES`],
      ['FLARE', 'DOES NOTHING'],
    ],
    about:
      'IT LIES UNDER THE WATER, THE COLOUR OF THE POOL, AND NEVER LEAVES IT. WATCH FOR A DARK SHAPE, SLOW RIPPLES, BUBBLES, OR A CROWN AND TWO EYES PEEKING OUT. STEP ON IT AND ITS ARMS PIN YOU WHILE IT SQUEEZES YOUR FLAME. THEN IT SWIMS TO ANOTHER POOL.',
    tip: 'WALK ROUND WATER WHEN YOU CAN. IF YOU MUST CROSS, DASH. A DASH SLIPS OVER IT UNHARMED. WHERE THREE SHARE ONE POOL, THE OTHERS STAY HIDDEN WHILE ONE HOLDS YOU.',
  },
  {
    id: 'oshade',
    name: 'O-SHADE',
    epithet: 'THE OVERCHARGE SHADE',
    ratings: [
      { label: 'DANGER', value: 5 },
      { label: 'SPEED', value: 5 },
      { label: 'STEALTH', value: 2 },
    ],
    facts: [
      ['FOUND', `DEPTH ${OSHADE_DEPTH} AND BELOW`],
      ['NUMBERS', `${oshadeCount(OSHADE_DEPTH)} AT FIRST, UP TO ${oshadeCount(DEEP)}`],
      ['BITE', `-${OSHADE_BITE} FLAME`],
      ['SPEED', `${OSHADE_SPEED}, EVEN IN YOUR LIGHT`],
      ['FLARES', `${OSHADE_FLARES} NORMAL, 1 BLUE`],
      ['BRAZIER', `KILLS IT IN ${OSHADE_BRAZIER_T} SECONDS`],
      ['SOUL', `${Math.round(OSHADE_SOUL_CHANCE * 100)}% A HYPER SOUL`],
      ['ELSE', `EMBER +${OSHADE_EMBER}`],
    ],
    about:
      'A SHADE DRUNK ON STOLEN FIRE, SWOLLEN BLUE AND VIOLET, ITS EYES BURNING YELLOW. YOUR LIGHT DOES NOT SLOW IT. A NORMAL FLARE ONLY SINGES IT; BLUE FIRE ENDS IT IN ONE BLAST. A BRAZIER NEEDS THREE FULL SECONDS TO TAKE IT.',
    tip: `LEAD IT INTO BRAZIER LIGHT AND KEEP IT THERE, USE TWO NORMAL FLARES, OR STRIKE ONCE WITH AN OVERCHARGED FLARE. ITS HYPER SOUL GRANTS +${SOUL_FUEL} FLAME AND THREE BLUE BARS: THEY ABSORB HITS, NEVER BURN DOWN. THE POWER LASTS ${SOUL_T} SECONDS AT SPEED ${SOUL_SPEED}, OR UNTIL THE BARS BREAK.`,
  },
];
