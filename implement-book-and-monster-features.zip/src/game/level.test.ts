import { strict as assert } from 'node:assert';
import { test } from 'node:test';
import { carveWaterPuddle, generateLevel, TILE, T_FLOOR, T_WALL } from './level';
import type { Level } from './level';
import { oshadeCount } from './rules';

const ctx = { fillRect() {} } as unknown as CanvasRenderingContext2D;
(globalThis as unknown as { document: unknown }).document = {
  createElement: () => ({ width: 0, height: 0, getContext: () => ctx }),
};

function reachable(level: Level, tx: number, ty: number): boolean {
  const start = level.start.y * level.w + level.start.x;
  const target = ty * level.w + tx;
  const visited = new Uint8Array(level.w * level.h);
  const queue = [start];
  visited[start] = 1;
  for (let i = 0; i < queue.length; i++) {
    const cell = queue[i];
    if (cell === target) return true;
    const x = cell % level.w;
    const y = Math.floor(cell / level.w);
    for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const nx = x + dx;
      const ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= level.w || ny >= level.h) continue;
      const n = ny * level.w + nx;
      if (!visited[n] && level.tiles[n] !== T_WALL) {
        visited[n] = 1;
        queue.push(n);
      }
    }
  }
  return false;
}

test('random reading rooms remain complete, dry, decorated and reachable', () => {
  for (let seed = 1; seed <= 30; seed++) {
    const level = generateLevel(5, seed * 7919);
    const book = level.book;
    assert.ok(book, `seed ${seed}: missing book`);
    assert.ok(reachable(level, book.x, book.y), `seed ${seed}: cannot reach book`);
    assert.ok(reachable(level, level.exit.x, level.exit.y), `seed ${seed}: cannot reach exit`);
    assert.equal(level.bookRoom.size, 41, `seed ${seed}: incomplete chamber`);
    assert.equal(level.bookLamps.length, 4, `seed ${seed}: missing lanterns`);
    for (const cell of level.bookRoom) assert.equal(level.tiles[cell], T_FLOOR, `seed ${seed}: wet room`);
    for (const lamp of level.bookLamps) {
      const cell = Math.floor(lamp.y / TILE) * level.w + Math.floor(lamp.x / TILE);
      assert.equal(level.tiles[cell], T_FLOOR, `seed ${seed}: lantern in wall`);
    }
    assert.equal(carveWaterPuddle(level, book.x, book.y), null, `seed ${seed}: admin drowned book room`);
  }
});

test('O-shades appear only at depth 10 and rise from 4 to a cap of 20', () => {
  for (const depth of [9, 10, 11, 12, 20, 26, 35]) {
    for (let seed = 1; seed <= 5; seed++) {
      const level = generateLevel(depth, seed * 3571 + depth);
      assert.equal(level.oshades.length, oshadeCount(depth));
      const cells = level.oshades.map((o) => o.y * level.w + o.x);
      assert.equal(new Set(cells).size, cells.length, `depth ${depth}: duplicate spawn`);
      assert.ok(reachable(level, level.exit.x, level.exit.y), `depth ${depth}: exit unreachable`);
    }
  }
  assert.equal(oshadeCount(10), 4);
  assert.equal(oshadeCount(11), 5);
  assert.equal(oshadeCount(26), 20);
});