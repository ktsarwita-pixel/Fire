// All pixel art is authored here as character grids and baked to canvases.

export const PAL: Record<string, string> = {
  k: '#0b0a16',
  w: '#fff1c2',
  y: '#ffd15c',
  o: '#ff9a3c',
  r: '#e8552d',
  m: '#9c2a3a',
  g: '#6b6f8a',
  G: '#4a4d68',
  h: '#9a9fb8',
  H: '#c9cde0',
  p: '#7b5cd6',
  P: '#4b3a8f',
  c: '#6fe3d2',
  C: '#2f8f9a',
  e: '#ff4d6d',
  u: '#6a55b5',
  U: '#3d2f78',
  d: '#17122e',
  n: '#e6d8b8',
  N: '#a8916f',
  B: '#5a3a2c',
  b: '#8a5a3c',
  x: '#2b2648',
  q: '#3a3560',
  a: '#6fb6e0',
  v: '#b8437f',
  V: '#45143b',
  l: '#eb77a8',
  L: '#ffd1e3',
  s: '#83255b',
  M: '#6a1b4a',
  D: '#132744',
  A: '#234b76',
  S: '#183559',
  W: '#2e6396',
  T: '#457eb5',
  // blue fire ramp, for an overcharged emberling and the hyper soul
  F: '#f2feff',
  I: '#9fe4ff',
  R: '#4fa8ff',
  Q: '#5a63f2',
  Z: '#2e3aa8',
};

export type Sprite = HTMLCanvasElement;

export interface Px {
  x: number;
  y: number;
}

function blank(w: number, h: number): [Sprite, CanvasRenderingContext2D] {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  return [c, c.getContext('2d') as CanvasRenderingContext2D];
}

function make(rows: string[], swap?: Record<string, string>): Sprite {
  const w = rows.reduce((m, r) => Math.max(m, r.length), 0);
  const [c, g] = blank(w, rows.length);
  rows.forEach((row, y) => {
    for (let x = 0; x < row.length; x++) {
      let ch = row[x];
      if (ch === '.') continue;
      if (swap && swap[ch]) ch = swap[ch];
      const col = PAL[ch];
      if (!col) continue;
      g.fillStyle = col;
      g.fillRect(x, y, 1, 1);
    }
  });
  return c;
}

/** Finds every cell drawn with a given character. */
function scan(rows: string[], ch: string): Px[] {
  const out: Px[] = [];
  rows.forEach((row, y) => {
    for (let x = 0; x < row.length; x++) if (row[x] === ch) out.push({ x, y });
  });
  return out;
}

/** A flat single-colour silhouette of a sprite. */
function tint(src: Sprite, color: string): Sprite {
  const [c, g] = blank(src.width, src.height);
  g.drawImage(src, 0, 0);
  g.globalCompositeOperation = 'source-in';
  g.fillStyle = color;
  g.fillRect(0, 0, c.width, c.height);
  return c;
}

/** Pixel-exact quarter turn, clockwise. */
function rot90(src: Sprite): Sprite {
  const w = src.width;
  const h = src.height;
  const sd = (src.getContext('2d') as CanvasRenderingContext2D).getImageData(0, 0, w, h);
  const [c, g] = blank(h, w);
  const dd = g.createImageData(h, w);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const si = (y * w + x) * 4;
      const di = (x * h + (h - 1 - y)) * 4;
      for (let k = 0; k < 4; k++) dd.data[di + k] = sd.data[si + k];
    }
  }
  g.putImageData(dd, 0, 0);
  return c;
}

function disc(r: number, fill: string, stroke: string, hi?: string): Sprite {
  const [c, g] = blank(r * 2 + 1, r * 2 + 1);
  for (let y = -r; y <= r; y++) {
    for (let x = -r; x <= r; x++) {
      const d = Math.sqrt(x * x + y * y);
      if (d > r + 0.35) continue;
      let col = fill;
      if (d > r - 0.75) col = stroke;
      else if (hi && d > r - 2.7 && d <= r - 1.6 && x < -r * 0.2 && y < -r * 0.2) col = hi;
      g.fillStyle = col;
      g.fillRect(x + r, y + r, 1, 1);
    }
  }
  return c;
}

function ring(r: number, fill: string, stroke: string): Sprite {
  const c = disc(r, fill, stroke);
  const g = c.getContext('2d') as CanvasRenderingContext2D;
  g.fillStyle = stroke;
  g.fillRect(r, 3, 1, 2);
  g.fillRect(r, r * 2 - 4, 1, 2);
  g.fillRect(3, r, 2, 1);
  g.fillRect(r * 2 - 4, r, 2, 1);
  return c;
}

function ellipse(w: number, h: number, color: string): Sprite {
  const [c, g] = blank(w, h);
  g.fillStyle = color;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const nx = (x + 0.5 - w / 2) / (w / 2);
      const ny = (y + 0.5 - h / 2) / (h / 2);
      if (nx * nx + ny * ny <= 1) g.fillRect(x, y, 1, 1);
    }
  }
  return c;
}

// --------------------------------------------------------------- emberling
// Three sizes (the flame shrinks as fuel burns down), three flicker frames each.

const BIG_BODY = [
  '..oyyyo...',
  '..oyyyyo..',
  '.oyyyyyyo.',
  '.oyywwyyo.',
  'oyywwwwyyo',
  'oywwwwwwyo',
  'oywwwwwwyo',
  'ryywwwwyyr',
  '.royyyyor.',
  '..rrrrrr..',
];
const BIG_TIPS = [
  ['....o.....', '....oo....', '...oyo....', '...oyyo...'],
  ['..........', '.....o....', '....oo....', '...oyyo...'],
  ['.....o....', '..........', '....oo....', '...oyo....'],
];

const MID_BODY = ['.oyyyyo.', '.oywwyo.', 'oywwwwyo', 'oywwwwyo', 'ryywwyyr', '.royyor.', '..rrrr..'];
const MID_TIPS = [
  ['...o....', '...oo...', '..oyo...', '..oyyo..'],
  ['........', '....o...', '...oo...', '..oyyo..'],
  ['....o...', '........', '...oo...', '..oyo...'],
];

const SMALL_BODY = ['.oyyo.', 'oywwyo', 'owwwwo', 'oywwyo', '.rrrr.'];
const SMALL_TIPS = [
  ['..o...', '..oo..'],
  ['......', '...o..'],
  ['...o..', '......'],
];

const DIM = { w: 'y', y: 'o', o: 'r', r: 'm' };
const TRAIL = ['#ffd15c', '#ff9a3c', '#e8552d', '#9c2a3a'];
/** Overcharged: the same flame burning blue. */
const DIM_OC = { w: 'I', y: 'R', o: 'Q', r: 'Z', m: 'Z' };
const OC = { w: 'F', y: 'I', o: 'R', r: 'Q' };
const TRAIL_OC = ['#9fe4ff', '#4fa8ff', '#5a63f2', '#2e3aa8'];

export interface PlayerTier {
  frames: Sprite[];
  /** Sputtering, cooler palette. */
  dim: Sprite[];
  /** Flat red flash shown when bitten. */
  hurt: Sprite;
  /** Dash afterimages, hot to cold. */
  sil: Sprite[];
  eyeY: number;
  eyeL: number;
  eyeR: number;
}

function tier(
  tips: string[][],
  body: string[],
  eyeY: number,
  eyeL: number,
  eyeR: number,
  base?: Record<string, string>,
  dim: Record<string, string> = DIM,
  trail: string[] = TRAIL,
): PlayerTier {
  const rows = tips.map((t) => [...t, ...body]);
  const frames = rows.map((r) => make(r, base));
  return {
    frames,
    dim: rows.map((r) => make(r, dim)),
    hurt: tint(frames[0], '#ff4d6d'),
    sil: trail.map((c) => tint(frames[0], c)),
    eyeY,
    eyeL,
    eyeR,
  };
}

// ------------------------------------------------------------------- shade
// A hooded wraith. The hood is shared; the tattered hem has four frames.

const SHADE_HOOD = [
  '.....uuuu.....',
  '...uuUUUUuu...',
  '..uUUddddUUu..',
  '.uUddddddddUu.',
  '.uUddddddddUu.',
  'uUddddddddddUu',
  'uUddddddddddUu',
  'uUddddddddddUu',
  'uUddddddddddUu',
  'uUddddddddddUu',
  'uUddddddddddUu',
];
const SHADE_HEMS = [
  ['.uUdUudddUudUu', '.uUu.uUdUu.uUu', '..u...uUu...u.', '.......u......'],
  ['uUdUudddUuddUu', 'uUu.uUdUu.uUUu', '.u...uUu...uu.', '......u.....u.'],
  ['.uUddUuddUudUu', '.uUdUu.uUu.uUu', '..uUu...u...u.', '...u..........'],
  ['uUddUudddUuUu.', 'uUUu.uUdUu.u..', '.uu...uUu.....', '.u.....u......'],
];

// -------------------------------------------------------- overcharge shade
// The same wraith, swollen on stolen fire: a peaked storm-hood rimmed in bright blue that
// cools to violet toward the hem, hollow black eye sockets (the yellow eyes themselves are
// drawn by the game so they can track you), and shoulders that flare wider than any common
// shade. Four hem frames billow; a separate set of arc frames crackles over the top.
// a = pale blue rim, R = bright blue, p = violet, P = deep violet, U = dusk violet,
// d = the dark within, k = the sockets.

const OSHADE_HOOD = [
  '.......aR.......',
  '......aRRa......',
  '.....aRppRa.....',
  '....aRPddPRa....',
  '...aRPddddPRa...',
  '..aRPddddddPRa..',
  '..aPdkkddkkdPa..',
  '.aRPdkkddkkdPRa.',
  '.aPddddddddddPa.',
  'aRPddddddddddPRa',
  'aPpUddddddddUpPa',
  'aPpUUddddddUUpPa',
];
const OSHADE_HEMS = [
  ['.aPdPUudduUPdPa.', '.aPu.aPddPa.uPa.', '..a...aPpa...a..', '.......aa.......'],
  ['aPdPUudduUPdPaa.', 'aPu.aPddPa.uPua.', '.a...aPpa...ua..', '......a.a.......'],
  ['.aPdPUudduUPdPa.', '.aPu.aPddPa.uPa.', '..ua..aPpa..a...', '...a.....a......'],
  ['.aaPdPUudduUPdPa', '.auPu.aPddPa.uPa', '..au...aPpa...a.', '.......a.a......'],
];
/** Connected lightning paths: two quiet frames between each irregular stutter of electricity. */
const OSHADE_ARCS: [number, number][][][] = [
  [
    [[2, 2], [4, 3], [3, 4], [5, 6]],
    [[13, 3], [11, 4], [12, 5], [10, 6]],
    [[1, 11], [3, 10], [2, 9]],
    [[14, 12], [12, 13], [13, 14]],
  ],
  [
    [[1, 5], [3, 6], [2, 7], [4, 8]],
    [[14, 2], [12, 3], [13, 4]],
    [[6, 15], [7, 13], [8, 14]],
  ],
  [
    [[3, 1], [4, 2], [3, 3]],
    [[13, 8], [11, 9], [12, 10], [10, 11]],
    [[2, 13], [4, 12], [3, 11]],
  ],
  [
    [[7, 0], [8, 1], [7, 2]],
    [[15, 5], [13, 6], [14, 7]],
    [[0, 9], [2, 10], [1, 11]],
  ],
  [],
  [],
];

// ------------------------------------------------------------- hyper soul
// What a burnt overcharge shade sometimes leaves behind: a blue wisp with a white heart.

const SOUL = [
  ['...R...', '...I...', '..RIR..', 'RIIFFIR', '..RIR..', '...I...', '...R...'],
  ['.......', '.R...R.', '..III..', '.QIFIQ.', '..III..', '.R...R.', '.......'],
  ['...Q...', '...R...', '..RIR..', '.RIFIR.', '..RIR..', '...R...', '...Q...'],
];

// ---------------------------------------------------------- water octopus
// A squat dome, 13 x 10. A water tile is 16 pixels wide and its banks take one pixel on each
// side, so this is the widest head that still sits wholly inside a pool one tile across.
// Only the head is authored (two breathing frames); its eyes, its arms and the shape it
// makes under the surface are drawn by the game. V outline, v body, l/L shine, s shade, M spots.

const OCTO_HEAD = [
  [
    '...VVVVVVV...',
    '.VVvllllvvVV.',
    'VvlLLlvvvMvvV',
    'VvvvvvvvvvvvV',
    'VvvvvvvvvvvvV',
    'VvMvvvvvvvvsV',
    'VvvvvvvvvvssV',
    'VsvvsvvvsvssV',
    'VssVVsVsVVssV',
    '.VV..V.V..VV.',
  ],
  [
    '..VVVVVVVVV..',
    'VVvvlllvvvvVV',
    'VvvlLLlvvMvvV',
    'VvvvvvvvvvvvV',
    'VvvvvvvvvvvvV',
    'VvMvvvvvvvvsV',
    'VvvvvvvvvvssV',
    'VsvvsvvvsvssV',
    'VssVVsVsVVssV',
    '.VV..V.V..VV.',
  ],
];

// --------------------------------------------------------------- guide book
// A proper little grimoire: a red leather cover with brass corners, two cream pages with
// inked glyphs, a ribbon, and a carved stone pedestal with a turquoise inlay.

function buildLectern(): Sprite {
  const [c, g] = blank(24, 24);
  const r = (col: string, x: number, y: number, w: number, h: number) => {
    g.fillStyle = col;
    g.fillRect(x, y, w, h);
  };
  // pedestal: a stepped foot, a tapered carved stem, and a capital under the book
  r('#111020', 5, 22, 15, 2);
  r('#9a9fb8', 5, 20, 14, 2);
  r('#4a4d68', 6, 21, 12, 2);
  r('#c9cde0', 6, 20, 12, 1);
  r('#6b6f8a', 7, 18, 10, 2);
  r('#9a9fb8', 8, 18, 8, 1);
  r('#6b6f8a', 9, 10, 6, 8);
  r('#9a9fb8', 9, 10, 2, 8);
  r('#4a4d68', 13, 10, 2, 8);
  r('#c9cde0', 9, 11, 1, 6);
  r('#2f8f9a', 11, 13, 2, 3);
  r('#88e4d8', 11, 13, 1, 2);
  r('#4a4d68', 7, 9, 10, 2);
  r('#9a9fb8', 7, 9, 10, 1);
  // leather binding and the stepped silhouette of an open book
  r('#45143b', 4, 0, 16, 1);
  r('#9c2a3a', 2, 1, 20, 7);
  r('#9c2a3a', 1, 3, 22, 4);
  r('#e8552d', 3, 1, 18, 1);
  r('#e8552d', 2, 2, 1, 5);
  r('#45143b', 20, 2, 1, 5);
  // left and right page blocks, with a bright upper edge and shaded lower edge
  r('#a8916f', 3, 2, 8, 6);
  r('#a8916f', 13, 2, 8, 6);
  r('#fff1c2', 4, 2, 7, 5);
  r('#fff1c2', 13, 2, 7, 5);
  r('#e6d8b8', 4, 6, 7, 1);
  r('#e6d8b8', 13, 6, 7, 1);
  r('#fff1c2', 4, 2, 6, 1);
  r('#fff1c2', 14, 2, 6, 1);
  r('#8a5a3c', 11, 2, 2, 6);
  r('#d0a16a', 11, 2, 1, 5);
  // actual tiny lines of ink, not just a blank cream rectangle
  r('#a8916f', 5, 3, 4, 1);
  r('#a8916f', 5, 5, 3, 1);
  r('#a8916f', 14, 3, 4, 1);
  r('#a8916f', 16, 5, 3, 1);
  r('#4b3a8f', 6, 4, 1, 1);
  r('#2f8f9a', 16, 4, 1, 1);
  // brass corner guards and the ribbon hanging over the binding
  r('#ffd15c', 2, 2, 2, 1);
  r('#ffd15c', 2, 3, 1, 2);
  r('#ffd15c', 20, 2, 2, 1);
  r('#ffd15c', 21, 3, 1, 2);
  r('#ffd15c', 11, 7, 2, 1);
  r('#e8552d', 13, 8, 1, 4);
  r('#ff9a3c', 13, 11, 1, 1);
  return c;
}

const ICON_BOOK = ['nnn.nnn', 'nwnBnwn', 'nwnBnwn', 'nwnBnwn', 'bbbBbbb'];

// -------------------------------------------------------------------- moth

const MOTH = [
  ['nn.......nn', 'nNn..b..nNn', 'nNNn.B.nNNn', '.nNNnBnNNn.', '..nnnBnnn..', '.....B.....', '...........'],
  ['...........', '.....b.....', 'nnnn.B.nnnn', 'nNNNnBnNNNn', '.nnNnBnNnn.', '.....B.....', '...........'],
  ['...........', '.....b.....', '.....B.....', '.nnnnBnnnn.', 'nNNNnBnNNNn', 'nNn..B..nNn', 'nn.......nn'],
];

// ----------------------------------------------------------------- brazier

const BRAZIER = [
  '.hHHHHHHHHHHh.',
  'hgkkkkkkkkkkgG',
  'hggkkkkkkkkggG',
  '.hggggggggggG.',
  '..GggggggggG..',
  '...GGggggGG...',
  '.....gggG.....',
  '.....hggG.....',
  '.....hggG.....',
  '....hgggGG....',
  '...hggggggG...',
  '..hgggggggGG..',
  '..GGGGGGGGGG..',
];
const COALS = [
  ['royoryoyor', '.ryroyror.'],
  ['oryoyroyro', '.oroyryro.'],
];
const FLAME = [
  [
    '....o.....',
    '....oo....',
    '...oyo....',
    '...oyyo...',
    '..oyyyo.o.',
    '..oywyoo..',
    '.oyywyyo..',
    '.oywwwyo..',
    '.oywwwyyo.',
    '..oywwyo..',
    '...oyyo...',
  ],
  [
    '.....o....',
    '....oo....',
    '....oyo...',
    '.o.oyyo...',
    '..ooyyyo..',
    '..oyywyo..',
    '.oyywwyo..',
    '.oywwwyyo.',
    '.oyywwwyo.',
    '..oywwyo..',
    '...oyyo...',
  ],
  [
    '..........',
    '....o.....',
    '...oyo....',
    '...oyyo...',
    '..oyyyo...',
    '.ooywyyo..',
    '.oyywwyo..',
    '.oywwwyo..',
    '.oyywwyyo.',
    '..oywwyo..',
    '...oyyo...',
  ],
  [
    '...o......',
    '....o.....',
    '...oyo..o.',
    '..oyyo.o..',
    '..oyyyoo..',
    '..oywyyo..',
    '.oyywwyo..',
    '.oywwwyyo.',
    '.oyywwyo..',
    '..oywwyo..',
    '...oyyo...',
  ],
];

// ------------------------------------------------------------------- ember

const EMBER = [
  ['...o...', '...y...', '..oyo..', 'oyywyyo', '..oyo..', '...y...', '...o...'],
  ['.......', '.o...o.', '..yyy..', '..ywy..', '..yyy..', '.o...o.', '.......'],
  ['.......', '...o...', '..oyo..', '.oywyo.', '..oyo..', '...o...', '.......'],
];

// -------------------------------------------------------------------- gate
// k = doorway (becomes the portal), x = rune slots, q = keystone gem.

const GATE = [
  '......hHHHHHHh......',
  '....hHggggggggGG....',
  '...hggggqqggggggG...',
  '..hgggGGGGGGGGgggG..',
  '.hgggGkkkkkkkkGgggG.',
  '.hggGkkkkkkkkkkGggG.',
  'hgggGkkkkkkkkkkGgggG',
  'hggGkkkkkkkkkkkkGggG',
  'hxgGkkkkkkkkkkkkGgxG',
  'hggGkkkkkkkkkkkkGggG',
  'hGgGkkkkkkkkkkkkGgGG',
  'hxgGkkkkkkkkkkkkGgxG',
  'hggGkkkkkkkkkkkkGggG',
  'hGgGkkkkkkkkkkkkGgGG',
  'hxgGkkkkkkkkkkkkGgxG',
  'hggGkkkkkkkkkkkkGggG',
  'hGgGkkkkkkkkkkkkGgGG',
  'HhhGkkkkkkkkkkkkGhhG',
  'GGGGGkkkkkkkkkkGGGGG',
];

// ----------------------------------------------------------------- effects

const POOF = [
  ['.hhh.', 'hhhhh', 'hhhhh', 'hhhhh', '.hhh.'],
  ['..hhh..', '.hgggh.', 'hg...gh', 'hg...gh', 'hg...gh', '.hgggh.', '..hhh..'],
  [
    '..g.g.g..',
    '.........',
    'g.......g',
    '.........',
    'g.......g',
    '.........',
    'g.......g',
    '.........',
    '..g.g.g..',
  ],
];
const SPARKLE = [
  ['.........', '.........', '.........', '....w....', '...www...', '....w....', '.........', '.........', '.........'],
  ['.........', '....y....', '....w....', '....w....', '.ywwwwwy.', '....w....', '....w....', '....y....', '.........'],
  ['....y....', '.........', '..y...y..', '....w....', 'y..w.w..y', '....w....', '..y...y..', '.........', '....y....'],
  ['....o....', '.........', '.o.....o.', '.........', 'o.......o', '.........', '.o.....o.', '.........', '....o....'],
];
const RIPPLE = [
  ['.aaaa.', 'a....a', '.aaaa.'],
  ['..aaaa..', 'a......a', 'a......a', '..aaaa..'],
  ['..a.aa.a..', '..........', 'a........a', '..........', '..a.aa.a..'],
];

// --------------------------------------------------------------------- hud

const HUD_FLAME = [
  ['..o..', '.oo..', '.oyo.', 'oyyyo', 'oywyo', 'oywyo', '.ooo.'],
  ['...o.', '..oo.', '.oyo.', 'oyyyo', 'oywyo', 'oywyo', '.ooo.'],
];
const PIP_LIT = ['..y..', '.oyo.', 'hgggh', '.ggg.', '..G..'];
const PIP_UNLIT = ['.....', '.....', 'GGGGG', '.GGG.', '..G..'];

const ICON_PAUSE = ['.......', '.ww.ww.', '.ww.ww.', '.ww.ww.', '.ww.ww.', '.ww.ww.', '.......'];
const ICON_SOUND = ['...w...', '..ww.w.', 'wwww..w', 'wwww..w', 'wwww..w', '..ww.w.', '...w...'];
const ICON_MUTED = ['...w...', '..ww...', 'wwwwe.e', 'wwww.e.', 'wwwwe.e', '..ww...', '...w...'];
const ICON_GEAR = ['.w...w.', '..www..', 'ww.k.ww', '.wkkkw.', 'ww.k.ww', '..www..', '.w...w.'];
const ICON_ADMIN = ['y..y..y', 'yy.y.yy', 'yyyyyyy', 'ycyyycy', 'yyyyyyy', '.yyyyy.', '.......'];
const ICON_DASH = ['w..w...', '.w..w..', '..w..w.', '.w..w..', 'w..w...'];

const MARKER = ['...k...', '..kok..', '.koyok.', 'koywyok', '.koyok.', '..kok..', '...k...'];
const ARROW_E = ['.kk....', '.kyk...', '.kyyk..', '.kywyk.', '.kyyk..', '.kyk...', '.kk....'];
const ARROW_NE = ['kkkkkk.', 'kywyyk.', '.kyyyk.', '..kyyk.', '...kyk.', '....kk.', '.......'];
const RETICLE = ['..w..', '.....', 'w...w', '.....', '..w..'];

/** Eight arrows indexed by octant: E, SE, S, SW, W, NW, N, NE. */
function arrows(swap?: Record<string, string>): Sprite[] {
  const e = make(ARROW_E, swap);
  const s = rot90(e);
  const w = rot90(s);
  const n = rot90(w);
  const ne = make(ARROW_NE, swap);
  const se = rot90(ne);
  const sw = rot90(se);
  const nw = rot90(sw);
  return [e, se, s, sw, w, nw, n, ne];
}

export interface Sprites {
  player: PlayerTier[];
  /** The same three sizes, burning blue while overcharged. */
  playerOC: PlayerTier[];
  shade: Sprite[];
  shadeBurn: Sprite[];
  /** The overcharge shade: bigger, blue over violet. */
  oshade: Sprite[];
  oshadeBurn: Sprite[];
  /** Lightning frames crackling over the overcharge shade. */
  oshadeArcs: Sprite[];
  /** Its restless electric aura. */
  oshadeAura: Sprite;
  /** The hyper soul pickup. */
  soul: Sprite[];
  moth: Sprite[];
  octoHead: Sprite[];
  /** The same head in the colours of the water, for when it only peeks. */
  octoCamo: Sprite[];
  /** A white-hot frame for the instant it strikes. */
  octoFlash: Sprite;
  /** The mantle as seen through the water. */
  octoSub: Sprite[];
  lectern: Sprite;
  bookAura: Sprite;
  iconBook: Sprite;
  brazier: Sprite;
  coals: Sprite[];
  flame: Sprite[];
  ember: Sprite[];
  gate: Sprite;
  gateMask: Px[];
  gateRunes: Px[];
  gateGem: Px[];
  poof: Sprite[];
  poofFire: Sprite[];
  poofShade: Sprite[];
  poofOC: Sprite[];
  sparkle: Sprite[];
  ripple: Sprite[];
  shadowS: Sprite;
  shadowM: Sprite;
  shadowL: Sprite;
  hudFlame: Sprite[];
  hudFlameDim: Sprite;
  /** The HUD flame while overcharged. */
  hudFlameOC: Sprite[];
  pipLit: Sprite;
  pipUnlit: Sprite;
  pipPop: Sprite;
  iconPause: Sprite;
  iconSound: Sprite;
  iconMuted: Sprite;
  iconGear: Sprite;
  iconAdmin: Sprite;
  iconDash: Sprite;
  iconDashDim: Sprite;
  markerFire: Sprite;
  markerGate: Sprite;
  arrowFire: Sprite[];
  arrowGate: Sprite[];
  reticle: Sprite;
  ring: Sprite;
  ringHot: Sprite;
  knob: Sprite;
  ringStatic: Sprite;
  ringStaticHot: Sprite;
  knobStatic: Sprite;
  /** [resting, ready, pressed] */
  btnFlare: Sprite[];
  btnDash: Sprite[];
}

export function buildSprites(): Sprites {
  const shade = SHADE_HEMS.map((hem) => make([...SHADE_HOOD, ...hem]));
  const oshade = OSHADE_HEMS.map((hem) => make([...OSHADE_HOOD, ...hem]));
  const pipLit = make(PIP_LIT);
  const SHADOW = 'rgba(7,6,22,0.38)';
  const OCTO_CAMO_PAL = { V: 'D', v: 'A', s: 'S', M: 'D', l: 'W', L: 'T' };
  const octoHead = OCTO_HEAD.map((o) => make(o));
  return {
    player: [tier(BIG_TIPS, BIG_BODY, 9, 3, 6), tier(MID_TIPS, MID_BODY, 6, 2, 5), tier(SMALL_TIPS, SMALL_BODY, 4, 1, 4)],
    playerOC: [
      tier(BIG_TIPS, BIG_BODY, 9, 3, 6, OC, DIM_OC, TRAIL_OC),
      tier(MID_TIPS, MID_BODY, 6, 2, 5, OC, DIM_OC, TRAIL_OC),
      tier(SMALL_TIPS, SMALL_BODY, 4, 1, 4, OC, DIM_OC, TRAIL_OC),
    ],
    shade,
    shadeBurn: ['#fff1c2', '#ffd15c', '#ff9a3c', '#e8552d'].map((c) => tint(shade[0], c)),
    oshade,
    oshadeBurn: ['#f2feff', '#9fe4ff', '#4fa8ff', '#5a63f2'].map((c) => tint(oshade[0], c)),
    oshadeArcs: OSHADE_ARCS.map((paths) => {
      const [c, g] = blank(16, 16);
      // Bresenham's line, one whole pixel at a time: connected bolts, never blurred strokes.
      paths.forEach((points, pathIndex) => {
        for (let i = 1; i < points.length; i++) {
          let [x, y] = points[i - 1];
          const [tx, ty] = points[i];
          const dx = Math.abs(tx - x);
          const dy = -Math.abs(ty - y);
          const sx = x < tx ? 1 : -1;
          const sy = y < ty ? 1 : -1;
          let err = dx + dy;
          for (let guard = 0; guard < 32; guard++) {
            g.fillStyle = pathIndex === 0 && i === 1 ? '#9fe4ff' : '#4fa8ff';
            g.fillRect(x, y, 1, 1);
            if (x === tx && y === ty) break;
            const e2 = err * 2;
            if (e2 >= dy) { err += dy; x += sx; }
            if (e2 <= dx) { err += dx; y += sy; }
          }
        }
        const tip = points[points.length - 1];
        g.fillStyle = '#f2feff';
        g.fillRect(tip[0], tip[1], 1, 1);
      });
      return c;
    }),
    oshadeAura: ellipse(28, 10, 'rgba(79,168,255,0.13)'),
    soul: SOUL.map((s) => make(s)),
    moth: MOTH.map((m) => make(m)),
    octoHead,
    octoCamo: OCTO_HEAD.map((o) => make(o, OCTO_CAMO_PAL)),
    octoFlash: tint(octoHead[0], '#fff1c2'),
    octoSub: [ellipse(9, 6, '#122a47'), ellipse(10, 5, '#122a47')],
    lectern: buildLectern(),
    bookAura: ellipse(34, 12, 'rgba(255,209,92,0.12)'),
    iconBook: make(ICON_BOOK),
    brazier: make(BRAZIER),
    coals: COALS.map((c) => make(c)),
    flame: FLAME.map((f) => make(f)),
    ember: EMBER.map((e) => make(e)),
    gate: make(GATE, { x: 'G', q: 'P' }),
    gateMask: scan(GATE, 'k'),
    gateRunes: scan(GATE, 'x'),
    gateGem: scan(GATE, 'q'),
    poof: POOF.map((p) => make(p)),
    poofFire: POOF.map((p) => make(p, { h: 'y', g: 'o' })),
    poofShade: POOF.map((p) => make(p, { h: 'p', g: 'P' })),
    poofOC: POOF.map((p) => make(p, { h: 'I', g: 'R' })),

    sparkle: SPARKLE.map((s) => make(s)),
    ripple: RIPPLE.map((r) => make(r)),
    shadowS: ellipse(5, 2, SHADOW),
    shadowM: ellipse(8, 3, SHADOW),
    shadowL: ellipse(12, 4, SHADOW),
    hudFlame: HUD_FLAME.map((f) => make(f)),
    hudFlameDim: make(HUD_FLAME[0], { o: 'G', y: 'g', w: 'h' }),
    hudFlameOC: HUD_FLAME.map((f) => make(f, { o: 'R', y: 'I', w: 'F' })),
    pipLit,
    pipUnlit: make(PIP_UNLIT),
    pipPop: tint(pipLit, '#fff1c2'),
    iconPause: make(ICON_PAUSE),
    iconSound: make(ICON_SOUND),
    iconMuted: make(ICON_MUTED),
    iconGear: make(ICON_GEAR),
    iconAdmin: make(ICON_ADMIN),
    iconDash: make(ICON_DASH),
    iconDashDim: make(ICON_DASH, { w: 'g' }),
    markerFire: make(MARKER),
    markerGate: make(MARKER, { o: 'C', y: 'c' }),
    arrowFire: arrows(),
    arrowGate: arrows({ y: 'c' }),
    reticle: make(RETICLE),
    ring: ring(22, 'rgba(255,241,194,0.07)', '#9a9fb8'),
    ringHot: ring(22, 'rgba(255,241,194,0.12)', '#fff1c2'),
    knob: disc(9, '#fff1c2', '#ffd15c', '#ffffff'),
    ringStatic: ring(29, 'rgba(255,241,194,0.09)', '#9a9fb8'),
    ringStaticHot: ring(29, 'rgba(255,241,194,0.16)', '#fff1c2'),
    knobStatic: disc(13, '#fff1c2', '#ffd15c', '#ffffff'),
    btnFlare: [
      disc(15, '#17122e', '#4a4d68'),
      disc(15, '#4a1c2c', '#ff9a3c', '#ffd15c'),
      disc(15, '#9c2a3a', '#fff1c2'),
    ],
    btnDash: [
      disc(11, '#17122e', '#4a4d68'),
      disc(11, '#143040', '#6fe3d2', '#e9fffb'),
      disc(11, '#2f8f9a', '#fff1c2'),
    ],
  };
}
