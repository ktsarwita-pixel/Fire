// A small pixel-art UI kit. Nothing here is drawn with a system font or a smooth edge:
// text uses the game's own 3x5 bitmap font, icons are character grids in the game's
// palette, and frames are tiny bevelled images. Every size is a whole number of "art
// pixels" (the CSS variable --px), so the whole panel sits on one pixel grid.

import { createContext, memo } from 'react';
import type { CSSProperties } from 'react';
import { glyphBits } from '../game/font';
import { PAL } from '../game/sprites';

export type Vars = CSSProperties & Record<`--${string}`, string>;

/** A length in art pixels. */
export const u = (n: number): string => `calc(var(--px) * ${n})`;

const INK = '#070616';

// ------------------------------------------------------------------- text

interface TextShape {
  d: string;
  w: number;
}

const textCache = new Map<string, TextShape>();

/** One SVG path covering every lit pixel of the string, with runs merged into bars. */
function textShape(text: string): TextShape {
  let hit = textCache.get(text);
  if (hit) return hit;
  let d = '';
  for (let i = 0; i < text.length; i++) {
    const g = glyphBits(text[i]);
    if (!g) continue;
    const ox = i * 4;
    for (let r = 0; r < 5; r++) {
      for (let c = 0; c < 3; c++) {
        if (g.charCodeAt(r * 3 + c) !== 49) continue;
        let e = c + 1;
        while (e < 3 && g.charCodeAt(r * 3 + e) === 49) e++;
        d += `M${ox + c} ${r}h${e - c}v1h${c - e}z`;
        c = e;
      }
    }
  }
  hit = { d, w: Math.max(1, text.length * 4 - 1) };
  if (textCache.size > 800) textCache.clear();
  textCache.set(text, hit);
  return hit;
}

export const PxText = memo(function PxText({
  text,
  color,
  scale = 1,
  shadow = true,
}: {
  text: string;
  color?: string;
  scale?: number;
  shadow?: boolean;
}) {
  const { d, w } = textShape(text.toUpperCase());
  const s = shadow ? 1 : 0;
  return (
    <svg
      aria-hidden="true"
      viewBox={`0 0 ${w + s} ${5 + s}`}
      shapeRendering="crispEdges"
      style={{ width: u((w + s) * scale), height: u((5 + s) * scale), color }}
    >
      {shadow && <path d={d} fill={INK} transform="translate(1 1)" />}
      <path d={d} fill="currentColor" />
    </svg>
  );
});

// ------------------------------------------------------------------ icons
// Drawn with the same palette letters as the game's sprites.

const ICONS = {
  crown: ['y..y..y', 'y..y..y', 'yy.y.yy', 'yyyyyyy', 'ycyeycy', 'yyyyyyy', '.ooooo.'],
  flame: ['..o..', '.oo..', '.oyo.', 'oyyyo', 'oywyo', 'oywyo', '.ooo.'],
  gate: ['.hhhhh.', 'hgcccgh', 'hcCcCch', 'hcCCcch', 'hccCCch', 'hcCcCch', 'GgcccgG'],
  shade: ['..uuu..', '.uUUUu.', 'uUdddUu', 'uUedeUu', 'uUdddUu', 'uUdUdUu', '.u.u.u.'],
  oshade: ['..ppp..', '.paPap.', 'pPdddPp', 'pPydyPp', 'pPdddPp', 'pPdPdPp', '.p.p.p.'],
  soul: ['...R...', '..RIR..', 'RIFFIR.', '..RIR..', '...I...'],
  stick: ['..www..', '..wyw..', '..www..', '...h...', '...h...', '.GgggG.', 'GGGGGGG'],
  gear: ['.h.h.h.', 'hhhhhhh', '.hhkhh.', 'hhkkkhh', '.hhkhh.', 'hhhhhhh', '.h.h.h.'],
  octo: ['..VVVVV..', '.VvlLvvV.', 'VvvvvvvvV', 'VvwkvwkvV', 'VvvvvvvvV', '.VsVsVsV.', '.V.V.V.V.'],
  pack: ['.VVV.VVV.', 'VvwvVvwvV', 'VvvvVvvvV', '.VVVVVVV.', '..VvwvV..', '..VvvvV..', '...VVV...'],
  moth: ['nn.....nn', 'nNn.b.nNn', '.nNnBnNn.', '..nnBnn..', '....B....'],
  ember: ['...o...', '...y...', '..oyo..', 'oyywyyo', '..oyo..', '...y...', '...o...'],
  drop: ['..a..', '..a..', '.aTa.', '.aTa.', 'aTTTa', 'aTwTa', '.aaa.'],
  puddle: ['..aaa..', '.aTTTa.', 'aTTwTTa', '.aTTTa.', '..aaa..'],
  shield: ['ccccccc', 'cCCwCCc', 'cCwwwCc', 'cCCwCCc', '.cCCCc.', '..cCc..', '...c...'],
  bolt: ['...yy', '..yy.', '.yy..', 'yyyyy', '..yy.', '.yy..', 'yy...'],
  glass: ['hhhhhhh', '.hyyyh.', '..hyh..', '...h...', '..h.h..', '.h.y.h.', 'hhhhhhh'],
  ghost: ['..www..', '.wwwww.', 'wkwwkww', 'wwwwwww', 'wwwwwww', 'wwwwwww', 'w.w.w.w'],
  speed: ['c..c...', '.c..c..', '..c..c.', '...c..c', '..c..c.', '.c..c..', 'c..c...'],
  sun: ['...y...', '.y.y.y.', '..yyy..', 'yyywyyy', '..yyy..', '.y.y.y.', '...y...'],
  eye: ['..www..', '.wcccw.', 'wcckccw', '.wcccw.', '..www..'],
  map: ['nnn.nnn', 'nNnnnNn', 'nnNnNnn', 'nnneNnn', 'nNnnnnn', 'nnnnNnn', 'nnn.nnn'],
  target: ['..ccc..', '.c...c.', 'c..w..c', 'c.www.c', 'c..w..c', '.c...c.', '..ccc..'],
  stairs: ['hhh....', 'GGh....', 'GGhhh..', 'GGGGh..', 'GGGGhhh', 'GGGGGGh', 'GGGGGGG'],
  redo: ['.cccc..', 'c....c.', 'c...ccc', 'c....c.', 'c......', 'c....c.', '.cccc..'],
  down: ['..yyy..', '..yyy..', '..yyy..', 'yyyyyyy', '.yyyyy.', '..yyy..', '...y...'],
  brazier: ['..o.o..', '.oyoyo.', '..oyo..', 'hgggggh', '.hgggh.', '..hgh..', '.hhhhh.'],
  cold: ['.......', '.......', '..G.G..', 'hgggggh', '.hgggh.', '..hgh..', '.hhhhh.'],
  skull: ['.wwwww.', 'wwwwwww', 'wkkwkkw', 'wkkwkkw', 'wwwkwww', '.wwwww.', '.w.w.w.'],
  heart: ['.......', '.ee.ee.', 'eeeeeee', 'eeeeeee', '.eeeee.', '..eee..', '...e...'],
  trash: ['..eee..', 'eeeeeee', '.ememe.', '.ememe.', '.ememe.', '.ememe.', '.eeeee.'],
  frost: ['...a...', '.a.a.a.', '..aaa..', 'aaawaaa', '..aaa..', '.a.a.a.', '...a...'],
  clock: ['.hhhhh.', 'hwwkwwh', 'hwwkwwh', 'hwwkkwh', 'hwwwwwh', 'hwwwwwh', '.hhhhh.'],
  step: ['c...c..', 'cc..c..', 'ccc.c..', 'ccccc..', 'ccc.c..', 'cc..c..', 'c...c..'],
  pause: ['.yy.yy.', '.yy.yy.', '.yy.yy.', '.yy.yy.', '.yy.yy.', '.yy.yy.', '.yy.yy.'],
  play: ['.c.....', '.ccc...', '.ccccc.', '.cccccc', '.ccccc.', '.ccc...', '.c.....'],
  bug: ['.c...c.', '..ccc..', 'ccwcwcc', '.ccccc.', 'ccccccc', '.ccccc.', 'c.c.c.c'],
  box: ['ee.e.ee', 'e.....e', '.......', 'e..w..e', '.......', 'e.....e', 'ee.e.ee'],
  buzz: ['c.www.c', 'c.wkw.c', '.cwkwc.', 'c.wkw.c', 'c.wkw.c', '.cwwwc.', 'c.....c'],
  sound: ['...w...', '..ww.w.', 'wwww..w', 'wwww..w', 'wwww..w', '..ww.w.', '...w...'],
  keys: ['hhhhhhh', 'hwhwhwh', 'hhhhhhh', 'hwwwwwh', 'hhhhhhh'],
  disk: ['hhhhhh.', 'hGwwGhh', 'hGwwGhh', 'hhhhhhh', 'hkkkkkh', 'hkkkkkh', 'hhhhhhh'],
  tune: ['.c.....', 'ccc.y..', '.c.yyy.', '.c..y..', '.c..y..', '.c..y..', '.......'],
  star: ['...y...', '...y...', 'yyywyyy', '.yywyy.', '..yyy..', '.yy.yy.', '.y...y.'],
  ring: ['..yyy..', '.y...y.', 'y.....y', 'y..o..y', 'y.....y', '.y...y.', '..yyy..'],
  wave: ['.......', '.aa..aa', 'a..aa..', '.......', '.aa..aa', 'a..aa..', '.......'],
  book: ['nnn.nnn', 'nwnBnwn', 'nwnBnwn', 'nwnBnwn', 'nwnBnwn', 'bbbBbbb', '...e...'],
  left: ['..w..', '.w...', 'wwwww', '.w...', '..w..'],
  right: ['..w..', '...w.', 'wwwww', '...w.', '..w..'],
  close: ['e...e', '.e.e.', '..e..', '.e.e.', 'e...e'],
  peek: ['.....', 'w...w', '.w.w.', '..w..', '.....'],
  open: ['.....', '..w..', '.w.w.', 'w...w', '.....'],
  plus: ['..w..', '..w..', 'wwwww', '..w..', '..w..'],
  minus: ['.....', '.....', 'wwwww', '.....', '.....'],
  lampOn: ['.ccc.', 'ccwcc', 'cwccc', 'ccccc', '.ccc.'],
  lampHold: ['.yyy.', 'yywyy', 'ywyyy', 'yyyyy', '.yyy.'],
  swOff: [
    '.GGGGGGGGGGG.',
    'GkkkkkkkkkkkG',
    'GkhhhkkkkkkkG',
    'GkhHhkkkkkkkG',
    'GkhhhkkkkkkkG',
    'GkkkkkkkkkkkG',
    '.GGGGGGGGGGG.',
  ],
  swOn: [
    '.ccccccccccc.',
    'cCCCCCCCCCCCc',
    'cCCCCCCCwwwCc',
    'cCCCCCCCwywCc',
    'cCCCCCCCwwwCc',
    'cCCCCCCCCCCCc',
    '.ccccccccccc.',
  ],
} as const satisfies Record<string, readonly string[]>;

export type IconName = keyof typeof ICONS;

interface IconShape {
  w: number;
  h: number;
  paths: { fill: string; d: string }[];
}

const iconCache = new Map<string, IconShape>();

function iconShape(name: IconName): IconShape {
  let hit = iconCache.get(name);
  if (hit) return hit;
  const rows: readonly string[] = ICONS[name];
  const byColor = new Map<string, string>();
  let w = 0;
  rows.forEach((row, y) => {
    w = Math.max(w, row.length);
    for (let x = 0; x < row.length; x++) {
      const ch = row[x];
      const col = PAL[ch];
      if (!col) continue;
      let e = x + 1;
      while (e < row.length && row[e] === ch) e++;
      byColor.set(col, (byColor.get(col) ?? '') + `M${x} ${y}h${e - x}v1h${x - e}z`);
      x = e - 1;
    }
  });
  hit = { w, h: rows.length, paths: [...byColor].map(([fill, d]) => ({ fill, d })) };
  iconCache.set(name, hit);
  return hit;
}

/** `box` centres the icon in a square of that many art pixels, so mixed icon sizes line up. */
export const PxIcon = memo(function PxIcon({ name, box, scale = 1 }: { name: IconName; box?: number; scale?: number }) {
  const { w, h, paths } = iconShape(name);
  const svg = (
    <svg
      aria-hidden="true"
      viewBox={`0 0 ${w} ${h}`}
      shapeRendering="crispEdges"
      style={{ width: u(w * scale), height: u(h * scale) }}
    >
      {paths.map((p) => (
        <path key={p.fill} d={p.d} fill={p.fill} />
      ))}
    </svg>
  );
  if (!box) return svg;
  return <span style={{ width: u(box), height: u(box), display: 'grid', placeItems: 'center', flex: 'none' }}>{svg}</span>;
});

// ----------------------------------------------------------------- frames
// Nine-slice borders. Each is painted at the exact size it is shown, so the browser never
// has to scale (and so never smooths) a single art pixel.

export type Tone = 'stone' | 'gold' | 'cyan' | 'pink' | 'red';

export interface FrameSet {
  panel: string;
  well: string;
  tabOn: string;
  tabOff: string;
  dither: string;
  tone: Record<Tone, { up: string; down: string }>;
}

export const TONE_TEXT: Record<Tone, string> = {
  stone: '#fff1c2',
  gold: '#ffd15c',
  cyan: '#e9fffb',
  pink: '#ffd1e3',
  red: '#ffc2cf',
};

type Rect = (color: string, x: number, y: number, w: number, h: number) => void;

function png(w: number, h: number, px: number, paint: (rect: Rect) => void): string {
  const c = document.createElement('canvas');
  c.width = w * px;
  c.height = h * px;
  const g = c.getContext('2d') as CanvasRenderingContext2D;
  paint((color, x, y, ww, hh) => {
    g.fillStyle = color;
    g.fillRect(x * px, y * px, ww * px, hh * px);
  });
  return `url(${c.toDataURL()})`;
}

/** A 7x7 bevelled box with notched corners: ink edge, lit top-left rim, shaded bottom-right rim. */
function bevel(px: number, hi: string, lo: string, fill: string): string {
  return png(7, 7, px, (r) => {
    r(INK, 1, 0, 5, 1);
    r(INK, 1, 6, 5, 1);
    r(INK, 0, 1, 1, 5);
    r(INK, 6, 1, 1, 5);
    r(fill, 1, 1, 5, 5);
    r(lo, 1, 5, 5, 1);
    r(lo, 5, 1, 1, 5);
    r(hi, 1, 1, 4, 1);
    r(hi, 1, 1, 1, 4);
  });
}

/** The 9x9 outer frame: ink, a gold band lit from the top-left, ink again, then the fill. */
function panel(px: number): string {
  const lit = '#ffd15c';
  const dim = '#ff9a3c';
  return png(9, 9, px, (r) => {
    r(INK, 2, 0, 5, 1);
    r(INK, 2, 8, 5, 1);
    r(INK, 0, 2, 1, 5);
    r(INK, 8, 2, 1, 5);
    r(INK, 1, 1, 1, 1);
    r(INK, 7, 1, 1, 1);
    r(INK, 1, 7, 1, 1);
    r(INK, 7, 7, 1, 1);
    r(dim, 2, 7, 5, 1);
    r(dim, 7, 2, 1, 5);
    r(dim, 6, 6, 1, 1);
    r(lit, 2, 1, 5, 1);
    r(lit, 1, 2, 1, 5);
    r(lit, 2, 2, 1, 1);
    r(lit, 6, 2, 1, 1);
    r(lit, 2, 6, 1, 1);
    r(INK, 3, 2, 3, 1);
    r(INK, 3, 6, 3, 1);
    r(INK, 2, 3, 1, 3);
    r(INK, 6, 3, 1, 3);
    r('#17122e', 3, 3, 3, 3);
  });
}

const frameCache = new Map<number, FrameSet>();

export function getFrames(px: number): FrameSet {
  let f = frameCache.get(px);
  if (f) return f;
  const pair = (hi: string, lo: string, fill: string, pressed: string) => ({
    up: bevel(px, hi, lo, fill),
    down: bevel(px, lo, hi, pressed),
  });
  f = {
    panel: panel(px),
    well: bevel(px, '#0b0a16', '#3a3560', '#100d22'),
    tabOn: bevel(px, '#ffd15c', '#8a5a3c', '#3a3560'),
    tabOff: bevel(px, '#3a3560', '#17122e', '#221d40'),
    dither: png(2, 2, px, (r) => {
      r('rgba(7,6,22,0.92)', 0, 0, 1, 1);
      r('rgba(7,6,22,0.92)', 1, 1, 1, 1);
      r('rgba(7,6,22,0.58)', 1, 0, 1, 1);
      r('rgba(7,6,22,0.58)', 0, 1, 1, 1);
    }),
    tone: {
      stone: pair('#6b6f8a', '#221d40', '#342f58', '#2b2648'),
      gold: pair('#ffd15c', '#8a5a3c', '#5a3a2c', '#4a2e22'),
      cyan: pair('#6fe3d2', '#2f8f9a', '#17404c', '#113540'),
      pink: pair('#eb77a8', '#83255b', '#45143b', '#3a1032'),
      red: pair('#ff4d6d', '#9c2a3a', '#3a1424', '#2e101d'),
    },
  };
  frameCache.set(px, f);
  return f;
}

export const Frames = createContext<FrameSet | null>(null);
