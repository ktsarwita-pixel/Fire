// Shared building blocks for the pixel-art panels: the admin panels and the guide book.

import { useCallback, useContext, useEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { Frames, PxIcon, PxText, TONE_TEXT, u } from './pixel';
import type { FrameSet, IconName, Tone, Vars } from './pixel';

export const GOLD = '#ffd15c';
export const CYAN = '#6fe3d2';
export const MUTED = '#9a9fb8';
export const DIM = '#6b6f8a';

export interface Layout {
  /** CSS pixels per art pixel. */
  px: number;
  /** Content width in art pixels: one of a few widths that every column count divides evenly. */
  inner: number;
  cols: number;
  short: boolean;
  touch: boolean;
}

export function measure(): Layout {
  const W = window.innerWidth;
  const H = window.innerHeight;
  const game = Math.max(1, Math.round(Math.sqrt((W * H) / 38000)));
  const px = Math.max(2, Math.round(game * 0.62));
  const uw = Math.floor(W / px);
  const inner = [274, 214, 154].find((w) => w + 18 <= uw) ?? Math.max(80, ((uw - 18) >> 1) << 1);
  const touch = typeof window.matchMedia === 'function' && window.matchMedia('(pointer: coarse)').matches;
  return { px, inner, cols: inner >= 274 ? 2 : 1, short: H / px < 230, touch };
}

export function useFrames(): FrameSet {
  const f = useContext(Frames);
  if (!f) throw new Error('pixel frames missing');
  return f;
}

export const mult = (v: number) => v.toFixed(2).replace(/0$/, '') + 'X';
export const pct = (v: number) => Math.round(v * 100) + '%';

// ---------------------------------------------------------------- widgets

export function Btn({
  icon,
  label,
  name,
  tone = 'stone',
  center,
  square,
  latched,
  disabled,
  onClick,
}: {
  icon?: IconName;
  label?: string;
  /** Spoken name, for buttons that show only an icon. */
  name?: string;
  tone?: Tone;
  center?: boolean;
  square?: boolean;
  /** Draws the button held down, for the chosen option of a set. */
  latched?: boolean;
  disabled?: boolean;
  onClick: () => void;
}) {
  const f = useFrames();
  const t = f.tone[tone];
  const style: Vars = { '--frame': latched ? t.down : t.up, '--frame-down': t.down, color: TONE_TEXT[tone] };
  return (
    <button
      type="button"
      className={'px-box px-btn' + (center ? ' px-center' : '') + (square ? ' px-sq' : '')}
      style={style}
      aria-label={name ?? label}
      aria-pressed={latched}
      disabled={disabled}
      onClick={onClick}
    >
      {icon && <PxIcon name={icon} box={square ? 7 : 9} />}
      {label && <PxText text={label} />}
    </button>
  );
}

export function Toggle({
  icon,
  label,
  sub,
  on,
  tone = 'cyan',
  onClick,
}: {
  icon: IconName;
  label: string;
  sub: string;
  on: boolean;
  tone?: Tone;
  onClick: () => void;
}) {
  const f = useFrames();
  const t = f.tone[on ? tone : 'stone'];
  const style: Vars = { '--frame': t.up, '--frame-down': t.down, color: on ? TONE_TEXT[tone] : TONE_TEXT.stone };
  return (
    <button type="button" className="px-box px-btn" style={style} aria-label={label} aria-pressed={on} onClick={onClick}>
      <PxIcon name={icon} box={9} />
      <span className="px-col" style={{ flex: 1, gap: u(2), overflow: 'hidden' }}>
        <PxText text={label} />
        <PxText text={sub} color={on ? '#c9cde0' : MUTED} />
      </span>
      <PxIcon name={on ? 'swOn' : 'swOff'} />
    </button>
  );
}

export function Stepper({
  icon,
  label,
  value,
  canDec = true,
  canInc = true,
  onDec,
  onInc,
}: {
  icon: IconName;
  label: string;
  value: string;
  canDec?: boolean;
  canInc?: boolean;
  onDec: () => void;
  onInc: () => void;
}) {
  const f = useFrames();
  const style: Vars = { '--frame': f.well, padding: u(1), gap: u(2) };
  return (
    <div className="px-box px-row" style={style}>
      <PxIcon name={icon} box={9} />
      <span style={{ flex: 1, minWidth: 0, overflow: 'hidden' }}>
        <PxText text={label} />
      </span>
      <Btn icon="minus" name={label + ' LESS'} square disabled={!canDec} onClick={onDec} />
      <span className="px-row" style={{ width: u(25), justifyContent: 'center' }}>
        <PxText text={value} color={GOLD} />
      </span>
      <Btn icon="plus" name={label + ' MORE'} square disabled={!canInc} onClick={onInc} />
    </div>
  );
}

export interface Chip {
  label: string;
  on: boolean;
  onClick: () => void;
}

export function Chips({ icon, label, note, tone = 'gold', options }: { icon: IconName; label: string; note?: string; tone?: Tone; options: Chip[] }) {
  const f = useFrames();
  const style: Vars = { '--frame': f.well, padding: u(1), gap: u(2) };
  return (
    <div className="px-box px-col" style={style}>
      <div className="px-row" style={{ gap: u(2) }}>
        <PxIcon name={icon} box={9} />
        <span style={{ flex: 1, minWidth: 0, overflow: 'hidden' }}>
          <PxText text={label} />
        </span>
        {note && <PxText text={note} color={MUTED} />}
      </div>
      <div className="px-grid" style={{ gridTemplateColumns: `repeat(${options.length}, minmax(0, 1fr))`, gap: u(2) }}>
        {options.map((o) => (
          <Btn key={o.label} label={o.label} name={label + ' ' + o.label} tone={o.on ? tone : 'stone'} latched={o.on} center onClick={o.onClick} />
        ))}
      </div>
    </div>
  );
}

export function Section({ icon, title, note, children }: { icon: IconName; title: string; note?: string; children: ReactNode }) {
  return (
    <section className="px-col" style={{ gap: u(2) }}>
      <div className="px-row" style={{ gap: u(2), height: u(9) }}>
        <PxIcon name={icon} box={9} />
        <PxText text={title} color={GOLD} />
        <span className="px-rule" />
        {note && <PxText text={note} color={CYAN} />}
      </div>
      {children}
    </section>
  );
}

export function Grid({ cols, children }: { cols: number; children: ReactNode }) {
  return (
    <div className="px-grid" style={{ gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))`, gap: u(2) }}>
      {children}
    </div>
  );
}

/** Ten chunky cells, lit like the flame gauge in the game. */
export function Meter({ value }: { value: number }) {
  const cells: ReactNode[] = [];
  for (let i = 0; i < 10; i++) {
    const w = Math.round(Math.max(0, Math.min(1, (value - i * 10) / 10)) * 8);
    const col = value < 22 ? '#e8552d' : i < 3 ? '#e8552d' : i < 6 ? '#ff9a3c' : GOLD;
    cells.push(
      <g key={i}>
        <rect x={1 + i * 9} y={1} width={8} height={6} fill="#2b2648" />
        {w > 0 && <rect x={1 + i * 9} y={1} width={w} height={6} fill={col} />}
        {w > 0 && <rect x={1 + i * 9} y={1} width={w} height={1} fill="#fff1c2" />}
        {w > 0 && <rect x={1 + i * 9} y={6} width={w} height={1} fill="#9c2a3a" />}
      </g>,
    );
  }
  return (
    <svg aria-hidden="true" viewBox="0 0 91 8" shapeRendering="crispEdges" style={{ width: u(91), height: u(8) }}>
      <rect width={91} height={8} fill="#070616" />
      {cells}
    </svg>
  );
}

export function Stat({ icon, label, value, color }: { icon: IconName; label: string; value: number; color: string }) {
  const f = useFrames();
  const style: Vars = { '--frame': f.well, padding: u(1), gap: u(2), alignItems: 'center' };
  return (
    <div className="px-box px-col" style={style}>
      <span className="px-row" style={{ gap: u(2) }}>
        <PxIcon name={icon} box={9} />
        <PxText text={String(value)} color={color} scale={2} />
      </span>
      <PxText text={label} color={MUTED} />
    </div>
  );
}

export function Info({ lines }: { lines: string[] }) {
  const f = useFrames();
  const style: Vars = { '--frame': f.well, padding: u(2), gap: u(2), overflow: 'hidden' };
  return (
    <div className="px-box px-col" style={style}>
      {lines.map((l) => (
        <PxText key={l} text={l} color={MUTED} />
      ))}
    </div>
  );
}

/** A scrolling column with its own pixel scroll bar; the browser's smooth one stays hidden. */
export function ScrollBody({ px, children }: { px: number; children: ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);
  const [bar, setBar] = useState({ top: 0, size: 0 });
  const sync = useCallback(() => {
    const el = ref.current;
    if (!el) return;
    const { scrollTop, scrollHeight, clientHeight } = el;
    let top = 0;
    let size = 0;
    if (scrollHeight > clientHeight + 1) {
      const track = Math.floor(clientHeight / px);
      size = Math.max(6, Math.round((clientHeight / scrollHeight) * track));
      top = Math.round((scrollTop / (scrollHeight - clientHeight)) * (track - size));
    }
    setBar((b) => (b.top === top && b.size === size ? b : { top, size }));
  }, [px]);
  useEffect(() => {
    sync();
    const el = ref.current;
    if (!el || typeof ResizeObserver !== 'function') return;
    const ro = new ResizeObserver(sync);
    ro.observe(el);
    if (el.firstElementChild) ro.observe(el.firstElementChild);
    return () => ro.disconnect();
  }, [sync]);
  return (
    <div style={{ position: 'relative', flex: 1, minHeight: 0, display: 'flex' }}>
      <div ref={ref} className="px-scroll" onScroll={sync} style={{ flex: 1, minHeight: 0 }}>
        <div className="px-col" style={{ gap: u(4), paddingBottom: u(2) }}>
          {children}
        </div>
      </div>
      {bar.size > 0 && <div className="px-thumb" style={{ top: u(bar.top), height: u(bar.size) }} />}
    </div>
  );
}
