// Tiny 3x5 bitmap font. Every glyph is 15 bits, row by row.
const G: Record<string, string> = {
  A: '010101111101101',
  B: '110101110101110',
  C: '011100100100011',
  D: '110101101101110',
  E: '111100110100111',
  F: '111100110100100',
  G: '011100101101011',
  H: '101101111101101',
  I: '111010010010111',
  J: '001001001101010',
  K: '101101110101101',
  L: '100100100100111',
  M: '101111111101101',
  N: '110101101101101',
  O: '111101101101111',
  P: '110101110100100',
  Q: '111101101111001',
  R: '110101110101101',
  S: '011100010001110',
  T: '111010010010010',
  U: '101101101101111',
  V: '101101101101010',
  W: '101101111111101',
  X: '101101010101101',
  Y: '101101010010010',
  Z: '111001010100111',
  '0': '010101101101010',
  '1': '010110010010111',
  '2': '110001010100111',
  '3': '110001010001110',
  '4': '101101111001001',
  '5': '111100110001110',
  '6': '011100111101111',
  '7': '111001010010010',
  '8': '111101111101111',
  '9': '111101111001110',
  '.': '000000000000010',
  ',': '000000000010100',
  '!': '010010010000010',
  '?': '110001010000010',
  '-': '000000111000000',
  '+': '000010111010000',
  ':': '000010000010000',
  '/': '001001010100100',
  "'": '010010000000000',
  '%': '101001010100101',
  '(': '001010010010001',
  ')': '100010010010100',
  '<': '001010100010001',
  '>': '100010001010100',
  '=': '000111000111000',
  '*': '000101010101000',
  '#': '101111101111101',
  '[': '110100100100110',
  ']': '011001001001011',
  '_': '000000000000111',
  '|': '010010010010010',
};

export function textWidth(text: string, scale = 1): number {
  return text.length ? (text.length * 4 - 1) * scale : 0;
}

/** Draws text. `color` may be one colour or five (one per glyph row). */
export function drawText(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  color: string | string[],
  scale = 1,
): void {
  const multi = Array.isArray(color);
  if (!multi) ctx.fillStyle = color as string;
  let cx = x;
  for (let i = 0; i < text.length; i++) {
    const g = G[text[i]];
    if (g) {
      for (let r = 0; r < 5; r++) {
        if (multi) ctx.fillStyle = (color as string[])[r];
        for (let c = 0; c < 3; c++) {
          if (g.charCodeAt(r * 3 + c) === 49) {
            ctx.fillRect(cx + c * scale, y + r * scale, scale, scale);
          }
        }
      }
    }
    cx += 4 * scale;
  }
}

/** The 15 bits of one glyph, row by row, or undefined for a character the font lacks. */
export function glyphBits(ch: string): string | undefined {
  return G[ch];
}
