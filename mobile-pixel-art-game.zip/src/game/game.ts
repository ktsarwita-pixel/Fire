import { drawText, textWidth } from './font';
import { buildSprites } from './sprites';
import type { PlayerTier, Sprite } from './sprites';
import { carveWaterPuddle, findPuddles, generateLevel, isOpenWater, spreadTiles, TILE, T_WALL, T_WATER } from './level';
import type { Level } from './level';
import { Sfx } from './audio';
import type { AdminBridge, AdminSnapshot, ForcedInput, TeleportTarget } from './admin';
import type { CreatureId, GuideBridge } from './guide';
import {
  BOOK_DEPTH,
  BRAZIER_R,
  DASH_COST,
  FLARE_COST,
  FLARE_R,
  flameBurn,
  MOTH_FLEE_T,
  MOTH_STEAL,
  OCTO_DRAIN,
  OCTO_HOLD_T,
  PLAYER_SPEED,
  SHADE_BITE,
  SHADE_EMBER,
  SHADE_SPEED_LIT,
  shadeSpeed,
  WATER_BURN,
  WATER_SPEED,
} from './rules';

export interface GameOptions {
  onAdminChange?: (open: boolean) => void;
  onGuideChange?: (open: boolean) => void;
  /** A gamepad asked to turn the guide book's page: -1 back, 1 on. */
  onGuidePage?: (dir: number) => void;
}
export interface GameHandle {
  destroy: () => void;
  admin: AdminBridge;
  guide: GuideBridge;
}

type State = 'title' | 'play' | 'pause' | 'settings' | 'over' | 'transition';
type InputMode = 'touch' | 'keys' | 'pad';

interface Shade {
  x: number;
  y: number;
  vx: number;
  vy: number;
  state: 'idle' | 'hunt' | 'burn' | 'gone';
  t: number;
  ph: number;
  lit: boolean;
  tx: number;
  ty: number;
  wait: number;
  rise: number;
  alert: number;
}
interface Moth {
  x: number;
  y: number;
  vx: number;
  vy: number;
  hx: number;
  hy: number;
  ph: number;
  seed: number;
  flee: number;
  carry: boolean;
}
interface Octo {
  x: number;
  y: number;
  state: 'lurk' | 'grab' | 'vanish' | 'emerge';
  t: number;
  ph: number;
  tick: number;
  /** Rows of the head showing above the water. */
  rise: number;
  /** Squeeze pulse: 1 at the moment the arms tighten, fading to 0. */
  sq: number;
  /** Octopuses crowded into one puddle share a pack number; loners are 0. */
  pack: number;
  /** A white-hot flash at the instant it strikes. */
  flash: number;
}
/** A cloud of ink left in a pool. */
interface Ink {
  x: number;
  y: number;
  t: number;
}
/** One queued, depth-sorted draw call. */
interface DrawItem {
  y: number;
  kind: number;
  ref: Brazier | Ember | Shade | null;
}
interface Ember {
  x: number;
  y: number;
  v: number;
  ph: number;
  z: number;
  vz: number;
}
interface Brazier {
  x: number;
  y: number;
  lit: boolean;
  litT: number;
}
interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  ramp: string[];
  g: number;
  big: boolean;
}
interface Floater {
  x: number;
  y: number;
  text: string;
  color: string;
  t: number;
}
interface Flare {
  x: number;
  y: number;
  t: number;
  r: number;
}
/** A short authored frame animation (poofs, sparkles, ripples). */
interface Fx {
  x: number;
  y: number;
  frames: Sprite[];
  t: number;
  dur: number;
  glow: boolean;
}
/** Dash afterimage. */
interface Ghost {
  x: number;
  y: number;
  tier: number;
  t: number;
}

const INK = '#070616';
const CREAM = '#fff1c2';
const FIRE = ['#fff1c2', '#ffd15c', '#ff9a3c', '#e8552d', '#9c2a3a'];
const SPARK = ['#fff1c2', '#ffd15c', '#ff9a3c'];
const SMOKE = ['#9a9fb8', '#6b6f8a', '#4a4d68'];
const DUST = ['#7d819c', '#565a78'];
const SPLASH = ['#e9fffb', '#6fb6e0', '#2e6396'];
const SHADOW = ['#b08cff', '#7b5cd6', '#4b3a8f', '#2b2648'];
const EYE = ['#ff4d6d', '#9c2a3a', '#5e1f33'];
const PORTAL = ['#2f8f9a', '#6fe3d2', '#e9fffb', '#6fe3d2', '#7b5cd6', '#4b3a8f'];
const TITLE_COLS = ['#fff1c2', '#ffd15c', '#ffd15c', '#ff9a3c', '#e8552d'];
const TIPS = ['THE DARK GROWS HUNGRIER', 'BRAZIERS ARE SAFE HAVENS', 'DASH THROUGH DANGER', 'SHADES FEAR THE LIGHT'];
const FLICK = [0, 1, 2, 1];
const EMBER_SEQ = [0, 2, 1, 2];

const MAX_SPEED = PLAYER_SPEED;
const DASH_SPEED = 235;
const DASH_TIME = 0.15;
const DASH_CD = 0.75;
const FLARE_CD = 0.9;
/** Presses made slightly too early are remembered for this long. */
const BUFFER = 0.18;
const JOY_R = 22;
const JOY_R_STATIC = 29;
const HEAD_W = 13;
const HEAD_H = 10;
/** An octopus is painted on its own small layer: its tile and the eight around it. */
const OL = TILE * 3;
const OC = OL >> 1;
/** Where the surface cuts across the head: low in the tile once it has a catch, mid-tile while it peeks. */
const WL = OC + 6;
const WL_LURK = OC + 4;
/** Rows of head it shows while holding the emberling. */
const GRAB_RISE = 6;
/** Seconds its ink hangs in the water. */
const INK_T = 0.9;
const OCTO_D = '#45143b';
const OCTO_M = '#b8437f';
const OCTO_L = '#eb77a8';
const OCTO_H = '#ffd1e3';
const CAMO_D = '#132744';
const CAMO_M = '#234b76';
const CAMO_L = '#2e6396';
const CAMO_H = '#6fb6e0';
const SUB_ARM = '#16314f';
const FOAM = '#e9fffb';
const OCTO_EYE = '#fff1c2';
const OCTO_PUPIL = '#17122e';
const OCTO_INK = ['#6a1b4a', '#45143b', '#2b1030'];
const BOOK_GLOW = ['#fff1c2', '#6fe3d2', '#2f8f9a'];
const BUBBLE = ['#e9fffb', '#6fb6e0', '#2e6396'];
const MAX_LIGHTS = 96;
/** Screens faster than about 95 Hz are throttled: simulating every refresh only burns battery. */
const MIN_FRAME_MS = 10.5;
const RING_X: number[] = [];
const RING_Y: number[] = [];
for (let i = 0; i < 12; i++) {
  RING_X.push(Math.cos((i / 12) * Math.PI * 2));
  RING_Y.push(Math.sin((i / 12) * Math.PI * 2));
}
const SPAWN_T = 0.45;
const BURN_T = 0.45;
const RISE_T = 0.6;
const T_CLOSE = 0.45;
const T_HOLD = 0.8;
const T_OPEN = 0.45;
const AWARE = 15;
const FAR = 32767;

const BAYER = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5];
const BAYER_T = BAYER.map((v) => Math.round(((v + 0.5) / 16) * 255));
const pack = (r: number, g: number, b: number, a: number) => ((a << 24) | (b << 16) | (g << 8) | r) >>> 0;
const DARK_FULL = pack(7, 6, 22, 255);
const DARK_SEEN = pack(7, 6, 22, 150);
const DARK_1 = pack(7, 6, 22, 110);
const DARK_2 = pack(7, 6, 22, 58);
const WARM = pack(255, 176, 96, 34);
const LEVEL_COL = new Uint32Array([0, DARK_1, DARK_2, WARM]);
/** Brightness (0-255) x Bayer cell (0-15) -> light level 0-3, so the per-pixel pass is one table lookup. */
const DITHER = new Uint8Array(256 * 16);
for (let b = 1; b < 256; b++) {
  for (let j = 0; j < 16; j++) DITHER[(b << 4) | j] = Math.min(3, ((b * 3 + BAYER_T[j]) / 255) | 0);
}

const rnd = (a: number, b: number) => a + Math.random() * (b - a);
const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
const easeOut = (t: number) => 1 - (1 - t) * (1 - t) * (1 - t);
const easeOutBack = (t: number) => {
  const u = t - 1;
  return 1 + 2.70158 * u * u * u + 1.70158 * u * u;
};

export function createGame(canvas: HTMLCanvasElement, opts: GameOptions = {}): GameHandle {
  const ctx = canvas.getContext('2d', { alpha: false }) as CanvasRenderingContext2D;
  const S = buildSprites();
  const sfx = new Sfx();
  const mq = (q: string) => (typeof window.matchMedia === 'function' ? window.matchMedia(q).matches : false);
  const reduceMotion = mq('(prefers-reduced-motion: reduce)');
  let inputMode: InputMode = mq('(pointer: coarse)') ? 'touch' : 'keys';

  // Reads the device safe-area insets (notches, home indicators).
  const probe = document.createElement('div');
  probe.style.cssText =
    'position:fixed;left:0;top:0;width:0;height:0;visibility:hidden;pointer-events:none;' +
    'padding:env(safe-area-inset-top) env(safe-area-inset-right) env(safe-area-inset-bottom) env(safe-area-inset-left)';
  document.body.appendChild(probe);

  // The emberling is composed here each frame, then squashed and stretched onto the screen.
  const pc = document.createElement('canvas');
  pc.width = 24;
  pc.height = 24;
  const pctx = pc.getContext('2d') as CanvasRenderingContext2D;

  const checker = document.createElement('canvas');
  checker.width = 2;
  checker.height = 2;
  const chk = checker.getContext('2d') as CanvasRenderingContext2D;
  chk.fillStyle = '#e8552d';
  chk.fillRect(0, 0, 1, 1);
  chk.fillRect(1, 1, 1, 1);
  const hitPattern = ctx.createPattern(checker, 'repeat');

  // distance and angle of every doorway pixel from its centre, for the portal swirl
  const gateD = S.gateMask.map((p) => Math.hypot(p.x - 9.5, p.y - 11));
  const gateA = S.gateMask.map((p) => Math.atan2(p.y - 11, p.x - 9.5));

  // ------------------------------------------------------------------ view
  let VW = 240;
  let VH = 160;
  let scale = 3;
  const safe = { t: 0, r: 0, b: 0, l: 0 };
  const lightCanvas = document.createElement('canvas');
  const lightCtx = lightCanvas.getContext('2d') as CanvasRenderingContext2D;
  let lightImg: ImageData = lightCtx.createImageData(1, 1);
  let light32 = new Uint32Array(lightImg.data.buffer);
  let bright = new Uint8Array(1);
  let colTx = new Int16Array(1);

  function resize(): void {
    const W = Math.max(1, window.innerWidth);
    const H = Math.max(1, window.innerHeight);
    scale = Math.max(1, Math.round(Math.sqrt((W * H) / 38000)));
    VW = Math.ceil(W / scale);
    VH = Math.ceil(H / scale);
    canvas.width = VW;
    canvas.height = VH;
    canvas.style.width = VW * scale + 'px';
    canvas.style.height = VH * scale + 'px';
    ctx.imageSmoothingEnabled = false;
    lightCanvas.width = VW;
    lightCanvas.height = VH;
    lightImg = lightCtx.createImageData(VW, VH);
    light32 = new Uint32Array(lightImg.data.buffer);
    bright = new Uint8Array(VW * VH);
    colTx = new Int16Array(VW);
    const cs = getComputedStyle(probe);
    const inset = (v: string) => Math.ceil((parseFloat(v) || 0) / scale);
    safe.t = inset(cs.paddingTop);
    safe.r = inset(cs.paddingRight);
    safe.b = inset(cs.paddingBottom);
    safe.l = inset(cs.paddingLeft);
    dirty = true;
  }

  // ----------------------------------------------------------------- state
  let state: State = 'title';
  let settingsFrom: 'title' | 'pause' = 'title';
  let settingsIdx = 0;
  let pauseIdx = 0;
  let staticJoy = false;
  let joyScale = 1.0;
  let depth = 1;
  let embersTotal = 0;
  let best = 0;
  let newBest = false;
  try {
    best = parseInt(localStorage.getItem('emberling_best') || '0', 10) || 0;
    staticJoy = localStorage.getItem('emberling_static_joy') === '1';
    const js = parseFloat(localStorage.getItem('emberling_joy_scale') || '1');
    if (js >= 0.8 && js <= 1.5) joyScale = js;
  } catch {
    /* storage unavailable */
  }

  // Admin state & debug toggles
  let adminOpen = false;
  let adminModalLock = false;
  let pauseOnAdmin = true;
  let showHudAdmin = false;
  let godMode = false;
  let noCooldowns = false;
  let fullBright = false;
  let revealMap = false;
  let freezeEnemies = false;
  let revealOctos = false;
  let speedMult = 1.0;
  let forcedInput: ForcedInput = 'auto';
  let fpsAvg = 60;
  let fpsCount = 0;
  let fpsTimer = 0;
  let noClip = false;
  let noBurn = false;
  let lightMult = 1;
  let timeScale = 1;
  /** Frames the admin panel has asked to advance while the game is held. */
  let stepQueue = 0;
  let debugHud = false;
  let hitboxes = false;
  let haptics = true;
  let deadzone = 0.18;
  /** Admin override for the three-in-a-puddle odds; -1 leaves the game's own. */
  let trioChance = -1;
  let packSeq = 1;
  /** Admin overlay: tints the stencil that every octopus is cut to. */
  let showMask = false;
  /** The guide book on its lectern, in pixels; null on every depth but one. */
  let book: { x: number; y: number } | null = null;
  let nearBook = false;
  let guideOpen = false;
  let inks: Ink[] = [];

  let level: Level;
  let explored = new Uint8Array(1);
  let flow = new Int16Array(1);
  let bfsQ = new Int32Array(1);
  let flowT = 0;
  let revealT = 0;

  const player = {
    x: 0,
    y: 0,
    vx: 0,
    vy: 0,
    /** Smoothed real horizontal speed; bends the flame. */
    avx: 0,
    fuel: 80,
    inv: 0,
    hurtT: 0,
    happyT: 0,
    flareCd: 0,
    dashCd: 0,
    dashT: 0,
    dashX: 0,
    dashY: 1,
    fx: 0,
    fy: 1,
    moving: false,
    hop: 0,
    hopH: 0,
    /** Squash and stretch spring. */
    sq: 0,
    sqV: 0,
    scale: 0,
    spawnT: 0,
    tier: 0,
    dead: false,
    deathT: 0,
    poofed: false,
    wet: false,
    lowT: 0,
  };
  const gate = { x: 0, y: 0 };
  let gateOpen = false;
  let gateT = 0;
  let gateHintT = 0;
  let litCount = 0;
  let shades: Shade[] = [];
  let moths: Moth[] = [];
  let octos: Octo[] = [];
  let grabOcto: Octo | null = null;
  let embers: Ember[] = [];
  let braziers: Brazier[] = [];
  let parts: Particle[] = [];
  let floaters: Floater[] = [];
  let flares: Flare[] = [];
  let fxs: Fx[] = [];
  let ghosts: Ghost[] = [];
  let ghostT = 0;
  const lightX = new Float32Array(MAX_LIGHTS);
  const lightY = new Float32Array(MAX_LIGHTS);
  const lightR = new Float32Array(MAX_LIGHTS);
  const lightK = new Float32Array(MAX_LIGHTS);
  let lightN = 0;
  /** Set when something on a menu screen changes, so idle menus are not redrawn every frame. */
  let dirty = true;

  let time = 0;
  let camX = 0;
  let camY = 0;
  /** The camera offset the last frame was actually drawn with, screen shake included. */
  let drawnX = 0;
  let drawnY = 0;
  let shake = 0;
  let hitFlash = 0;
  let lightKick = 0;
  let lightFuel = 80;
  let fuelShown = 80;
  let fuelGhost = 80;
  let fuelLast = 80;
  let ghostHold = 0;
  let gainFlash = 0;
  let hudShake = 0;
  const toast = { text: '', t: 0, age: 0 };
  let toastQ: string[] = [];
  const trans = { t: 0, swapped: false, opened: false };

  // ----------------------------------------------------------------- input
  const keys = new Set<string>();
  const joy = { active: false, id: -1, ox: 0, oy: 0, dx: 0, dy: 0, kx: 0, ky: 0 };
  const mouse = { down: false, x: 0, y: 0 };
  const pad = { x: 0, y: 0, a: false, b: false, start: false };
  let padLive = false;
  let padProbe = 0;
  let inX = 0;
  let inY = 0;
  let flareBuf = 0;
  let dashBuf = 0;
  let flarePressT = 0;
  let dashPressT = 0;

  // --------------------------------------------------------------- helpers
  function say(text: string, t = 2.6): void {
    toast.text = text;
    toast.t = t;
    toast.age = 0;
    toastQ = [];
  }

  function sayAll(list: string[]): void {
    say(list[0], 3.2);
    toastQ = list.slice(1);
  }

  function tileAt(px: number, py: number): number {
    const tx = Math.floor(px / TILE);
    const ty = Math.floor(py / TILE);
    if (tx < 0 || ty < 0 || tx >= level.w || ty >= level.h) return T_WALL;
    return level.tiles[ty * level.w + tx];
  }

  function boxHits(x: number, y: number): boolean {
    return (
      tileAt(x - 3.5, y - 2) === T_WALL ||
      tileAt(x + 3.5, y - 2) === T_WALL ||
      tileAt(x - 3.5, y + 4) === T_WALL ||
      tileAt(x + 3.5, y + 4) === T_WALL
    );
  }

  /** Roughly on screen: effects further away than this are never seen, so they are skipped. */
  function nearView(x: number, y: number): boolean {
    return Math.abs(x - player.x) < VW && Math.abs(y - player.y) < VH;
  }

  function spawn(x: number, y: number, vx: number, vy: number, life: number, ramp: string[], g = 0, big = false): void {
    if (parts.length > 460 || !nearView(x, y)) return;
    parts.push({ x, y, vx, vy, life, max: life, ramp, g, big });
  }

  function burst(x: number, y: number, n: number, ramp: string[], speed: number): void {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const s = rnd(speed * 0.3, speed);
      spawn(x, y, Math.cos(a) * s, Math.sin(a) * s, rnd(0.25, 0.7), ramp, 30);
    }
  }

  function floater(x: number, y: number, text: string, color: string): void {
    floaters.push({ x, y, text, color, t: 0.9 });
  }

  function addFx(frames: Sprite[], x: number, y: number, dur: number, glow: boolean): void {
    fxs.push({ x, y, frames, t: 0, dur, glow });
  }

  function vibrate(ms: number): void {
    if (!haptics) return;
    try {
      if (typeof navigator.vibrate === 'function') navigator.vibrate(ms);
    } catch {
      /* not supported */
    }
  }

  function tierOf(): number {
    if (player.dead) return 2;
    return player.fuel >= 60 ? 0 : player.fuel >= 25 ? 1 : 2;
  }

  /** Recently hurt, mid-dash, or in the brief grace window right after a dash. */
  function untouchable(): boolean {
    return player.inv > 0 || player.dashT > 0 || player.dashCd > DASH_CD - DASH_TIME - 0.12;
  }

  function joyR(): number {
    return Math.round((staticJoy ? JOY_R_STATIC : JOY_R) * joyScale);
  }

  function setStaticJoy(v: boolean): void {
    staticJoy = v;
    joy.active = false;
    joy.dx = 0;
    joy.dy = 0;
    joy.kx = 0;
    joy.ky = 0;
    dirty = true;
    try {
      localStorage.setItem('emberling_static_joy', v ? '1' : '0');
    } catch {
      /* storage unavailable */
    }
  }

  function setJoyScale(v: number): void {
    joyScale = clamp(Math.round(v * 20) / 20, 0.85, 1.35);
    dirty = true;
    try {
      localStorage.setItem('emberling_joy_scale', String(joyScale));
    } catch {
      /* storage unavailable */
    }
  }

  function playerRadius(): number {
    if (player.dead) return Math.max(0, 22 * (1 - player.deathT / 0.7));
    const flick = reduceMotion ? 0 : Math.sin(time * 13) * 0.8 + Math.sin(time * 7.3) * 0.7;
    return (18 + lightFuel * 0.58 + flick + lightKick) * (0.25 + 0.75 * Math.min(1, player.scale)) * lightMult;
  }

  function inBrazierLight(x: number, y: number): boolean {
    const r2 = BRAZIER_R * 0.8 * (BRAZIER_R * 0.8);
    for (const b of braziers) {
      if (!b.lit) continue;
      const dx = b.x - x;
      const dy = b.y - 4 - y;
      if (dx * dx + dy * dy < r2) return true;
    }
    return false;
  }

  function reveal(x: number, y: number, r: number): void {
    const x0 = Math.max(0, Math.floor((x - r) / TILE));
    const x1 = Math.min(level.w - 1, Math.floor((x + r) / TILE));
    const y0 = Math.max(0, Math.floor((y - r) / TILE));
    const y1 = Math.min(level.h - 1, Math.floor((y + r) / TILE));
    const rr = (r + 4) * (r + 4);
    for (let ty = y0; ty <= y1; ty++) {
      for (let tx = x0; tx <= x1; tx++) {
        const dx = tx * TILE + 8 - x;
        const dy = ty * TILE + 8 - y;
        if (dx * dx + dy * dy < rr) explored[ty * level.w + tx] = 1;
      }
    }
  }

  function dropEmber(x: number, y: number, v: number): void {
    let ex = x;
    let ey = y;
    if (tileAt(x, y) === T_WALL) {
      const tx = Math.floor(x / TILE);
      const ty = Math.floor(y / TILE);
      let bd = Infinity;
      let found = false;
      for (let oy = -2; oy <= 2; oy++) {
        for (let ox = -2; ox <= 2; ox++) {
          const cx = (tx + ox) * TILE + 8;
          const cy = (ty + oy) * TILE + 8;
          if (tileAt(cx, cy) === T_WALL) continue;
          const d = (cx - x) * (cx - x) + (cy - y) * (cy - y);
          if (d < bd) {
            bd = d;
            ex = cx;
            ey = cy;
            found = true;
          }
        }
      }
      if (!found) return;
    }
    // freshly dropped embers pop into the air and bounce
    embers.push({ x: ex, y: ey, v, ph: Math.random() * 6, z: 2, vz: 85 });
  }

  function cameraTarget(): { x: number; y: number } {
    const mw = level.w * TILE;
    const mh = level.h * TILE;
    // look slightly ahead of where the emberling is heading
    let tx = player.x + clamp(player.vx * 0.16, -12, 12) - VW / 2;
    let ty = player.y - 4 + clamp(player.vy * 0.16, -12, 12) - VH / 2;
    tx = mw <= VW ? (mw - VW) / 2 : clamp(tx, 0, mw - VW);
    ty = mh <= VH ? (mh - VH) / 2 : clamp(ty, 0, mh - VH);
    return { x: tx, y: ty };
  }

  // ---------------------------------------------------------------- levels
  function loadLevel(d: number): void {
    level = generateLevel(d, (Math.random() * 0x7fffffff) | 0, trioChance < 0 ? undefined : trioChance);
    packSeq = 1;
    const n = level.w * level.h;
    explored = new Uint8Array(n);
    flow = new Int16Array(n).fill(FAR);
    bfsQ = new Int32Array(n);
    player.x = level.start.x * TILE + 8;
    player.y = level.start.y * TILE + 8;
    player.vx = 0;
    player.vy = 0;
    player.avx = 0;
    player.inv = 0;
    player.hurtT = 0;
    player.happyT = 0;
    player.flareCd = 0;
    player.dashCd = 0;
    player.dashT = 0;
    player.hop = 0;
    player.hopH = 0;
    player.sq = 0;
    player.sqV = 0;
    player.scale = 0;
    player.spawnT = SPAWN_T;
    player.dead = false;
    player.deathT = 0;
    player.poofed = false;
    player.wet = false;
    player.tier = tierOf();
    lightFuel = Math.max(0, player.fuel);
    gate.x = level.exit.x * TILE + 8;
    gate.y = level.exit.y * TILE + 8;
    gateOpen = false;
    gateT = 0;
    litCount = 0;
    braziers = level.braziers.map((b): Brazier => ({ x: b.x * TILE + 8, y: b.y * TILE + 9, lit: false, litT: 0 }));
    embers = level.embers.map(
      (e): Ember => ({ x: e.x * TILE + 8, y: e.y * TILE + 8, v: 10, ph: Math.random() * 6, z: 0, vz: 0 }),
    );
    shades = level.shades.map((s): Shade => {
      const x = s.x * TILE + 8;
      const y = s.y * TILE + 8;
      return {
        x,
        y,
        vx: 0,
        vy: 0,
        state: 'idle',
        t: 0,
        ph: Math.random() * 6,
        lit: false,
        tx: x,
        ty: y,
        wait: rnd(0, 2),
        rise: 0,
        alert: 0,
      };
    });
    moths = level.moths.map((m): Moth => {
      const x = m.x * TILE + 8;
      const y = m.y * TILE + 8;
      return { x, y, vx: 0, vy: 0, hx: x, hy: y, ph: Math.random() * 6, seed: Math.random() * 6, flee: 0, carry: false };
    });
    octos = level.octos.map((o) => makeOcto(o.x * TILE + 8, o.y * TILE + 8, o.pack));
    grabOcto = null;
    inks = [];
    book = level.book ? { x: level.book.x * TILE + 8, y: level.book.y * TILE + 9 } : null;
    nearBook = false;
    parts = [];
    floaters = [];
    flares = [];
    fxs = [];
    ghosts = [];
    flowT = 0;
    revealT = 0;
    flareBuf = 0;
    dashBuf = 0;
    const c = cameraTarget();
    camX = c.x;
    camY = c.y;
    if (revealMap) explored.fill(1);
    else reveal(player.x, player.y, 18 + Math.max(0, player.fuel) * 0.58);
  }

  function levelIntro(): void {
    if (book) {
      say('A GUIDE BOOK RESTS NEARBY - GO AND READ IT', 4);
      return;
    }
    const pack = octos.some((o) => o.pack > 0);
    if (depth === 6) {
      sayAll(pack ? ['WATCH WATER FOR OCTOPUS', 'A PACK OF THREE SHARES ONE POOL'] : ['WATCH WATER FOR OCTOPUS']);
      return;
    }
    if (depth !== 1) {
      if (pack) say('A PACK OF THREE SHARES ONE POOL', 3.2);
      return;
    }
    const mode = activeMode();
    if (mode === 'touch') {
      const moveMsg = staticJoy ? 'USE THE STICK TO MOVE' : 'DRAG ANYWHERE TO MOVE';
      sayAll([moveMsg, 'FOLLOW THE ARROW TO A BRAZIER', 'FLARE BURNS SHADES - DASH SLIPS PAST']);
    } else if (mode === 'pad') {
      sayAll(['FOLLOW THE ARROW TO A BRAZIER', 'A TO FLARE - B TO DASH']);
    } else {
      sayAll(['FOLLOW THE ARROW TO A BRAZIER', 'SPACE TO FLARE - SHIFT TO DASH']);
    }
  }

  function startRun(): void {
    depth = 1;
    embersTotal = 0;
    newBest = false;
    player.fuel = 80;
    if (state !== 'title') loadLevel(1);
    else player.sq = 0.3;
    state = 'play';
    flareBuf = 0;
    dashBuf = 0;
    sfx.startMusic();
    levelIntro();
  }

  function die(): void {
    player.dead = true;
    player.deathT = 0;
    player.poofed = false;
    player.fuel = 0;
    player.dashT = 0;
    player.hurtT = 0.4;
    grabOcto = null;
    state = 'over';
    joy.active = false;
    mouse.down = false;
    hitFlash = 0.25;
    sfx.stopMusic();
    sfx.over();
    vibrate(120);
    if (depth > best) {
      best = depth;
      newBest = true;
      try {
        localStorage.setItem('emberling_best', String(best));
      } catch {
        /* storage unavailable */
      }
    }
  }

  function setPaused(p: boolean): void {
    if (p && state === 'play') {
      state = 'pause';
      pauseIdx = 0;
      joy.active = false;
      mouse.down = false;
      keys.clear();
      sfx.stopMusic();
    } else if (!p && state === 'pause') {
      state = 'play';
      sfx.startMusic();
    }
  }

  function openSettings(from: 'title' | 'pause'): void {
    settingsFrom = from;
    settingsIdx = 0;
    state = 'settings';
    keys.clear();
    joy.active = false;
    mouse.down = false;
    dirty = true;
  }

  function closeSettings(): void {
    state = settingsFrom;
    pauseIdx = 0;
    dirty = true;
  }

  function applyAdminOpen(open: boolean): void {
    adminOpen = open;
    adminModalLock = open;
    joy.active = false;
    mouse.down = false;
    keys.clear();
    stepQueue = 0;
    if (open) {
      // the panel brings its own pause, so the menus underneath step aside
      if (state === 'settings') state = settingsFrom === 'title' ? 'title' : 'play';
      else if (state === 'pause') state = 'play';
    } else if (state === 'play') {
      sfx.startMusic();
    }
    dirty = true;
  }

  function setAdminVisible(open: boolean): void {
    applyAdminOpen(open);
    opts.onAdminChange?.(open);
  }

  function triggerOpenAdmin(): void {
    setAdminVisible(true);
  }

  function activateSettings(idx: number): void {
    if (idx === 0) {
      setStaticJoy(!staticJoy);
      sfx.pickup();
    } else if (idx === 1) {
      sfx.setMuted(!sfx.muted);
      if (!sfx.muted) sfx.pickup();
    } else if (idx === 2) {
      triggerOpenAdmin();
    } else {
      closeSettings();
    }
  }

  function openGuide(): void {
    if (guideOpen) return;
    guideOpen = true;
    joy.active = false;
    mouse.down = false;
    keys.clear();
    flareBuf = 0;
    dashBuf = 0;
    sfx.page();
    dirty = true;
    opts.onGuideChange?.(true);
  }

  function closeGuide(): void {
    if (!guideOpen) return;
    guideOpen = false;
    keys.clear();
    sfx.page();
    dirty = true;
    opts.onGuideChange?.(false);
  }

  function pressFlare(): void {
    // standing at the lectern, the action button reads the book instead of flaring
    if (nearBook && state === 'play' && !player.dead) {
      openGuide();
      return;
    }
    flareBuf = BUFFER;
    flarePressT = 0.15;
  }

  function pressDash(): void {
    dashBuf = BUFFER;
    dashPressT = 0.15;
  }

  function action(): void {
    if (state === 'title') startRun();
    else if (state === 'over') {
      if (player.deathT > 1) startRun();
    } else if (state === 'pause') {
      if (pauseIdx === 1) openSettings('pause');
      else if (pauseIdx === 2) triggerOpenAdmin();
      else setPaused(false);
    } else if (state === 'settings') {
      activateSettings(settingsIdx);
    } else if (state === 'play') pressFlare();
  }

  // ----------------------------------------------------------------- input
  function pollPad(dt: number): void {
    if (typeof navigator.getGamepads !== 'function') return;
    if (!padLive) {
      // nothing plugged in: look again once a second instead of every frame
      padProbe -= dt;
      if (padProbe > 0) return;
      padProbe = 1;
    }
    let found: Gamepad | null = null;
    try {
      const list = navigator.getGamepads();
      for (let i = 0; i < list.length; i++) {
        const g = list[i];
        if (g && g.connected) {
          found = g;
          break;
        }
      }
    } catch {
      return;
    }
    if (!found) {
      padLive = false;
      pad.x = 0;
      pad.y = 0;
      pad.a = false;
      pad.b = false;
      pad.start = false;
      return;
    }
    const gp = found;
    padLive = true;
    const down = (i: number) => i < gp.buttons.length && gp.buttons[i].pressed;
    let x = gp.axes.length > 0 ? gp.axes[0] : 0;
    let y = gp.axes.length > 1 ? gp.axes[1] : 0;
    if (down(14)) x = -1;
    if (down(15)) x = 1;
    if (down(12)) y = -1;
    if (down(13)) y = 1;
    const len = Math.hypot(x, y);
    if (len < 0.25) {
      x = 0;
      y = 0;
    } else {
      const m = Math.min(1, (len - 0.25) / 0.6);
      x = (x / len) * m;
      y = (y / len) * m;
      inputMode = 'pad';
    }
    const prevX = pad.x;
    const prevY = pad.y;
    pad.x = x;
    pad.y = y;
    const a = down(0);
    const b = down(1) || down(2);
    const st = down(9);
    if (guideOpen) {
      // the book has the pad: left and right turn the page, any button shuts it
      if (Math.abs(x) > 0.6 && Math.abs(prevX) <= 0.6) opts.onGuidePage?.(x > 0 ? 1 : -1);
      if ((a && !pad.a) || (b && !pad.b) || (st && !pad.start)) closeGuide();
      pad.a = a;
      pad.b = b;
      pad.start = st;
      return;
    }
    if ((a && !pad.a) || (b && !pad.b) || (st && !pad.start)) dirty = true;
    if (a && !pad.a) {
      inputMode = 'pad';
      sfx.init();
      action();
    }
    if (b && !pad.b) {
      inputMode = 'pad';
      if (state === 'play') pressDash();
      else if (state === 'settings') closeSettings();
    }
    if (st && !pad.start) {
      if (state === 'play') setPaused(true);
      else if (state === 'pause') setPaused(false);
      else if (state === 'settings') closeSettings();
    }
    if ((state === 'settings' || state === 'pause') && Math.abs(y) > 0.6 && Math.abs(prevY) <= 0.6) {
      dirty = true;
      const dir = y > 0 ? 1 : -1;
      if (state === 'settings') settingsIdx = (settingsIdx + dir + 4) % 4;
      else pauseIdx = (pauseIdx + dir + 3) % 3;
    }
    pad.a = a;
    pad.b = b;
    pad.start = st;
  }

  function readInput(): void {
    let x = 0;
    let y = 0;
    if (keys.has('ArrowLeft') || keys.has('KeyA')) x -= 1;
    if (keys.has('ArrowRight') || keys.has('KeyD')) x += 1;
    if (keys.has('ArrowUp') || keys.has('KeyW')) y -= 1;
    if (keys.has('ArrowDown') || keys.has('KeyS')) y += 1;
    if (joy.active) {
      x += joy.dx;
      y += joy.dy;
    }
    if (mouse.down) {
      // holding the mouse button walks the emberling toward the cursor
      const dx = mouse.x + camX - player.x;
      const dy = mouse.y + camY + 2 - player.y;
      const d = Math.hypot(dx, dy);
      if (d > 3) {
        const m = Math.min(1, d / 16);
        x += (dx / d) * m;
        y += (dy / d) * m;
      }
    }
    x += pad.x;
    y += pad.y;
    const len = Math.hypot(x, y);
    if (len > 1) {
      x /= len;
      y /= len;
    }
    inX = x;
    inY = y;
  }

  /** When a move is blocked by a tile corner, slide around it instead of snagging. */
  function slip(dx: number, dy: number, s: number): void {
    for (let n = 1; n <= 6; n++) {
      for (let sign = -1; sign <= 1; sign += 2) {
        const ox = dy !== 0 ? sign * n : 0;
        const oy = dx !== 0 ? sign * n : 0;
        if (boxHits(player.x + ox + dx, player.y + oy + dy)) continue;
        const st = Math.min(n, s);
        const nx = player.x + (dy !== 0 ? sign * st : 0);
        const ny = player.y + (dx !== 0 ? sign * st : 0);
        if (!boxHits(nx, ny)) {
          player.x = nx;
          player.y = ny;
        }
        return;
      }
    }
  }

  function stepMove(dx: number, dy: number): void {
    if (noClip) {
      // admin: drift straight through the rock, but never off the map
      player.x = clamp(player.x + dx, 20, level.w * TILE - 20);
      player.y = clamp(player.y + dy, 20, level.h * TILE - 20);
      return;
    }
    if (dx !== 0) {
      if (!boxHits(player.x + dx, player.y)) player.x += dx;
      else if (Math.abs(dy) < Math.abs(dx) * 0.6) slip(dx, 0, Math.abs(dx));
    }
    if (dy !== 0) {
      if (!boxHits(player.x, player.y + dy)) player.y += dy;
      else if (Math.abs(dx) < Math.abs(dy) * 0.6) slip(0, dy, Math.abs(dy));
    }
  }

  function doFlare(): void {
    if (godMode || noCooldowns || player.fuel > FLARE_COST + 4) {
      if (!godMode && !noCooldowns) player.fuel -= FLARE_COST;
      player.flareCd = noCooldowns ? 0 : FLARE_CD;
      player.sq = 0.3;
      lightKick = 6;
      flares.push({ x: player.x, y: player.y - 3, t: 0, r: 0 });
      sfx.flare();
      vibrate(12);
      if (!reduceMotion) shake = 3;
      burst(player.x, player.y - 4, 16, FIRE, 70);
      reveal(player.x, player.y, FLARE_R + 20);
    } else {
      sfx.deny();
      floater(player.x, player.y - 16, 'TOO DIM', '#9a9fb8');
      player.flareCd = 0.3;
    }
  }

  function doDash(): void {
    if (!godMode && !noCooldowns && player.fuel <= DASH_COST + 2) {
      sfx.deny();
      floater(player.x, player.y - 16, 'TOO DIM', '#9a9fb8');
      player.dashCd = 0.3;
      return;
    }
    const mag = Math.hypot(inX, inY);
    if (mag > 0.05) {
      player.dashX = inX / mag;
      player.dashY = inY / mag;
    } else {
      player.dashX = player.fx;
      player.dashY = player.fy;
    }
    if (!godMode && !noCooldowns) player.fuel -= DASH_COST;
    player.dashT = DASH_TIME;
    player.dashCd = noCooldowns ? 0 : DASH_CD;
    player.sq = 0.2;
    ghostT = 0;
    sfx.dash();
    vibrate(8);
    for (let i = 0; i < 8; i++) {
      spawn(
        player.x,
        player.y - 3,
        -player.dashX * rnd(20, 70) + rnd(-18, 18),
        -player.dashY * rnd(20, 70) + rnd(-18, 18),
        rnd(0.2, 0.45),
        FIRE,
      );
    }
  }

  // ---------------------------------------------------------------- update
  function computeFlow(): void {
    flow.fill(FAR);
    const w = level.w;
    const s = Math.floor(player.y / TILE) * w + Math.floor(player.x / TILE);
    let head = 0;
    let tail = 0;
    bfsQ[tail++] = s;
    flow[s] = 0;
    const tiles = level.tiles;
    while (head < tail) {
      const c = bfsQ[head++];
      const d = flow[c] + 1;
      if (d > 26) continue;
      let n = c - 1;
      if (tiles[n] !== T_WALL && flow[n] === FAR) {
        flow[n] = d;
        bfsQ[tail++] = n;
      }
      n = c + 1;
      if (tiles[n] !== T_WALL && flow[n] === FAR) {
        flow[n] = d;
        bfsQ[tail++] = n;
      }
      n = c - w;
      if (tiles[n] !== T_WALL && flow[n] === FAR) {
        flow[n] = d;
        bfsQ[tail++] = n;
      }
      n = c + w;
      if (tiles[n] !== T_WALL && flow[n] === FAR) {
        flow[n] = d;
        bfsQ[tail++] = n;
      }
    }
  }

  function igniteShade(s: Shade): void {
    s.state = 'burn';
    s.t = BURN_T;
    sfx.burn();
  }

  function placeShadeFar(s: Shade): void {
    const w = level.w;
    for (let tries = 0; tries < 60; tries++) {
      const tx = 1 + ((Math.random() * (w - 2)) | 0);
      const ty = 1 + ((Math.random() * (level.h - 2)) | 0);
      if (level.tiles[ty * w + tx] === T_WALL) continue;
      const x = tx * TILE + 8;
      const y = ty * TILE + 8;
      const dx = x - player.x;
      const dy = y - player.y;
      if (dx * dx + dy * dy < 150 * 150 && tries < 50) continue;
      if (inBrazierLight(x, y)) continue;
      s.x = s.tx = x;
      s.y = s.ty = y;
      return;
    }
  }

  function bite(s: Shade): void {
    if (godMode) return;
    player.fuel -= SHADE_BITE;
    player.inv = 1.1;
    player.hurtT = 0.36;
    player.sq = -0.3;
    const dx = player.x - s.x;
    const dy = player.y - s.y;
    const d = Math.hypot(dx, dy) || 1;
    player.vx += (dx / d) * 150;
    player.vy += (dy / d) * 150;
    hitFlash = 0.25;
    hudShake = 0.3;
    if (!reduceMotion) shake = 5;
    sfx.hurt();
    vibrate(45);
    floater(player.x, player.y - 16, '-' + SHADE_BITE, '#ff4d6d');
    burst(s.x, s.y - 4, 12, SHADOW, 50);
    addFx(S.poofShade, s.x, s.y - 4, 0.3, true);
    s.state = 'gone';
    s.t = 3.5;
  }

  function updateShades(dt: number): void {
    const pr = playerRadius() * 0.8;
    const w = level.w;
    const tiles = level.tiles;
    const speed = shadeSpeed(depth);
    for (let i = shades.length - 1; i >= 0; i--) {
      const s = shades[i];
      s.ph += dt;
      if (s.alert > 0) s.alert -= dt;
      if (s.state === 'gone') {
        s.t -= dt;
        if (s.t <= 0) {
          placeShadeFar(s);
          s.state = 'idle';
          s.rise = RISE_T;
          s.vx = 0;
          s.vy = 0;
        }
        continue;
      }
      if (s.state === 'burn') {
        s.t -= dt;
        if (Math.random() < dt * 50) {
          spawn(s.x + rnd(-5, 5), s.y - 4 + rnd(-6, 5), rnd(-10, 10), rnd(-34, -10), rnd(0.3, 0.6), Math.random() < 0.5 ? FIRE : SHADOW);
        }
        if (s.t <= 0) {
          dropEmber(s.x, s.y, SHADE_EMBER);
          burst(s.x, s.y - 4, 10, FIRE, 40);
          addFx(S.poofFire, s.x, s.y - 4, 0.3, true);
          shades.splice(i, 1);
        }
        continue;
      }
      if (s.rise > 0) {
        s.rise -= dt;
        continue;
      }
      if (inBrazierLight(s.x, s.y)) {
        igniteShade(s);
        continue;
      }
      const x0 = s.x;
      const y0 = s.y;
      const dx = player.x - s.x;
      const dy = player.y - s.y;
      const d = Math.hypot(dx, dy);
      s.lit = !player.dead && d < pr;
      const tx = Math.floor(s.x / TILE);
      const ty = Math.floor(s.y / TILE);
      const fd = flow[ty * w + tx];
      let gx = s.tx;
      let gy = s.ty;
      let sp = 0;
      if (player.dead) {
        gx = player.x;
        gy = player.y;
        sp = d > 12 ? 30 : 0;
      } else if (fd < AWARE) {
        if (s.state !== 'hunt') s.alert = 0.3;
        s.state = 'hunt';
        sp = s.lit ? SHADE_SPEED_LIT : speed;
        if (fd <= 1) {
          gx = player.x;
          gy = player.y;
        } else {
          let bx = tx;
          let by = ty;
          let bd = fd;
          for (let oy = -1; oy <= 1; oy++) {
            for (let ox = -1; ox <= 1; ox++) {
              if (!ox && !oy) continue;
              const nx = tx + ox;
              const ny = ty + oy;
              const nd = flow[ny * w + nx];
              if (nd >= bd) continue;
              if (ox && oy && (tiles[ty * w + nx] === T_WALL || tiles[ny * w + tx] === T_WALL)) continue;
              bd = nd;
              bx = nx;
              by = ny;
            }
          }
          gx = bx * TILE + 8;
          gy = by * TILE + 8;
        }
        s.tx = gx;
        s.ty = gy;
      } else {
        s.state = 'idle';
        sp = 10;
        s.wait -= dt;
        if (s.wait <= 0) {
          s.wait = rnd(1, 3);
          const dir = (Math.random() * 4) | 0;
          const nx = tx + (dir === 0 ? 1 : dir === 1 ? -1 : 0);
          const ny = ty + (dir === 2 ? 1 : dir === 3 ? -1 : 0);
          if (nx > 0 && ny > 0 && nx < w - 1 && ny < level.h - 1 && tiles[ny * w + nx] !== T_WALL) {
            s.tx = nx * TILE + 8;
            s.ty = ny * TILE + 8;
          } else {
            s.tx = tx * TILE + 8;
            s.ty = ty * TILE + 8;
          }
        }
        gx = s.tx;
        gy = s.ty;
      }
      const mx = gx - s.x;
      const my = gy - s.y;
      const ml = Math.hypot(mx, my);
      if (ml > 0.5 && sp > 0) {
        const st = Math.min(ml, sp * dt);
        s.x += (mx / ml) * st;
        s.y += (my / ml) * st;
      }
      // keep shades from stacking on one another
      for (let j = 0; j < i; j++) {
        const o = shades[j];
        if (o.state === 'gone' || o.state === 'burn') continue;
        const ox = s.x - o.x;
        const oy = s.y - o.y;
        const od = ox * ox + oy * oy;
        if (od < 81 && od > 0.01) {
          const l = Math.sqrt(od);
          const push = (9 - l) * 0.5;
          const px = s.x + (ox / l) * push;
          const py = s.y + (oy / l) * push;
          if (tileAt(px, py) !== T_WALL) {
            s.x = px;
            s.y = py;
          }
        }
      }
      if (dt > 0) {
        const k = Math.min(1, dt * 8);
        s.vx += ((s.x - x0) / dt - s.vx) * k;
        s.vy += ((s.y - y0) / dt - s.vy) * k;
      }
      if (s.lit) {
        // light makes them smoulder
        if (Math.random() < dt * 9) spawn(s.x + rnd(-4, 4), s.y - 9, rnd(-4, 4), rnd(-18, -8), rnd(0.3, 0.6), SHADOW);
      } else if (s.state === 'hunt' && Math.random() < dt * 8) {
        // red streaks trail a hunting shade's eyes through the dark
        spawn(s.x + rnd(-3, 3), s.y - 5, 0, 0, 0.3, EYE);
      }
      if (!player.dead && d < 8 && !untouchable()) bite(s);
    }
  }

  function updateMoths(dt: number): void {
    const pr = playerRadius();
    for (const m of moths) {
      m.ph += dt;
      let orbit: Brazier | null = null;
      let bd = 84 * 84;
      for (const b of braziers) {
        if (!b.lit) continue;
        const d2 = (b.x - m.x) * (b.x - m.x) + (b.y - m.y) * (b.y - m.y);
        if (d2 < bd) {
          bd = d2;
          orbit = b;
        }
      }
      const dx = player.x - m.x;
      const dy = player.y - 4 - m.y;
      const d = Math.hypot(dx, dy);
      let gx: number;
      let gy: number;
      let sp: number;
      if (m.flee > 0) {
        m.flee -= dt;
        gx = m.x - dx;
        gy = m.y - dy;
        sp = 64;
      } else if (orbit) {
        const a = m.ph * 1.6 + m.seed;
        gx = orbit.x + Math.cos(a) * 15;
        gy = orbit.y - 16 + Math.sin(a) * 7;
        sp = 46;
      } else if (!player.dead && d < pr + 16) {
        gx = player.x;
        gy = player.y - 4;
        sp = 44;
      } else {
        const a = m.ph * 0.5 + m.seed;
        gx = m.hx + Math.cos(a) * 26;
        gy = m.hy + Math.sin(a * 1.3) * 18;
        sp = 20;
      }
      const ex = gx - m.x;
      const ey = gy - m.y;
      const el = Math.hypot(ex, ey) || 1;
      const k = Math.min(1, dt * 4);
      m.vx += ((ex / el) * sp - m.vx) * k;
      m.vy += ((ey / el) * sp - m.vy) * k;
      m.x += m.vx * dt;
      m.y += m.vy * dt + Math.sin(m.ph * 11 + m.seed) * 0.25;
      if (m.carry && Math.random() < dt * 12) spawn(m.x, m.y + 1, 0, 6, 0.3, SPARK);
      if (!orbit && m.flee <= 0 && !player.dead && d < 7 && !untouchable() && !godMode) {
        player.fuel -= MOTH_STEAL;
        player.hurtT = 0.22;
        hudShake = 0.2;
        m.carry = true;
        m.flee = MOTH_FLEE_T;
        sfx.steal();
        floater(player.x, player.y - 16, '-' + MOTH_STEAL, '#ff4d6d');
        burst(m.x, m.y, 5, SPARK, 30);
      }
    }
  }

  function makeOcto(x: number, y: number, pack: number): Octo {
    return { x, y, state: 'lurk', t: 0, ph: Math.random() * 6, tick: 0, rise: 0, sq: 0, pack, flash: 0 };
  }

  function waterAt(tx: number, ty: number): boolean {
    return tx >= 0 && ty >= 0 && tx < level.w && ty < level.h && level.tiles[ty * level.w + tx] === T_WATER;
  }

  function octoOn(x: number, y: number): boolean {
    for (const o of octos) if (o.x === x && o.y === y) return true;
    return false;
  }

  function relocateOcto(o: Octo): void {
    const pool = level.water;
    if (!pool.length) return;
    let best = pool[0];
    let bestScore = -Infinity;
    for (let i = 0; i < 30; i++) {
      const p = pool[(Math.random() * pool.length) | 0];
      const wx = p.x * TILE + 8;
      const wy = p.y * TILE + 8;
      const dp = Math.hypot(wx - player.x, wy - player.y);
      const ds = Math.hypot(wx - o.x, wy - o.y);
      let occ = false;
      for (const other of octos) {
        if (other !== o && Math.hypot(wx - other.x, wy - other.y) < 12) {
          occ = true;
          break;
        }
      }
      const score = (ds > 12 ? 100 : 0) + (dp >= 48 ? 100 : dp) + (occ ? -200 : 0) + Math.random() * 20;
      if (score > bestScore) {
        bestScore = score;
        best = p;
      }
    }
    o.x = best.x * TILE + 8;
    o.y = best.y * TILE + 8;
    // it swims off alone
    o.pack = 0;
  }

  /** Lets go of the emberling, if it has it, and sinks away behind a cloud of ink. */
  function releaseOcto(o: Octo): void {
    if (grabOcto === o) grabOcto = null;
    o.state = 'vanish';
    o.t = 0.4;
    inks.push({ x: o.x, y: o.y, t: 0 });
  }

  function startOctoGrab(o: Octo): void {
    o.state = 'grab';
    o.t = OCTO_HOLD_T;
    o.tick = 0;
    o.rise = 0;
    o.sq = 1;
    o.flash = 0.08;
    grabOcto = o;
    player.dashT = 0;
    player.vx = 0;
    player.vy = 0;
    player.x = o.x;
    player.y = o.y;
    player.sq = -0.32;
    player.hurtT = 0.28;
    sfx.grab();
    vibrate(45);
    addFx(S.ripple, o.x, o.y + 3, 0.45, false);
    for (let i = 0; i < 12; i++) {
      spawn(o.x + rnd(-6, 6), o.y + 2, rnd(-36, 36), rnd(-60, -22), rnd(0.25, 0.52), SPLASH, 160);
    }
    floater(o.x, o.y - 24, 'TRAPPED!', OCTO_H);
  }

  function updateOctos(dt: number): void {
    // While one octopus has a catch, every other one lies low. A packmate in the same pool
    // must not give itself away: it stays under, the colour of the water, until the hold ends.
    const hush = grabOcto !== null;
    for (const o of octos) {
      o.ph += dt;
      if (o.sq > 0) o.sq = Math.max(0, o.sq - dt * 3);
      if (o.flash > 0) o.flash -= dt;
      if (o.state === 'lurk') {
        // it stays under. Now and then the crown and the eyes break the surface for a look,
        // and a bump of its head shows when the emberling comes close
        const cycle = (o.ph + o.x * 0.07) % 5.4;
        const near = !player.dead && Math.hypot(player.x - o.x, player.y - o.y) < 30;
        const target = hush ? 0 : cycle > 4.45 ? 4 : near ? 2 : 0;
        o.rise += clamp(target - o.rise, -dt * (hush ? 40 : 11), dt * 16);
        if (nearView(o.x, o.y)) {
          if (Math.random() < dt * 0.8) addFx(S.ripple, o.x + rnd(-2, 2), o.y + rnd(1, 3), 0.5, false);
          if (Math.random() < dt * 1.5) {
            spawn(o.x + rnd(-5, 5), o.y + rnd(0, 4), rnd(-1.5, 1.5), rnd(-6, -2.5), rnd(0.45, 0.85), BUBBLE);
          }
        }
        if (!player.dead && !grabOcto && !untouchable() && Math.hypot(player.x - o.x, player.y - o.y) < 9.5) {
          startOctoGrab(o);
        }
      } else if (o.state === 'grab') {
        o.t -= dt;
        o.ph += dt;
        const held = OCTO_HOLD_T - Math.max(0, o.t);
        const k = clamp(held / 0.22, 0, 1);
        // it rears up before each squeeze and ducks as it bears down
        const windup = o.tick < 4 && held % 1 > 0.78;
        const pose =
          o.sq > 0.4 ? GRAB_RISE - 1 : windup ? GRAB_RISE + 1.6 : GRAB_RISE + (Math.sin(o.ph * 2.2) > 0.3 ? 0.6 : 0);
        o.rise = k < 1 ? GRAB_RISE * easeOutBack(k) : o.rise + clamp(pose - o.rise, -dt * 30, dt * 18);
        if (Math.random() < dt * 4) addFx(S.ripple, o.x + rnd(-2, 2), o.y + rnd(2, 4), 0.4, false);
        if (Math.random() < dt * 7) {
          spawn(o.x + rnd(-7, 7), o.y + 5, rnd(-14, 14), rnd(-34, -14), rnd(0.25, 0.45), SPLASH, 140);
        }
        while (o.tick < 4 && held >= o.tick + 1) {
          o.tick++;
          o.sq = 1;
          if (!godMode) {
            player.fuel = Math.max(0, player.fuel - OCTO_DRAIN);
            floater(player.x, player.y - 22, '-' + OCTO_DRAIN, '#ff4d6d');
          } else {
            floater(player.x, player.y - 22, 'GOD', '#6fe3d2');
          }
          player.hurtT = 0.28;
          player.sq = -0.26;
          hudShake = 0.25;
          hitFlash = 0.18;
          if (!reduceMotion) shake = 3.5;
          sfx.hurt();
          sfx.splash();
          vibrate(35);
          for (let i = 0; i < 6; i++) {
            spawn(o.x + rnd(-4, 4), o.y + 2, rnd(-28, 28), rnd(-48, -18), rnd(0.25, 0.45), SPLASH, 160);
          }
          spawn(player.x + rnd(-3, 3), player.y - 4, rnd(-6, 6), rnd(-24, -10), rnd(0.4, 0.7), SMOKE, 0, true);
          if (player.fuel <= 0) break;
        }
        if (player.fuel <= 0 || o.t <= 0) {
          releaseOcto(o);
          if (player.fuel > 0) {
            player.inv = 0.7;
            player.sq = 0.26;
          }
          sfx.splash();
          for (let i = 0; i < 6; i++) {
            spawn(o.x + rnd(-4, 4), o.y, rnd(-22, 22), rnd(-44, -16), rnd(0.25, 0.45), SPLASH, 160);
          }
        }
      } else if (o.state === 'vanish') {
        o.t -= dt;
        o.rise = GRAB_RISE * clamp(o.t / 0.4, 0, 1);
        if (o.t <= 0) {
          relocateOcto(o);
          o.state = 'emerge';
          o.t = 0.55;
          o.rise = 0;
          addFx(S.ripple, o.x, o.y + 2, 0.45, false);
        }
      } else {
        // settling, unseen, into its new pool
        o.t -= dt;
        o.rise = 0;
        if (o.t <= 0) {
          o.state = 'lurk';
          o.ph = 0;
        }
      }
    }
  }

  function updateFlares(dt: number): void {
    for (let i = flares.length - 1; i >= 0; i--) {
      const f = flares[i];
      f.t += dt;
      const k = Math.min(1, f.t / 0.35);
      f.r = FLARE_R * easeOut(k);
      const r2 = f.r * f.r;
      for (const s of shades) {
        if (s.state !== 'idle' && s.state !== 'hunt') continue;
        if ((s.x - f.x) * (s.x - f.x) + (s.y - f.y) * (s.y - f.y) < r2) igniteShade(s);
      }
      for (let j = moths.length - 1; j >= 0; j--) {
        const m = moths[j];
        if ((m.x - f.x) * (m.x - f.x) + (m.y - f.y) * (m.y - f.y) < r2) {
          dropEmber(m.x, m.y, m.carry ? 12 : 6);
          burst(m.x, m.y, 8, FIRE, 40);
          addFx(S.poofFire, m.x, m.y, 0.3, true);
          sfx.burn();
          moths.splice(j, 1);
        }
      }
      if (f.t > 0.55) flares.splice(i, 1);
    }
  }

  function updateParticles(dt: number): void {
    for (let i = parts.length - 1; i >= 0; i--) {
      const p = parts[i];
      p.life -= dt;
      if (p.life <= 0) {
        parts[i] = parts[parts.length - 1];
        parts.pop();
        continue;
      }
      p.vy += p.g * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
    }
    for (let i = floaters.length - 1; i >= 0; i--) {
      const f = floaters[i];
      f.t -= dt;
      f.y -= 14 * dt;
      if (f.t <= 0) floaters.splice(i, 1);
    }
  }

  /** Purely cosmetic timers that keep running on every screen. */
  function tickWorld(dt: number): void {
    for (const b of braziers) if (b.lit) b.litT += dt;
    if (gateOpen) gateT += dt;
    for (const e of embers) {
      e.ph += dt * 4;
      if (e.z > 0 || e.vz !== 0) {
        e.vz -= 320 * dt;
        e.z += e.vz * dt;
        if (e.z <= 0) {
          e.z = 0;
          e.vz = e.vz < -50 ? -e.vz * 0.45 : 0;
        }
      }
    }
    for (let i = ghosts.length - 1; i >= 0; i--) {
      ghosts[i].t += dt;
      if (ghosts[i].t >= 0.2) ghosts.splice(i, 1);
    }
    for (let i = fxs.length - 1; i >= 0; i--) {
      fxs[i].t += dt;
      if (fxs[i].t >= fxs[i].dur) fxs.splice(i, 1);
    }
    for (let i = inks.length - 1; i >= 0; i--) {
      inks[i].t += dt;
      if (inks[i].t >= INK_T) inks.splice(i, 1);
    }
    if (hitFlash > 0) hitFlash -= dt;
    if (shake > 0) shake = Math.max(0, shake - dt * 22);
  }

  function ambient(dt: number): void {
    // the emberling's own flame
    if (!player.dead && player.scale > 0.5 && Math.random() < dt * (8 + player.fuel * 0.22)) {
      spawn(
        player.x + rnd(-2.5, 2.5),
        player.y - 6 - player.hopH,
        rnd(-4, 4) - player.avx * 0.2,
        rnd(-28, -12),
        rnd(0.25, 0.55),
        FIRE,
      );
    }
    for (const b of braziers) {
      if (!b.lit) continue;
      if (Math.abs(b.x - player.x) > VW || Math.abs(b.y - player.y) > VH) continue;
      if (Math.random() < dt * 16) spawn(b.x + rnd(-3, 3), b.y - 14, rnd(-4, 4), rnd(-30, -14), rnd(0.4, 0.8), FIRE);
    }
    if (book && nearView(book.x, book.y) && Math.random() < dt * 5) {
      // motes of light drift up off the open pages
      spawn(book.x + rnd(-6, 6), book.y - 9, rnd(-2, 2), rnd(-14, -6), rnd(0.5, 1), BOOK_GLOW);
    }
    if (gateOpen && Math.random() < dt * 12) {
      spawn(gate.x + rnd(-6, 6), gate.y + rnd(-10, 2), rnd(-3, 3), rnd(-20, -8), rnd(0.5, 1), PORTAL);
    }
  }

  /** Springs, expressions and the spawn pop: everything that makes the emberling feel alive. */
  function animatePlayer(dt: number): void {
    if (player.spawnT > 0) {
      if (player.spawnT === SPAWN_T) {
        burst(player.x, player.y - 3, 12, SPARK, 45);
        addFx(S.poofFire, player.x, player.y - 3, 0.3, true);
      }
      player.spawnT -= dt;
      player.scale = player.spawnT <= 0 ? 1 : easeOutBack(1 - player.spawnT / SPAWN_T);
    }
    player.sqV += (-player.sq * 220 - player.sqV * 16) * dt;
    player.sq = clamp(player.sq + player.sqV * dt, -0.5, 0.5);
    if (player.hurtT > 0) player.hurtT -= dt;
    if (player.happyT > 0) player.happyT -= dt;
    lightFuel += (Math.max(0, player.fuel) - lightFuel) * Math.min(1, dt * 7);
    lightKick *= Math.max(0, 1 - dt * 7);
  }

  function updatePlayer(dt: number): void {
    const px0 = player.x;
    const py0 = player.y;
    readInput();
    const mag = Math.hypot(inX, inY);
    player.moving = mag > 0.05;
    if (player.moving) {
      player.fx = inX / mag;
      player.fy = inY / mag;
    }
    const wasWet = player.wet;
    player.wet = tileAt(player.x, player.y + 2) === T_WATER;
    if (player.wet && !wasWet) {
      sfx.splash();
      addFx(S.ripple, player.x, player.y + 3, 0.4, false);
      for (let i = 0; i < 6; i++) {
        spawn(player.x + rnd(-3, 3), player.y + 2, rnd(-25, 25), rnd(-45, -20), rnd(0.25, 0.45), SPLASH, 160);
      }
    }

    if (player.flareCd > 0) player.flareCd -= dt;
    if (player.dashCd > 0) player.dashCd -= dt;
    if (player.inv > 0) player.inv -= dt;
    if (grabOcto) {
      // held in place by tentacles; struggling nudges slightly
      flareBuf = 0;
      dashBuf = 0;
      player.dashT = 0;
      player.vx = 0;
      player.vy = 0;
      const jx = player.moving && !reduceMotion ? inX * 1.4 + Math.sin(time * 38) * 0.5 : 0;
      const jy = player.moving && !reduceMotion ? inY * 1.0 : 0;
      player.x = grabOcto.x + jx;
      player.y = grabOcto.y + jy;
      player.avx += (inX * 22 - player.avx) * Math.min(1, dt * 12);
      player.hop = 0;
      player.hopH = 0;
    } else {
      if (flareBuf > 0) {
        flareBuf -= dt;
        if (player.flareCd <= 0) {
          flareBuf = 0;
          doFlare();
        }
      }
      if (dashBuf > 0) {
        dashBuf -= dt;
        if (player.dashCd <= 0 && player.dashT <= 0) {
          dashBuf = 0;
          doDash();
        }
      }

      if (player.dashT > 0) {
        player.dashT -= dt;
        player.vx = player.dashX * DASH_SPEED;
        player.vy = player.dashY * DASH_SPEED;
        ghostT -= dt;
        if (ghostT <= 0) {
          ghostT = 0.03;
          ghosts.push({ x: player.x, y: player.y, tier: player.tier, t: 0 });
        }
        spawn(player.x + rnd(-2, 2), player.y - 3 + rnd(-3, 3), rnd(-10, 10), rnd(-20, 0), rnd(0.2, 0.4), FIRE);
        if (player.dashT <= 0) {
          player.vx = player.dashX * MAX_SPEED;
          player.vy = player.dashY * MAX_SPEED;
          player.sq = -0.22;
        }
      } else {
        // quick to start, quick to stop, but never instant
        const max = (player.wet ? WATER_SPEED : MAX_SPEED) * speedMult;
        const k = Math.min(1, dt * (player.moving ? 16 : 11));
        player.vx += (inX * max - player.vx) * k;
        player.vy += (inY * max - player.vy) * k;
      }
      const dx = player.vx * dt;
      const dy = player.vy * dt;
      const steps = Math.max(1, Math.ceil(Math.max(Math.abs(dx), Math.abs(dy)) / 3));
      for (let i = 0; i < steps; i++) stepMove(dx / steps, dy / steps);

      // animate from what actually happened, so pushing a wall doesn't hop in place
      const rvx = dt > 0 ? (player.x - px0) / dt : 0;
      const rvy = dt > 0 ? (player.y - py0) / dt : 0;
      player.avx += (rvx - player.avx) * Math.min(1, dt * 12);
      const sp = Math.hypot(rvx, rvy);
      if (sp > 10 && player.dashT <= 0) {
        const before = Math.floor(player.hop / Math.PI);
        player.hop += dt * (6 + sp * 0.11);
        if (Math.floor(player.hop / Math.PI) !== before) {
          // touched down
          player.sq -= 0.09;
          if (player.wet) addFx(S.ripple, player.x, player.y + 3, 0.4, false);
          else {
            spawn(player.x - 2, player.y + 3, rnd(-10, -3), rnd(-8, -3), 0.25, DUST);
            spawn(player.x + 2, player.y + 3, rnd(3, 10), rnd(-8, -3), 0.25, DUST);
          }
        }
        player.hopH = Math.abs(Math.sin(player.hop)) * 2;
      } else {
        player.hop = 0;
        player.hopH += (0 - player.hopH) * Math.min(1, dt * 14);
      }

      // the flame burns down: it is health, light and clock at once
      const burnRate = flameBurn(depth);
      const warm = inBrazierLight(player.x, player.y);
      if (player.wet) {
        if (!godMode && !noBurn) player.fuel -= burnRate * WATER_BURN * dt;
        if (Math.random() < dt * 14) {
          spawn(player.x + rnd(-3, 3), player.y - 2, rnd(-5, 5), rnd(-22, -10), rnd(0.4, 0.8), SMOKE, 0, true);
        }
      } else if (warm) {
        if (player.fuel < 50) player.fuel = Math.min(50, player.fuel + 8 * dt);
      } else if (!godMode && !noBurn) {
        player.fuel -= burnRate * dt;
      }
    }

    // embers
    for (let i = embers.length - 1; i >= 0; i--) {
      const e = embers[i];
      const ex = player.x - e.x;
      const ey = player.y - 2 - e.y;
      const d = Math.hypot(ex, ey);
      if (d < 26 && d > 0.01) {
        const pull = Math.min(d, (30 - d) * 5 * dt);
        e.x += (ex / d) * pull;
        e.y += (ey / d) * pull;
        if (Math.random() < dt * 22) spawn(e.x, e.y - 1, 0, 0, 0.22, SPARK);
      }
      if (d < 8) {
        player.fuel = Math.min(100, player.fuel + e.v);
        embersTotal++;
        sfx.pickup();
        floater(e.x, e.y - 8, '+' + e.v, '#ffd15c');
        addFx(S.sparkle, e.x, e.y - 2, 0.3, true);
        player.sq = Math.max(player.sq, 0.14);
        lightKick = 5;
        embers.splice(i, 1);
      }
    }

    // braziers
    for (const b of braziers) {
      if (b.lit) continue;
      const bx = player.x - b.x;
      const by = player.y - b.y;
      if (bx * bx + by * by < 14 * 14) {
        b.lit = true;
        b.litT = 0;
        litCount++;
        player.fuel = Math.min(100, player.fuel + 15);
        player.happyT = 1.3;
        player.sq = 0.32;
        lightKick = 8;
        sfx.light();
        vibrate(20);
        burst(b.x, b.y - 12, 26, FIRE, 80);
        addFx(S.sparkle, b.x, b.y - 14, 0.4, true);
        reveal(b.x, b.y - 4, BRAZIER_R);
        if (litCount === braziers.length) {
          gateOpen = true;
          gateT = 0;
          sfx.gate();
          say('THE GATE AWAKENS', 3.2);
        } else {
          say('BRAZIER LIT ' + litCount + '/' + braziers.length, 2.2);
        }
      }
    }

    // the guide book: standing at the lectern turns the action button into READ
    const wasNear = nearBook;
    nearBook = book !== null && !grabOcto && Math.hypot(player.x - book.x, player.y - book.y) < 20;
    // a rustle of pages as the emberling steps up
    if (nearBook && !wasNear) sfx.page();

    // growing and shrinking between sizes gets a little pop
    const t = tierOf();
    if (t !== player.tier) {
      player.sq = t > player.tier ? -0.28 : 0.28;
      if (t > player.tier) {
        for (let i = 0; i < 4; i++) spawn(player.x + rnd(-3, 3), player.y - 6, rnd(-6, 6), rnd(-20, -8), rnd(0.3, 0.6), SMOKE, 0, true);
      }
      player.tier = t;
    }

    // gate
    const gdx = player.x - gate.x;
    const gdy = player.y - gate.y;
    const gd2 = gdx * gdx + gdy * gdy;
    if (gateHintT > 0) gateHintT -= dt;
    if (gateOpen && gd2 < 9 * 9) {
      state = 'transition';
      trans.t = 0;
      trans.swapped = false;
      trans.opened = false;
      joy.active = false;
      mouse.down = false;
      player.dashT = 0;
      sfx.descend();
    } else if (!gateOpen && gd2 < 16 * 16 && gateHintT <= 0) {
      say('THE GATE SLEEPS - LIGHT EVERY BRAZIER', 2.4);
      gateHintT = 5;
    }

    if (player.fuel < 22) {
      player.lowT -= dt;
      if (player.lowT <= 0) {
        player.lowT = 0.9;
        sfx.low();
      }
    }
    if (player.fuel <= 0) die();
  }

  function updateCamera(dt: number): void {
    const c = cameraTarget();
    const k = Math.min(1, dt * 9);
    camX += (c.x - camX) * k;
    camY += (c.y - camY) * k;
  }

  function updateTransition(dt: number): void {
    trans.t += dt;
    if (!trans.swapped) {
      if (trans.t < T_CLOSE) {
        // the emberling is drawn into the gate
        const k = Math.min(1, dt * 10);
        player.x += (gate.x - player.x) * k;
        player.y += (gate.y - 4 - player.y) * k;
        player.scale = Math.max(0, 1 - trans.t / T_CLOSE);
        if (Math.random() < dt * 40) {
          const a = Math.random() * Math.PI * 2;
          spawn(gate.x + Math.cos(a) * 12, gate.y - 5 + Math.sin(a) * 12, -Math.cos(a) * 30, -Math.sin(a) * 30, 0.35, PORTAL);
        }
        updateCamera(dt);
      } else {
        trans.swapped = true;
        depth++;
        player.fuel = Math.min(100, player.fuel + 25);
        loadLevel(depth);
      }
      return;
    }
    if (!trans.opened) {
      if (trans.t >= T_CLOSE + T_HOLD) {
        trans.opened = true;
        sfx.spawn();
      }
      return;
    }
    animatePlayer(dt);
    if (trans.t >= T_CLOSE + T_HOLD + T_OPEN) {
      state = 'play';
      levelIntro();
    }
  }

  function tickHud(dt: number): void {
    if (toast.t > 0) {
      toast.t -= dt;
      toast.age += dt;
      if (toast.t <= 0 && toastQ.length) {
        const rest = toastQ.slice(1);
        say(toastQ[0], 3.2);
        toastQ = rest;
      }
    }
    const f = Math.max(0, player.fuel);
    if (f > fuelLast + 4) gainFlash = 0.22;
    fuelLast = f;
    if (gainFlash > 0) gainFlash -= dt;
    if (hudShake > 0) hudShake -= dt;
    fuelShown += (f - fuelShown) * Math.min(1, dt * 12);
    // sudden losses leave a red "ghost" chunk that drains a moment later
    if (f >= fuelGhost || fuelGhost - f < 3) {
      fuelGhost = f;
      ghostHold = 0.4;
    } else {
      ghostHold -= dt;
      if (ghostHold <= 0) fuelGhost = Math.max(f, fuelGhost - 45 * dt);
    }
    if (flarePressT > 0) flarePressT -= dt;
    if (dashPressT > 0) dashPressT -= dt;
  }

  function update(dt: number): void {
    pollPad(dt);
    // menus and the guide book hold the world still
    const held = state === 'pause' || state === 'settings' || guideOpen;
    if (held || (adminModalLock && pauseOnAdmin)) {
      if (held || stepQueue <= 0) {
        time += dt;
        return;
      }
      // admin frame-advance: exactly one tick while everything else stays held
      stepQueue--;
      dt = 1 / 60;
      dirty = true;
    } else {
      stepQueue = 0;
      dt *= timeScale;
    }
    time += dt;
    tickHud(dt);

    if (state === 'transition') {
      updateTransition(dt);
      tickWorld(dt);
      updateParticles(dt);
      return;
    }

    ambient(dt);
    tickWorld(dt);

    if (state === 'title') {
      animatePlayer(dt);
      updateParticles(dt);
      updateCamera(dt);
      return;
    }

    if (state === 'over') {
      player.deathT += dt;
      if (!player.poofed && player.deathT > 0.4) {
        player.poofed = true;
        addFx(S.poof, player.x, player.y - 3, 0.35, true);
        for (let i = 0; i < 14; i++) {
          spawn(player.x + rnd(-3, 3), player.y - 4, rnd(-9, 9), rnd(-28, -8), rnd(0.6, 1.4), SMOKE, 0, i % 2 === 0);
        }
      }
      animatePlayer(dt);
      updateOctos(dt);
      updateShades(dt);
      updateMoths(dt);
      updateParticles(dt);
      updateCamera(dt);
      return;
    }

    updatePlayer(dt);
    animatePlayer(dt);
    if ((state as State) !== 'play') {
      // the player just died or stepped through the gate
      updateParticles(dt);
      updateCamera(dt);
      return;
    }
    flowT -= dt;
    if (flowT <= 0) {
      flowT = 0.3;
      computeFlow();
    }
    revealT -= dt;
    if (revealT <= 0) {
      revealT = 0.1;
      reveal(player.x, player.y - 3, playerRadius() * 0.95);
    }
    updateFlares(dt);
    if (!freezeEnemies) {
      updateOctos(dt);
      updateShades(dt);
      updateMoths(dt);
    }
    updateParticles(dt);
    updateCamera(dt);
  }

  // ---------------------------------------------------------------- render
  const textCache = new Map<string, Sprite>();

  /** Outlined lettering costs hundreds of tiny rects, so every string is drawn once and kept as a sprite. */
  function textSprite(str: string, color: string | string[], sc: number): Sprite {
    const key = sc + '|' + (typeof color === 'string' ? color : color.join('')) + '|' + str;
    let spr = textCache.get(key);
    if (!spr) {
      if (textCache.size > 500) textCache.clear();
      spr = document.createElement('canvas');
      spr.width = textWidth(str, sc) + 2 + sc;
      spr.height = 5 * sc + 2 + sc;
      const tc = spr.getContext('2d') as CanvasRenderingContext2D;
      drawText(tc, str, 0, 1, INK, sc);
      drawText(tc, str, 2, 1, INK, sc);
      drawText(tc, str, 1, 0, INK, sc);
      drawText(tc, str, 1, 2, INK, sc);
      drawText(tc, str, 1 + sc, 1 + sc, INK, sc);
      drawText(tc, str, 1, 1, color, sc);
      textCache.set(key, spr);
    }
    return spr;
  }

  function text(str: string, x: number, y: number, color: string | string[], sc = 1, align = 0): void {
    if (!str) return;
    const w = textWidth(str, sc);
    const px = Math.round(align === 1 ? x - w / 2 : align === 2 ? x - w : x);
    ctx.drawImage(textSprite(str, color, sc), px - 1, Math.round(y) - 1);
  }

  function maxChars(): number {
    return Math.max(8, Math.floor((VW - safe.l - safe.r - 8) / 4));
  }

  /** Centred text that wraps on narrow screens, preferring to break at " - ". Returns the y after the last line. */
  function textWrap(str: string, y: number, color: string | string[]): number {
    const max = maxChars();
    const mid = Math.round(VW / 2);
    const chunks = str.length > max ? str.split(' - ') : [str];
    for (const chunk of chunks) {
      let line = '';
      for (const word of chunk.split(' ')) {
        const next = line ? line + ' ' + word : word;
        if (next.length > max && line) {
          text(line, mid, y, color, 1, 1);
          y += 8;
          line = word;
        } else {
          line = next;
        }
      }
      if (line) {
        text(line, mid, y, color, 1, 1);
        y += 8;
      }
    }
    return y;
  }

  /** Big title lettering that rides a slow wave. */
  function waveText(str: string, mid: number, y: number, sc: number): void {
    let x = Math.round(mid - textWidth(str, sc) / 2);
    for (let i = 0; i < str.length; i++) {
      const off = reduceMotion ? 0 : Math.round(Math.sin(time * 2.6 - i * 0.7) * 1.7);
      text(str[i], x, y + off, TITLE_COLS, sc);
      x += 4 * sc;
    }
  }

  function addLight(x: number, y: number, r: number, k: number): void {
    if (lightN >= MAX_LIGHTS || r <= 0.5 || k <= 0) return;
    lightX[lightN] = x;
    lightY[lightN] = y;
    lightR[lightN] = r;
    lightK[lightN] = k;
    lightN++;
  }

  function buildLights(cx: number, cy: number): void {
    lightN = 0;
    const flick = reduceMotion ? 0 : Math.sin(time * 9.1) * 1.2;
    addLight(player.x, player.y - 3, playerRadius(), 1);
    for (const b of braziers) {
      if (!b.lit) continue;
      // a freshly lit brazier's glow swells outward
      const grow = b.litT < 0.5 ? easeOut(b.litT / 0.5) : 1;
      addLight(b.x, b.y - 4, BRAZIER_R * grow + flick, 1);
    }
    for (const e of embers) {
      if (e.x < cx - 12 || e.x > cx + VW + 12 || e.y < cy - 12 || e.y > cy + VH + 12) continue;
      addLight(e.x, e.y, 9 + Math.sin(e.ph) * 1.2, 0.75);
    }
    for (const f of flares) addLight(f.x, f.y, f.r * 1.35 + 12, 1 - f.t / 0.55);
    if (gateOpen) addLight(gate.x, gate.y - 5, (36 + flick) * Math.min(1, gateT / 0.9), 0.9);
    // the guide book glows, so it can be found in the dark
    if (book) addLight(book.x, book.y - 6, 24 + flick, 0.85);
    for (const s of shades) {
      if (s.state === 'burn') addLight(s.x, s.y - 4, 18, 0.8);
    }
    for (const m of moths) {
      if (m.carry) addLight(m.x, m.y, 7, 0.7);
    }
  }

  function renderDarkness(cx: number, cy: number): void {
    bright.fill(0);
    for (let n = 0; n < lightN; n++) {
      const sx = lightX[n] - cx;
      const sy = lightY[n] - cy;
      const r = lightR[n];
      const x0 = Math.max(0, Math.floor(sx - r));
      const x1 = Math.min(VW - 1, Math.ceil(sx + r));
      const y0 = Math.max(0, Math.floor(sy - r));
      const y1 = Math.min(VH - 1, Math.ceil(sy + r));
      if (x0 > x1 || y0 > y1) continue;
      const r2 = r * r;
      const k = (lightK[n] * 561) / r2;
      for (let y = y0; y <= y1; y++) {
        // only walk the pixels of this row that are inside the circle
        const dy = y - sy;
        const span = r2 - dy * dy;
        if (span <= 0) continue;
        const half = Math.sqrt(span);
        const xa = Math.max(x0, Math.ceil(sx - half));
        const xb = Math.min(x1, Math.floor(sx + half));
        let i = y * VW + xa;
        for (let x = xa; x <= xb; x++, i++) {
          const dx = x - sx;
          let v = (span - dx * dx) * k;
          if (v > 255) v = 255;
          if (v > bright[i]) bright[i] = v;
        }
      }
    }
    const w = level.w;
    const h = level.h;
    for (let x = 0; x < VW; x++) {
      const t = (x + cx) >> 4;
      colTx[x] = t >= 0 && t < w ? t : -1;
    }
    const bx = cx & 3;
    let i = 0;
    for (let y = 0; y < VH; y++) {
      const wy = y + cy;
      const ty = wy >> 4;
      const rowOk = ty >= 0 && ty < h;
      const rowBase = ty * w;
      const by = (wy & 3) << 2;
      for (let x = 0; x < VW; x++, i++) {
        const lv = DITHER[(bright[i] << 4) | by | ((x + bx) & 3)];
        if (lv !== 0) light32[i] = LEVEL_COL[lv];
        else {
          const t = colTx[x];
          light32[i] = rowOk && t >= 0 && explored[rowBase + t] ? DARK_SEEN : DARK_FULL;
        }
      }
    }
    lightCtx.putImageData(lightImg, 0, 0);
    ctx.drawImage(lightCanvas, 0, 0);
  }

  function drawWater(cx: number, cy: number): void {
    const x0 = Math.max(0, cx >> 4);
    const x1 = Math.min(level.w - 1, (cx + VW) >> 4);
    const y0 = Math.max(0, cy >> 4);
    const y1 = Math.min(level.h - 1, (cy + VH) >> 4);
    ctx.fillStyle = '#6fb6e0';
    for (let ty = y0; ty <= y1; ty++) {
      for (let tx = x0; tx <= x1; tx++) {
        if (level.tiles[ty * level.w + tx] !== T_WATER) continue;
        const hsh = (tx * 37 + ty * 91) % 17;
        const ph = Math.floor(time * 2 + hsh * 0.37) % 6;
        if (ph > 3) continue;
        const sx = tx * TILE - cx + 2 + ((hsh * 5 + ph * 3) % 11);
        const sy = ty * TILE - cy + 3 + ((hsh * 3 + ph * 7) % 10);
        ctx.fillRect(sx, sy, ph % 2 === 0 ? 2 : 3, 1);
      }
    }
  }

  function runesLit(): number {
    if (gateOpen) return 6;
    return braziers.length ? Math.floor((litCount / braziers.length) * 6) : 0;
  }

  /** The gate's runes light one by one as braziers are lit; they also shine through the dark. */
  function drawRunes(sx: number, sy: number): void {
    const n = runesLit();
    for (let i = 0; i < n && i < S.gateRunes.length; i++) {
      const p = S.gateRunes[S.gateRunes.length - 1 - i];
      ctx.fillStyle = Math.floor(time * 4 + i * 1.7) % 5 === 0 ? '#e9fffb' : '#6fe3d2';
      ctx.fillRect(sx + p.x, sy + p.y, 1, 2);
    }
    if (gateOpen) {
      ctx.fillStyle = Math.floor(time * 3) % 2 === 0 ? '#e9fffb' : '#6fe3d2';
      for (const p of S.gateGem) ctx.fillRect(sx + p.x, sy + p.y, 1, 1);
    }
  }

  function drawGate(sx: number, sy: number): void {
    ctx.drawImage(S.gate, sx, sy);
    if (gateOpen) {
      // the portal irises open from the middle
      const R = gateT < 0.9 ? 12 * easeOut(gateT / 0.9) : 99;
      const t = reduceMotion ? time * 0.3 : time;
      for (let i = 0; i < S.gateMask.length; i++) {
        const d = gateD[i];
        if (d > R) continue;
        const p = S.gateMask[i];
        if (d > R - 1.3) ctx.fillStyle = '#e9fffb';
        else {
          // two spiral arms turning around the centre
          const v = Math.sin(gateA[i] * 2 + d * 0.55 - t * 3.2) * 1.5 + Math.sin(d * 0.9 - t * 2.1);
          ctx.fillStyle = PORTAL[clamp((((v + 2.5) / 5) * PORTAL.length) | 0, 0, PORTAL.length - 1)];
        }
        ctx.fillRect(sx + p.x, sy + p.y, 1, 1);
      }
    } else {
      // asleep: a few dim motes drift in the doorway
      for (let i = 0; i < 3; i++) {
        const idx = (Math.floor(time * 1.5 + i * 0.37) * (37 + i * 11) + i * 53) % S.gateMask.length;
        const p = S.gateMask[idx];
        ctx.fillStyle = i === 0 ? '#4b3a8f' : '#2b2648';
        ctx.fillRect(sx + p.x, sy + p.y, 1, 1);
      }
    }
    drawRunes(sx, sy);
  }

  function drawFace(T: PlayerTier, tier: number, ox: number, oy: number): void {
    const y = oy + T.eyeY;
    const l = ox + T.eyeL;
    const r = ox + T.eyeR;
    const blink = time % 3.4 < 0.12;
    pctx.fillStyle = '#2a1020';
    if (tier === 2) {
      // too small for expressions: just two worried dots
      if (!blink) {
        pctx.fillRect(l, y, 1, 1);
        pctx.fillRect(r, y, 1, 1);
      }
      return;
    }
    if (player.dead || player.hurtT > 0 || grabOcto) {
      // wince
      pctx.fillRect(l - 1, y, 1, 1);
      pctx.fillRect(l, y + 1, 1, 1);
      pctx.fillRect(r + 1, y, 1, 1);
      pctx.fillRect(r, y + 1, 1, 1);
      return;
    }
    if (player.happyT > 0) {
      // beaming
      pctx.fillRect(l, y, 1, 1);
      pctx.fillRect(l - 1, y + 1, 1, 1);
      pctx.fillRect(r, y, 1, 1);
      pctx.fillRect(r + 1, y + 1, 1, 1);
      pctx.fillStyle = '#e8552d';
      pctx.fillRect(l + 1, y + 2, r - l - 1, 1);
      return;
    }
    if (blink) {
      pctx.fillRect(l, y + 1, 1, 1);
      pctx.fillRect(r, y + 1, 1, 1);
      return;
    }
    // eyes follow the direction of travel
    const lx = player.moving ? Math.round(player.fx) : 0;
    const ly = tier === 0 && player.moving ? (player.fy > 0.6 ? 1 : player.fy < -0.6 ? -1 : 0) : 0;
    pctx.fillRect(l + lx, y + ly, 1, 2);
    pctx.fillRect(r + lx, y + ly, 1, 2);
  }

  function drawPlayer(cx: number, cy: number): void {
    if (player.dead && player.poofed) return;
    let sc = player.scale;
    if (player.dead) sc *= Math.max(0.35, 1 - (player.deathT / 0.4) * 0.6);
    if (sc <= 0.03) return;
    if (!player.dead && player.inv > 0 && player.hurtT <= 0 && Math.floor(time * 18) % 2 === 0) return;

    const tier = tierOf();
    const T = S.player[tier];
    const fi = FLICK[Math.floor(time * 9) % 4];
    const held = grabOcto !== null && !player.dead;
    const sputter = player.dead || (player.wet && !held) || (tier === 2 && (time * 2.7) % 1 < 0.14);
    const flash = player.hurtT > 0.24;
    const spr = flash ? T.hurt : sputter ? T.dim[fi] : T.frames[fi];
    const w = spr.width;
    const h = spr.height;
    const ox = (24 - w) >> 1;
    const oy = 23 - h;

    // the flame tip sways on its own and trails behind when moving
    pctx.clearRect(0, 0, 24, 24);
    const sway = reduceMotion ? 0 : Math.sin(time * 6.1) * 0.5 + Math.sin(time * 10.7) * 0.3;
    const lean = clamp((-player.avx / MAX_SPEED) * 2.2 + sway, -2.6, 2.6);
    for (let r = 0; r < h; r++) {
      const kk = (h - 1 - r) / (h - 1);
      pctx.drawImage(spr, 0, r, w, 1, ox + Math.round(lean * kk * kk), oy + r, w, 1);
    }
    if (!flash) drawFace(T, tier, ox, oy);

    const sq = player.sq + (reduceMotion ? 0 : Math.sin(time * 3.2) * 0.035);
    let sx = (1 - sq * 0.7) * sc;
    let sy = (1 + sq) * sc;
    if (player.dashT > 0) {
      if (Math.abs(player.dashX) > Math.abs(player.dashY)) {
        sx *= 1.3;
        sy *= 0.78;
      } else {
        sx *= 0.82;
        sy *= 1.25;
      }
    }
    // an octopus hoists its catch clear of the water
    const wading = player.wet && !player.dead && !held;
    const srcH = wading ? 20 : 23;
    const dw = Math.max(1, Math.round(24 * sx));
    const dh = Math.max(1, Math.round(srcH * sy));
    const fx = Math.round(player.x - cx) + (player.dead && Math.floor(time * 30) % 2 === 0 ? 1 : 0);
    const ground = Math.round(player.y - cy) + 4;
    const fy = held ? ground - 2 : wading ? ground - 1 : ground - Math.round(player.hopH);
    if (grabOcto && held) drawOctoBack(grabOcto, cx, cy);
    if (!wading && !held && !player.dead && sc > 0.6) ctx.drawImage(S.shadowM, fx - 4, ground - 2);
    ctx.drawImage(pc, 0, 0, 24, srcH, fx - (dw >> 1), fy - dh, dw, dh);
    if (grabOcto && held) drawOctoFront(grabOcto, cx, cy, tier);
    if (wading) {
      const ph = Math.floor(time * 5) % 2;
      ctx.fillStyle = '#6fb6e0';
      ctx.fillRect(fx - 6 - ph, fy, 3, 1);
      ctx.fillRect(fx + 3 + ph, fy, 3, 1);
    }
  }

  function drawShade(s: Shade, cx: number, cy: number): void {
    const W = 14;
    const H = 15;
    const gx = Math.round(s.x - cx);
    const gy = Math.round(s.y - cy);
    const bob = Math.round(Math.sin(s.ph * 3) * 1.2);
    // caught in the light, a shade cowers and trembles
    const bx = gx - 7 + (s.lit && !reduceMotion && Math.floor(time * 40) % 2 === 1 ? 1 : 0);
    const by = gy - 11 + bob;
    if (s.state === 'burn') {
      // burning away: the silhouette flares white-hot, then is eaten from the hem upward
      const k = clamp(1 - s.t / BURN_T, 0, 1);
      const sil = S.shadeBurn[Math.min(3, (k * 4) | 0)];
      const tick = Math.floor(time * 30);
      const keep = Math.ceil(H * (1 - k * k));
      for (let r = 0; r < keep; r++) {
        const hsh = (r * 7 + tick * 13 + (gx & 7) * 3) % 10;
        const edge = r >= keep - 3;
        if (edge && hsh < 4) continue;
        ctx.drawImage(sil, 0, r, W, 1, bx + (edge ? (hsh & 1 ? 1 : -1) : 0), by - Math.round(k * 3) + r, W, 1);
      }
      return;
    }
    ctx.drawImage(S.shadowL, gx - 6, gy + 2);
    const spr = S.shade[Math.floor(s.ph * 6) % 4];
    // rising out of the floor, head first
    const rows = s.rise > 0 ? Math.max(1, Math.round(H * (1 - s.rise / RISE_T))) : H;
    const top = by + H - rows;
    // the tattered hem drags behind the hood
    const lag = clamp(-s.vx / 36, -1, 1) * 3;
    if (rows === H && Math.abs(lag) < 0.5) {
      // hovering in place: one blit instead of fifteen
      ctx.drawImage(spr, bx, top);
      return;
    }
    for (let r = 0; r < rows; r++) {
      const kk = r / (H - 1);
      ctx.drawImage(spr, 0, r, W, 1, bx + Math.round(lag * kk * kk), top + r, W, 1);
    }
  }

  function drawBrazier(b: Brazier, cx: number, cy: number): void {
    const bx = Math.round(b.x - cx) - 7;
    const by = Math.round(b.y - cy) - 9;
    ctx.drawImage(S.shadowL, bx + 1, by + 10);
    ctx.drawImage(S.brazier, bx, by);
    if (!b.lit) return;
    ctx.drawImage(S.coals[Math.floor(time * 5 + b.x) % 2], bx + 2, by + 1);
    const spr = S.flame[Math.floor(time * 10 + b.x * 0.37) % 4];
    const baseX = bx + 7;
    const baseY = by + 3;
    if (b.litT < 0.4) {
      // whoosh: the flame leaps up, overshoots and settles
      const g = Math.max(0.1, easeOutBack(b.litT / 0.4));
      const dw = Math.max(1, Math.round(10 * g));
      const dh = Math.max(1, Math.round(11 * g * 1.15));
      ctx.drawImage(spr, baseX - (dw >> 1), baseY - dh, dw, dh);
      return;
    }
    const sway = reduceMotion ? 0 : Math.sin(time * 5 + b.x) * 1.2 + Math.sin(time * 8.3 + b.y) * 0.6;
    for (let r = 0; r < 11; r++) {
      const kk = (10 - r) / 10;
      ctx.drawImage(spr, 0, r, 10, 1, baseX - 5 + Math.round(sway * kk * kk), baseY - 11 + r, 10, 1);
    }
  }

  function drawEmber(e: Ember, cx: number, cy: number): void {
    const x = Math.round(e.x - cx);
    const y = Math.round(e.y - cy);
    ctx.drawImage(S.shadowS, x - 2, y + 2);
    const bob = Math.round(Math.sin(e.ph) * 1.3);
    ctx.drawImage(S.ember[EMBER_SEQ[Math.floor(e.ph * 1.6) % 4]], x - 3, y - 5 + bob - Math.round(e.z));
  }

  function drawFx(cx: number, cy: number, glow: boolean): void {
    for (const f of fxs) {
      if (f.glow !== glow) continue;
      const spr = f.frames[Math.min(f.frames.length - 1, ((f.t / f.dur) * f.frames.length) | 0)];
      ctx.drawImage(spr, Math.round(f.x - cx - spr.width / 2), Math.round(f.y - cy - spr.height / 2));
    }
  }

  // draw calls are queued in reusable records and depth-sorted, so a frame allocates nothing
  const K_GATE = 0;
  const K_BRAZIER = 1;
  const K_EMBER = 2;
  const K_SHADE = 3;
  const K_PLAYER = 4;
  const K_BOOK = 5;
  const drawPool: DrawItem[] = [];
  const drawList: DrawItem[] = [];
  const byDepth = (a: DrawItem, b: DrawItem) => a.y - b.y;
  const view = { x0: 0, x1: 0, y0: 0, y1: 0 };

  function inView(x: number, y: number): boolean {
    return x > view.x0 && x < view.x1 && y > view.y0 && y < view.y1;
  }

  function queue(y: number, kind: number, ref: Brazier | Ember | Shade | null): void {
    let it = drawPool[drawList.length];
    if (!it) {
      it = { y: 0, kind: 0, ref: null };
      drawPool.push(it);
    }
    it.y = y;
    it.kind = kind;
    it.ref = ref;
    drawList.push(it);
  }

  const wave = reduceMotion ? 0.25 : 1;
  const tentX = new Int16Array(24);
  const tentY = new Int16Array(24);

  // ---- keeping the octopus in the water ------------------------------------------------
  // Nothing an octopus is made of is drawn straight to the screen. Its head, its arms, the
  // shape it makes under the surface and the ink it leaves are all painted onto this small
  // layer first: its own tile and the eight around it. The layer is then cut, pixel by
  // pixel, with the level's open-water stencil, and only what survives is stamped onto the
  // screen. The stencil leaves out dry land and the bank drawn along a pool's edge, so no
  // part of an octopus can show outside its pool or over the pool's rim.
  const octoLayer = document.createElement('canvas');
  octoLayer.width = OL;
  octoLayer.height = OL;
  const og = octoLayer.getContext('2d') as CanvasRenderingContext2D;
  og.imageSmoothingEnabled = false;

  /** Cuts the layer to open water and stamps it where the tile at (wx, wy) is on screen. */
  function octoFlush(wx: number, wy: number, cx: number, cy: number): void {
    const x0 = (Math.floor(wx / TILE) - 1) * TILE;
    const y0 = (Math.floor(wy / TILE) - 1) * TILE;
    og.globalCompositeOperation = 'destination-in';
    og.drawImage(level.mask, x0, y0, OL, OL, 0, 0, OL, OL);
    og.globalCompositeOperation = 'source-over';
    ctx.drawImage(octoLayer, x0 - cx, y0 - cy);
  }

  /** An arm: dark-edged, two pixels thick at the root and one at the tip, with pale suckers. */
  function tentacle(
    x: number,
    y: number,
    len: number,
    ang: number,
    curl: number,
    ph: number,
    amp: number,
    camo: boolean,
    thin = false,
  ): void {
    const n = Math.min(24, Math.round(len));
    if (n < 2) return;
    let px = x;
    let py = y;
    for (let i = 0; i < n; i++) {
      const t = i / n;
      const a = ang + curl * t * t + Math.sin(ph + i * 0.55) * amp * t;
      px += Math.cos(a);
      py += Math.sin(a);
      tentX[i] = Math.round(px);
      tentY[i] = Math.round(py);
    }
    const thick = thin ? 0 : Math.ceil(n * 0.5);
    og.fillStyle = camo ? CAMO_D : OCTO_D;
    for (let i = 0; i < n; i++) {
      const z = i < thick ? 2 : 1;
      og.fillRect(tentX[i] - 1, tentY[i], z + 2, z);
      og.fillRect(tentX[i], tentY[i] - 1, z, z + 2);
    }
    og.fillStyle = camo ? CAMO_M : OCTO_M;
    for (let i = 0; i < n; i++) {
      const z = i < thick ? 2 : 1;
      og.fillRect(tentX[i], tentY[i], z, z);
    }
    og.fillStyle = camo ? CAMO_L : OCTO_L;
    for (let i = 0; i < thick; i += 2) og.fillRect(tentX[i], tentY[i], 1, 1);
    og.fillStyle = camo ? CAMO_H : OCTO_H;
    for (let i = 2; i < n - 1; i += 3) {
      og.fillRect(tentX[i] + (i < thick ? 1 : 0), tentY[i] + (i < thick ? 1 : 0), 1, 1);
    }
    og.fillRect(tentX[n - 1], tentY[n - 1], 1, 1);
  }

  /** Stamps the head so that `rise` rows of it stand above the waterline `wl`. Returns its left edge. */
  function octoHead(spr: Sprite, rise: number, w: number, wl: number): number {
    const rows = Math.round(rise);
    const x = OC - (w >> 1);
    if (rows > 0) og.drawImage(spr, 0, 0, HEAD_W, Math.min(HEAD_H, rows), x, wl - rows, w, rows);
    return x;
  }

  /**
   * The eyes sit on rows 3-4 of the head, so they show only once it has risen that far.
   * mood: 0 watching, 1 glaring, 2 wide, 3 gleeful, 4 shut.
   */
  function octoEyes(x: number, top: number, w: number, rows: number, mood: number, look: number, camo: boolean): void {
    const vis = Math.min(2, rows - 3);
    if (vis <= 0) return;
    const lx = x + 2;
    const rx = x + w - 5;
    const y = top + 3;
    if (mood === 3) {
      // squeezed shut with glee: ^ ^
      if (vis < 2) return;
      og.fillStyle = OCTO_EYE;
      og.fillRect(lx, y + 1, 1, 1);
      og.fillRect(lx + 1, y, 1, 1);
      og.fillRect(lx + 2, y + 1, 1, 1);
      og.fillRect(rx, y + 1, 1, 1);
      og.fillRect(rx + 1, y, 1, 1);
      og.fillRect(rx + 2, y + 1, 1, 1);
      return;
    }
    if (mood === 4) {
      og.fillStyle = camo ? CAMO_D : OCTO_D;
      og.fillRect(lx, y + vis - 1, 3, 1);
      og.fillRect(rx, y + vis - 1, 3, 1);
      return;
    }
    og.fillStyle = camo ? CAMO_H : OCTO_EYE;
    og.fillRect(lx, y, 3, vis);
    og.fillRect(rx, y, 3, vis);
    og.fillStyle = OCTO_PUPIL;
    if (mood === 2) {
      // wide with anticipation: pinprick pupils fixed on its catch
      og.fillRect(lx + 1, y, 1, 1);
      og.fillRect(rx + 1, y, 1, 1);
      return;
    }
    og.fillRect(lx + 1 + look, y, 1, vis);
    og.fillRect(rx + 1 + look, y, 1, vis);
    if (mood === 1) {
      // heavy brows slanting in
      og.fillStyle = OCTO_D;
      og.fillRect(lx + 2, y, 1, 1);
      og.fillRect(rx, y, 1, 1);
    }
  }

  /**
   * A lurking octopus, always in the colours of the water. Under the surface it is eight arms
   * swaying round a dark mantle; above it, at most a crown and two eyes.
   */
  function paintLurk(o: Octo): void {
    og.fillStyle = SUB_ARM;
    for (let i = 0; i < 8; i++) {
      let a = (i / 8) * Math.PI * 2 + 0.39 + Math.sin(o.ph * 0.9 + i * 1.7) * 0.25 * wave;
      const len = 6 + Math.sin(o.ph * 1.3 + i * 2.1) * 1.3;
      let px = OC;
      let py = OC + 2;
      for (let s = 0; s < len; s++) {
        a += Math.sin(o.ph * 2 + s * 0.8 + i) * 0.14 * wave;
        px += Math.cos(a);
        py += Math.sin(a) * 0.62;
        const z = s < 3 ? 2 : 1;
        og.fillRect(Math.round(px), Math.round(py), z, z);
      }
    }
    const body = S.octoSub[Math.floor(o.ph * 1.4) % 2];
    og.drawImage(body, OC - (body.width >> 1), OC + 2 - (body.height >> 1));
    // a slow ring spreading over it
    const cyc = (o.ph * 0.45 + o.x * 0.03) % 1.6;
    if (cyc < 1) {
      const rr = 3 + cyc * 4.5;
      og.fillStyle = cyc < 0.45 ? '#4c88bd' : '#2e6396';
      for (let a = cyc < 0.45 ? 0 : 1; a < 12; a += 2) {
        og.fillRect(Math.round(OC + RING_X[a] * rr), Math.round(OC + 3 + RING_Y[a] * rr * 0.5), 1, 1);
      }
    }
    const rows = Math.round(o.rise);
    if (rows > 0) {
      const x = octoHead(S.octoCamo[Math.floor(o.ph * 2) % 2], rows, HEAD_W, WL_LURK);
      const look = clamp(Math.round((player.x - o.x) / 14), -1, 1);
      const blink = (o.ph * 0.8 + o.x * 0.13) % 3.1 < 0.14;
      octoEyes(x, WL_LURK - rows, HEAD_W, rows, blink ? 4 : 0, look, true);
      // one arm tip tests the air
      if (rows >= 3) tentacle(OC + 4, WL_LURK, 2 + rows * 0.6, -Math.PI / 2 + 0.2, 0.9, o.ph * 2.4, 0.8 * wave, true);
      // the surface laps at whatever breaks it
      const lap = Math.floor(o.ph * 4) % 2;
      og.fillStyle = CAMO_H;
      og.fillRect(OC - 7 + lap, WL_LURK, 3, 1);
      og.fillRect(OC + 4 - lap, WL_LURK, 3, 1);
    }
  }

  /**
   * Behind its catch: arms rising out of the water on either side of the flame. Where there is
   * open water beside it the arms sprawl; against a bank they stay tight to the head.
   */
  function paintBack(o: Octo, openL: boolean, openR: boolean): void {
    const grab = o.state === 'grab';
    const k = grab ? clamp((OCTO_HOLD_T - o.t) / 0.22, 0, 1) : clamp(o.t / 0.4, 0, 1);
    const grow = grab ? easeOutBack(k) : k;
    const ph = o.ph * 2.6;
    const whip = o.sq * 0.9;
    for (let side = -1; side <= 1; side += 2) {
      // each arm is rooted just inside the head, clear of the bank even in a pool one tile wide
      const bx = OC + side * 5 - (side < 0 ? 0 : 1);
      if (side < 0 ? openL : openR) {
        tentacle(bx + side, WL - 1, 14 * grow, -Math.PI / 2 + side * 0.6, -side * (1.5 + whip), ph + side, 0.6 * wave, false);
        tentacle(bx + side * 2, WL, 9 * grow, side < 0 ? Math.PI + 0.25 : -0.25, -side * 1.1, ph * 1.5 + side * 2, wave, false);
      } else {
        tentacle(bx, WL - 1, 11 * grow, -Math.PI / 2, -side * (0.9 + whip), ph + side, 0.4 * wave, false);
      }
    }
  }

  /**
   * In front of its catch: two slim arms coiled round the flame, and the low dome of the head
   * glaring up out of the water. `fx` is the flame's centre on the layer.
   */
  function paintFront(o: Octo, tier: number, fx: number, coils: boolean): void {
    const grab = o.state === 'grab';
    const k = grab ? clamp((OCTO_HOLD_T - o.t) / 0.22, 0, 1) : clamp(o.t / 0.4, 0, 1);
    if (coils) {
      const hw = 5 - tier;
      const small = tier === 2;
      const tight = Math.round(o.sq * 1.8);
      const ph = o.ph * 3.6;
      // one coil across the brow and one round the waist, leaving the face between them clear
      tentacle(fx + hw + 1 - tight, OC - (small ? 4 : 5), (hw * 2 + 2) * k, Math.PI - 0.06, 0.45, ph + 2, 0.25 * wave, false, true);
      if (!small) tentacle(fx - hw - 2 + tight, OC, (hw * 2 + 2) * k, 0.06, -0.5, ph, 0.25 * wave, false, true);
    }
    const rows = Math.round(o.rise);
    if (rows > 0) {
      const squeezing = grab && o.sq > 0.4;
      const windup = grab && !squeezing && o.rise > GRAB_RISE + 1;
      // it flattens as it bears down and stretches tall as it rears up
      const w = squeezing ? HEAD_W + 1 : windup ? HEAD_W - 1 : HEAD_W;
      const flash = o.flash > 0;
      const x = octoHead(flash ? S.octoFlash : S.octoHead[Math.floor(o.ph * 2.5) % 2], rows, w, WL);
      if (!flash) octoEyes(x, WL - rows, w, rows, !grab ? 4 : squeezing ? 3 : windup ? 2 : 1, 0, false);
      // churned water where it breaks the surface
      const lap = Math.floor(o.ph * 6) % 2;
      og.fillStyle = FOAM;
      for (let i = 0; i < 3; i++) og.fillRect(OC - 6 + i * 5 + lap, WL, 2, 1);
    }
  }

  /** The ink it leaves as it sinks: a blot that spreads, thins and breaks up. */
  function paintInk(k: Ink): void {
    const a = k.t / INK_T;
    const r = 3 + easeOut(a) * 5;
    for (let i = 0; i < 26; i++) {
      // a fixed scatter, so the cloud keeps its shape while it grows
      if (((i * 7 + 3) % 10) / 10 < a * 1.15 - 0.25) continue;
      const ang = i * 2.399 + k.x * 0.37;
      const d = r * Math.sqrt((i + 0.5) / 26);
      og.fillStyle = OCTO_INK[i % 3];
      const z = a < 0.5 && i % 2 === 0 ? 2 : 1;
      og.fillRect(Math.round(OC + Math.cos(ang) * d), Math.round(OC + 2 + Math.sin(ang) * d * 0.6), z, z);
    }
  }

  function drawOctoLurk(o: Octo, cx: number, cy: number): void {
    og.clearRect(0, 0, OL, OL);
    paintLurk(o);
    octoFlush(o.x, o.y, cx, cy);
  }

  /** Also drawn, with the front, as it sinks away. */
  function drawOctoBack(o: Octo, cx: number, cy: number): void {
    const tx = Math.floor(o.x / TILE);
    const ty = Math.floor(o.y / TILE);
    og.clearRect(0, 0, OL, OL);
    paintBack(o, waterAt(tx - 1, ty), waterAt(tx + 1, ty));
    octoFlush(o.x, o.y, cx, cy);
  }

  function drawOctoFront(o: Octo, cx: number, cy: number, tier: number): void {
    og.clearRect(0, 0, OL, OL);
    paintFront(o, tier, OC + Math.round(player.x - o.x), o.state === 'grab');
    octoFlush(o.x, o.y, cx, cy);
  }

  function drawInk(k: Ink, cx: number, cy: number): void {
    og.clearRect(0, 0, OL, OL);
    paintInk(k);
    octoFlush(k.x, k.y, cx, cy);
  }

  let portraitCache: Record<CreatureId, string[]> | null = null;

  /** Small scenes for the guide book, painted by the same code that draws each creature in the game. */
  function makePortraits(): Record<CreatureId, string[]> {
    const W = 44;
    const H = 30;
    const c = document.createElement('canvas');
    c.width = W;
    c.height = H;
    const g = c.getContext('2d') as CanvasRenderingContext2D;
    const ground = (base: string, fleck: string) => {
      g.fillStyle = base;
      g.fillRect(0, 0, W, H);
      g.fillStyle = fleck;
      for (let i = 0; i < 16; i++) g.fillRect((i * 29 + 5) % W, (i * 17 + 3) % H, i % 3 === 0 ? 2 : 1, 1);
    };
    const out: Record<CreatureId, string[]> = { emberling: [], shade: [], moth: [], octopus: [] };
    const mid = W >> 1;
    for (let f = 0; f < 4; f++) {
      // the emberling, flickering in its own light
      ground('#3d4260', '#4a5072');
      const T = S.player[0];
      const flame = T.frames[FLICK[f]];
      const ex = mid - (flame.width >> 1);
      const ey = 23 - flame.height;
      g.drawImage(S.shadowM, mid - 4, 21);
      g.drawImage(flame, ex, ey);
      g.fillStyle = '#2a1020';
      g.fillRect(ex + T.eyeL, ey + T.eyeY, 1, 2);
      g.fillRect(ex + T.eyeR, ey + T.eyeY, 1, 2);
      out.emberling.push(c.toDataURL());

      // a shade in the dark, hem trailing, eyes lit
      ground('#1b1f33', '#232840');
      const sx = mid - 7;
      const sy = 7 + (f % 2);
      g.drawImage(S.shadowL, sx + 1, 23);
      g.drawImage(S.shade[f], sx, sy);
      g.fillStyle = '#ff4d6d';
      g.fillRect(sx + 4, sy + 5, 2, 2);
      g.fillRect(sx + 8, sy + 5, 2, 2);
      g.fillStyle = '#ffc2cf';
      g.fillRect(sx + 4, sy + 5, 1, 1);
      g.fillRect(sx + 8, sy + 5, 1, 1);
      out.shade.push(c.toDataURL());

      // a moth on the wing
      ground('#2a3048', '#333a56');
      const moth = S.moth[FLICK[f]];
      g.drawImage(S.shadowS, mid - 2, 22);
      g.drawImage(moth, mid - (moth.width >> 1), 10 + (f % 2));
      out.moth.push(c.toDataURL());
    }
    // the octopus as it looks with a catch: out of hiding, arms up, glaring
    const o = makeOcto(0, 0, 0);
    o.state = 'grab';
    o.t = OCTO_HOLD_T - 0.6;
    o.rise = GRAB_RISE;
    for (let f = 0; f < 6; f++) {
      o.ph = f * 0.403;
      ground('#1d3f66', '#2e6396');
      og.clearRect(0, 0, OL, OL);
      paintBack(o, true, true);
      g.drawImage(octoLayer, mid - OC, -8);
      og.clearRect(0, 0, OL, OL);
      paintFront(o, 0, OC, false);
      g.drawImage(octoLayer, mid - OC, -8);
      out.octopus.push(c.toDataURL());
    }
    return out;
  }

  /** The guide book on its lectern. A glint crosses the open pages now and then. */
  function drawBook(cx: number, cy: number): void {
    if (!book) return;
    const bx = Math.round(book.x - cx) - 7;
    const by = Math.round(book.y - cy) - 9;
    ctx.drawImage(S.shadowL, bx + 2, by + 9);
    ctx.drawImage(S.lectern, bx, by);
    const sweep = (time * 0.9) % 2.6;
    if (sweep < 0.45 && !reduceMotion) {
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(bx + 1 + Math.floor((sweep / 0.45) * 13), by + 1, 1, 5);
    }
  }

  function drawEntities(cx: number, cy: number): void {
    drawList.length = 0;
    view.x0 = cx - 24;
    view.x1 = cx + VW + 24;
    view.y0 = cy - 28;
    view.y1 = cy + VH + 28;

    // ink first, then the octopuses: both sit in the water, beneath everything that walks or floats
    for (const k of inks) {
      if (inView(k.x, k.y)) drawInk(k, cx, cy);
    }
    for (const o of octos) {
      if (o.state === 'grab' || !inView(o.x, o.y)) continue;
      if (o.state === 'vanish') {
        drawOctoBack(o, cx, cy);
        drawOctoFront(o, cx, cy, 0);
      } else drawOctoLurk(o, cx, cy);
    }

    // dash afterimages cool from yellow to dark red
    for (const gh of ghosts) {
      const spr = S.player[gh.tier].sil[Math.min(3, (gh.t / 0.05) | 0)];
      ctx.drawImage(spr, Math.round(gh.x - cx) - (spr.width >> 1), Math.round(gh.y - cy) + 4 - spr.height);
    }

    if (inView(gate.x, gate.y)) queue(gate.y - 2, K_GATE, null);
    for (const b of braziers) {
      if (inView(b.x, b.y)) queue(b.y, K_BRAZIER, b);
    }
    for (const e of embers) {
      if (inView(e.x, e.y)) queue(e.y - 4, K_EMBER, e);
    }
    for (const s of shades) {
      if (s.state !== 'gone' && inView(s.x, s.y)) queue(s.y, K_SHADE, s);
    }
    if (book && inView(book.x, book.y)) queue(book.y, K_BOOK, null);
    queue(player.y, K_PLAYER, null);
    drawList.sort(byDepth);
    for (let i = 0; i < drawList.length; i++) {
      const d = drawList[i];
      if (d.kind === K_SHADE) drawShade(d.ref as Shade, cx, cy);
      else if (d.kind === K_EMBER) drawEmber(d.ref as Ember, cx, cy);
      else if (d.kind === K_BRAZIER) drawBrazier(d.ref as Brazier, cx, cy);
      else if (d.kind === K_GATE) drawGate(Math.round(gate.x - cx) - 10, Math.round(gate.y - cy) - 15);
      else if (d.kind === K_BOOK) drawBook(cx, cy);
      else drawPlayer(cx, cy);
    }

    for (const m of moths) {
      if (!inView(m.x, m.y)) continue;
      const mx = Math.round(m.x - cx);
      const my = Math.round(m.y - cy);
      if (tileAt(m.x, m.y + 9) !== T_WALL) ctx.drawImage(S.shadowS, mx - 2, my + 8);
      ctx.drawImage(S.moth[FLICK[Math.floor(m.ph * 16) % 4]], mx - 5, my - 3);
    }
  }

  /** Things that glow through the darkness. */
  function drawGlows(cx: number, cy: number): void {
    // bioluminescent mushrooms and crystals twinkle faintly in the dark
    for (const g of level.glints) {
      const sx = g.x - cx;
      const sy = g.y - cy;
      if (sx < 0 || sx >= VW || sy < 0 || sy >= VH) continue;
      const ph = (time * 0.8 + ((g.x * 13 + g.y * 7) % 23) * 0.31) % 3;
      ctx.fillStyle = ph < 0.2 ? '#e9fffb' : ph < 1.6 ? '#2f8f9a' : '#215f6b';
      ctx.fillRect(sx, sy, 1, 1);
    }
    for (const s of shades) {
      if (s.state === 'gone' || s.state === 'burn') continue;
      if (s.rise > RISE_T * 0.45) continue;
      const sx = Math.round(s.x - cx) - 7 + (s.lit && !reduceMotion && Math.floor(time * 40) % 2 === 1 ? 1 : 0);
      const sy = Math.round(s.y - cy) - 11 + Math.round(Math.sin(s.ph * 3) * 1.2);
      if (sx < -16 || sx > VW + 2 || sy < -16 || sy > VH + 2) continue;
      if ((s.ph * 0.9) % 4.3 < 0.13) continue;
      const look = clamp(Math.round((player.x - s.x) / 24), -1, 1);
      const lx = sx + 4 + look;
      const rx = sx + 8 + look;
      const ey = sy + 5;
      if (s.lit) {
        // squinting against the light
        ctx.fillStyle = '#ff4d6d';
        ctx.fillRect(lx, ey + 1, 2, 1);
        ctx.fillRect(rx, ey + 1, 2, 1);
      } else if (s.state === 'hunt') {
        // angry slant; flashes white the moment it notices you
        ctx.fillStyle = s.alert > 0 ? '#fff1c2' : '#ff4d6d';
        ctx.fillRect(lx, ey, 1, 2);
        ctx.fillRect(lx + 1, ey + 1, 1, 1);
        ctx.fillRect(rx + 1, ey, 1, 2);
        ctx.fillRect(rx, ey + 1, 1, 1);
        ctx.fillStyle = '#ffc2cf';
        ctx.fillRect(lx, ey, 1, 1);
        ctx.fillRect(rx + 1, ey, 1, 1);
      } else {
        ctx.fillStyle = '#ff4d6d';
        ctx.fillRect(lx, ey, 2, 2);
        ctx.fillRect(rx, ey, 2, 2);
        ctx.fillStyle = '#ffc2cf';
        ctx.fillRect(lx, ey, 1, 1);
        ctx.fillRect(rx, ey, 1, 1);
      }
    }
    // cold coals smoulder faintly so unlit braziers can be spotted
    for (const b of braziers) {
      if (b.lit) continue;
      const sx = Math.round(b.x - cx);
      const sy = Math.round(b.y - cy);
      if (sx < -6 || sx > VW + 6 || sy < -6 || sy > VH + 6) continue;
      const ph = Math.floor(time * 3 + b.x) % 4;
      ctx.fillStyle = ph === 0 ? '#ff9a3c' : '#9c2a3a';
      ctx.fillRect(sx - 3 + ph * 2, sy - 8, 1, 1);
      if (ph === 2) ctx.fillRect(sx - 2, sy - 7, 1, 1);
    }
    if (runesLit() > 0) {
      const gx = Math.round(gate.x - cx) - 10;
      const gy = Math.round(gate.y - cy) - 15;
      if (gx > -22 && gx < VW + 2 && gy > -20 && gy < VH + 2) drawRunes(gx, gy);
    }
    for (const m of moths) {
      if (!m.carry) continue;
      ctx.fillStyle = '#ffd15c';
      ctx.fillRect(Math.round(m.x - cx), Math.round(m.y - cy) + 1, 1, 1);
    }
    // hidden octopuses remain concealed in dark puddles; only an admin debug toggle or faint explored water shimmer shows them
    for (const o of octos) {
      const sx = Math.round(o.x - cx);
      const sy = Math.round(o.y - cy);
      if (sx < -16 || sx > VW + 16 || sy < -16 || sy > VH + 16) continue;
      if (revealOctos) {
        ctx.fillStyle = o.state === 'grab' ? '#ff4d6d' : '#6fe3d2';
        ctx.fillRect(sx - 9, sy - 7, 18, 1);
        ctx.fillRect(sx - 9, sy + 7, 18, 1);
        ctx.fillRect(sx - 9, sy - 7, 1, 15);
        ctx.fillRect(sx + 8, sy - 7, 1, 15);
        text('OCTO', sx, sy - 14, '#6fe3d2', 1, 1);
        continue;
      }
      if (o.state !== 'lurk') continue;
      // only if the puddle was already explored and the octopus is peeking close by, hint with 1px dark-water glint
      const tx = Math.floor(o.x / TILE);
      const ty = Math.floor(o.y / TILE);
      if (tx >= 0 && ty >= 0 && tx < level.w && ty < level.h && explored[ty * level.w + tx]) {
        const pulse = (o.ph * 0.45 + o.x * 0.03) % 1.4;
        if (pulse < 0.4) {
          ctx.fillStyle = '#2e6396';
          ctx.fillRect(sx - 3, sy + 3, 1, 1);
          ctx.fillRect(sx + 3, sy + 3, 1, 1);
        }
      }
    }
    // flare shockwave
    for (const f of flares) {
      const fade = f.t / 0.55;
      if (fade >= 1) continue;
      ctx.fillStyle = fade < 0.4 ? '#fff1c2' : fade < 0.7 ? '#ffd15c' : '#ff9a3c';
      const n = Math.max(20, Math.floor(f.r * 1.6));
      for (let i = 0; i < n; i++) {
        if (fade > 0.5 && i % 2 === 0) continue;
        const a = (i / n) * Math.PI * 2;
        ctx.fillRect(Math.round(f.x - cx + Math.cos(a) * f.r), Math.round(f.y - cy + Math.sin(a) * f.r), 1, 1);
      }
    }
    let lastCol = '';
    for (const p of parts) {
      const sx = Math.round(p.x - cx);
      const sy = Math.round(p.y - cy);
      if (sx < -2 || sy < -2 || sx > VW || sy > VH) continue;
      const col = p.ramp[Math.min(p.ramp.length - 1, ((1 - p.life / p.max) * p.ramp.length) | 0)];
      if (col !== lastCol) {
        ctx.fillStyle = col;
        lastCol = col;
      }
      const sz = p.big ? 2 : 1;
      ctx.fillRect(sx, sy, sz, sz);
    }
    drawFx(cx, cy, true);
    for (const f of floaters) {
      // numbers pop up with a little overshoot
      const age = 0.9 - f.t;
      const pop = age < 0.12 ? Math.round((1 - age / 0.12) * 3) : 0;
      text(f.text, f.x - cx, Math.round(f.y - cy) + pop, f.color, 1, 1);
    }
  }

  /** An arrow at the screen edge (or a bobbing marker) pointing at the next objective. */
  function drawIndicator(cx: number, cy: number): void {
    let tx = 0;
    let ty = 0;
    let found = false;
    if (gateOpen) {
      tx = gate.x;
      ty = gate.y - 6;
      found = true;
    } else {
      let bd = Infinity;
      for (const b of braziers) {
        if (b.lit) continue;
        const d = (b.x - player.x) * (b.x - player.x) + (b.y - player.y) * (b.y - player.y);
        if (d < bd) {
          bd = d;
          tx = b.x;
          ty = b.y - 4;
          found = true;
        }
      }
    }
    if (!found) return;
    const sx = tx - cx;
    const sy = ty - cy;
    const l = safe.l + 7;
    const r = VW - safe.r - 7;
    const t = safe.t + 28;
    const b = VH - safe.b - 9;
    if (sx >= l && sx <= r && sy >= t && sy <= b) {
      // on screen but still hidden in the dark: hover a marker above it
      const lit = playerRadius() * 0.7;
      if ((tx - player.x) * (tx - player.x) + (ty - player.y) * (ty - player.y) > lit * lit) {
        const bob = Math.round(Math.sin(time * 4) * 1.5);
        ctx.drawImage(gateOpen ? S.markerGate : S.markerFire, Math.round(sx) - 3, Math.round(sy) - 20 + bob);
      }
      return;
    }
    const px = player.x - cx;
    const py = player.y - cy;
    const dx = sx - px;
    const dy = sy - py;
    let k = 1;
    if (dx > 0) k = Math.min(k, (r - px) / dx);
    else if (dx < 0) k = Math.min(k, (l - px) / dx);
    if (dy > 0) k = Math.min(k, (b - py) / dy);
    else if (dy < 0) k = Math.min(k, (t - py) / dy);
    k = Math.max(0, k);
    const ang = Math.atan2(dy, dx);
    const oct = ((Math.round(ang / (Math.PI / 4)) % 8) + 8) % 8;
    // the arrow nudges back and forth along its own direction
    const push = reduceMotion ? 0 : (Math.sin(time * 7) + 1) * 1.5;
    const ix = Math.round(clamp(px + dx * k, l, r) - Math.cos(ang) * push);
    const iy = Math.round(clamp(py + dy * k, t, b) - Math.sin(ang) * push);
    ctx.drawImage((gateOpen ? S.arrowGate : S.arrowFire)[oct], ix - 3, iy - 3);
  }

  function activeMode(): InputMode {
    return forcedInput === 'auto' ? inputMode : forcedInput;
  }

  function btnRects(): { pause: { x: number; y: number }; mute: { x: number; y: number }; admin: { x: number; y: number } } {
    const y = safe.t + 4;
    const x = VW - safe.r - 4 - 13;
    return { pause: { x, y }, mute: { x: x - 19, y }, admin: { x: x - 38, y } };
  }

  function hudAdminRect(): { x: number; y: number } {
    return { x: safe.l + 4, y: safe.t + 23 };
  }

  function flarePos(): { x: number; y: number } {
    return { x: VW - safe.r - 20, y: VH - safe.b - 28 };
  }

  /** On narrow portrait screens the dash button sits neatly above the flare along the right thumb arc. */
  function dashPos(): { x: number; y: number } {
    if (VW - safe.l - safe.r < 170) return { x: VW - safe.r - 24, y: VH - safe.b - 68 };
    return { x: VW - safe.r - 53, y: VH - safe.b - 24 };
  }

  function staticJoyPos(): { x: number; y: number } {
    const r = Math.round(JOY_R_STATIC * joyScale);
    return { x: safe.l + r + 4, y: VH - safe.b - r - 7 };
  }

  function drawBtn(x: number, y: number, icon: Sprite): void {
    ctx.fillStyle = 'rgba(7,6,22,0.72)';
    ctx.fillRect(x, y, 13, 13);
    ctx.fillStyle = '#4a4d68';
    ctx.fillRect(x + 1, y, 11, 1);
    ctx.fillRect(x + 1, y + 12, 11, 1);
    ctx.fillRect(x, y + 1, 1, 11);
    ctx.fillRect(x + 12, y + 1, 1, 11);
    ctx.drawImage(icon, x + 3, y + 3);
  }

  function segW(v: number, i: number): number {
    return clamp(Math.round(((v - i * 10) / 10) * 4), 0, 4);
  }

  function drawHud(): void {
    const shx = hudShake > 0 && !reduceMotion ? Math.round((Math.random() - 0.5) * 3) : 0;
    const x0 = safe.l + 4 + shx;
    const y0 = safe.t + 4;
    const low = player.fuel < 22;
    const blink = low && Math.floor(time * 5) % 2 === 0;

    // flame meter
    ctx.drawImage(blink ? S.hudFlameDim : S.hudFlame[Math.floor(time * 6) % 2], x0, y0);
    const bx = x0 + 8;
    const by = y0 + 1;
    ctx.fillStyle = INK;
    ctx.fillRect(bx - 1, by - 1, 51, 7);
    for (let i = 0; i < 10; i++) {
      const sx = bx + i * 5;
      ctx.fillStyle = '#2b2648';
      ctx.fillRect(sx, by, 4, 5);
      const gw = segW(fuelGhost, i);
      if (gw > 0) {
        ctx.fillStyle = '#ff4d6d';
        ctx.fillRect(sx, by, gw, 5);
      }
      const fw = segW(fuelShown, i);
      if (fw > 0) {
        ctx.fillStyle =
          gainFlash > 0 ? '#fff1c2' : low ? (blink ? '#9c2a3a' : '#e8552d') : i < 3 ? '#e8552d' : i < 6 ? '#ff9a3c' : '#ffd15c';
        ctx.fillRect(sx, by, fw, 5);
        ctx.fillStyle = 'rgba(255,241,194,0.35)';
        ctx.fillRect(sx, by, fw, 1);
        ctx.fillStyle = 'rgba(7,6,22,0.22)';
        ctx.fillRect(sx, by + 4, fw, 1);
      }
    }
    // brazier pips pop when lit
    for (let i = 0; i < braziers.length; i++) {
      const b = braziers[i];
      if (!b.lit) ctx.drawImage(S.pipUnlit, x0 + i * 7, y0 + 10);
      else if (b.litT < 0.3) ctx.drawImage(S.pipPop, x0 + i * 7, y0 + 8);
      else ctx.drawImage(S.pipLit, x0 + i * 7, y0 + 10);
    }
    if (gateOpen && Math.floor(time * 3) % 2 === 0) {
      ctx.drawImage(S.markerGate, x0 + braziers.length * 7 + 1, y0 + 9);
    }

    // buttons + run info
    const br = btnRects();
    drawBtn(br.pause.x, br.pause.y, S.iconPause);
    drawBtn(br.mute.x, br.mute.y, sfx.muted ? S.iconMuted : S.iconSound);
    if (showHudAdmin) {
      const ha = hudAdminRect();
      drawBtn(ha.x, ha.y, S.iconAdmin);
    }
    const rx = VW - safe.r - 4;
    text('DEPTH ' + depth, rx, y0 + 17, '#9a9fb8', 1, 2);
    const cnt = String(embersTotal);
    text(cnt, rx, y0 + 25, '#ffd15c', 1, 2);
    ctx.drawImage(S.ember[2], rx - textWidth(cnt) - 8, y0 + 24);
  }

  /** A round action button that refills from the bottom while it cools down. */
  function drawButton(set: Sprite[], r: number, x: number, y: number, ready: number, pressed: boolean, usable: boolean): void {
    const d = r * 2 + 1;
    const py = pressed ? 1 : 0;
    ctx.drawImage(set[0], x - r, y - r + py);
    if (pressed) ctx.drawImage(set[2], x - r, y - r + py);
    else if (usable) {
      const rows = Math.round(d * ready);
      if (rows > 0) ctx.drawImage(set[1], 0, d - rows, d, rows, x - r, y - r + d - rows, d, rows);
    }
  }

  function drawScaled(spr: Sprite, cx: number, cy: number, sc: number): void {
    if (Math.abs(sc - 1) < 0.02) {
      ctx.drawImage(spr, Math.round(cx - spr.width / 2), Math.round(cy - spr.height / 2));
      return;
    }
    const w = Math.round(spr.width * sc);
    const h = Math.round(spr.height * sc);
    ctx.drawImage(spr, Math.round(cx - w / 2), Math.round(cy - h / 2), w, h);
  }

  function drawControls(): void {
    const mode = activeMode();
    const fp = flarePos();
    const dp = dashPos();
    const canFlare = godMode || noCooldowns || player.fuel > FLARE_COST + 4;
    const canDash = godMode || noCooldowns || player.fuel > DASH_COST + 2;
    const fReady = noCooldowns ? 1 : clamp(1 - player.flareCd / FLARE_CD, 0, 1);
    const dReady = noCooldowns ? 1 : clamp(1 - player.dashCd / DASH_CD, 0, 1);
    const fOn = canFlare && fReady >= 1;
    const dOn = canDash && dReady >= 1;

    drawButton(S.btnFlare, 15, fp.x, fp.y, nearBook ? 1 : fReady, flarePressT > 0, nearBook || canFlare);
    if (nearBook) ctx.drawImage(S.iconBook, fp.x - 3, fp.y - 2);
    else ctx.drawImage(fOn ? S.hudFlame[Math.floor(time * 6) % 2] : S.hudFlameDim, fp.x - 2, fp.y - 3 + (flarePressT > 0 ? 1 : 0));
    drawButton(S.btnDash, 11, dp.x, dp.y, dReady, dashPressT > 0, canDash);
    ctx.drawImage(dOn ? S.iconDash : S.iconDashDim, dp.x - 3, dp.y - 2 + (dashPressT > 0 ? 1 : 0));

    const fl = mode === 'touch' ? (nearBook ? 'READ' : 'FLARE') : mode === 'pad' ? 'A' : 'SPACE';
    const dl = mode === 'touch' ? 'DASH' : mode === 'pad' ? 'B' : 'SHIFT';
    text(fl, fp.x + 1, fp.y + 18, fOn || nearBook ? '#ffd15c' : '#6b6f8a', 1, 1);
    text(dl, dp.x + 1, dp.y + 14, dOn ? '#6fe3d2' : '#6b6f8a', 1, 1);

    if (staticJoy) {
      const sj = staticJoyPos();
      const kx = joy.active ? Math.round(joy.kx) : 0;
      const ky = joy.active ? Math.round(joy.ky) : 0;
      if (!joy.active) ctx.globalAlpha = 0.65;
      drawScaled(joy.active ? S.ringStaticHot : S.ringStatic, sj.x, sj.y, joyScale);
      drawScaled(S.knobStatic, sj.x + kx, sj.y + ky, joyScale);
      ctx.globalAlpha = 1;
    } else if (joy.active) {
      drawScaled(S.ringHot, Math.round(joy.ox), Math.round(joy.oy), joyScale);
      drawScaled(S.knob, Math.round(joy.ox + joy.kx), Math.round(joy.oy + joy.ky), joyScale);
    } else if (mode === 'touch') {
      const r = Math.round(JOY_R * joyScale);
      const jx = safe.l + r + 8;
      const jy = VH - safe.b - r - 10;
      ctx.globalAlpha = 0.42;
      drawScaled(S.ring, jx, jy, joyScale);
      drawScaled(S.knob, jx, jy, joyScale);
      ctx.globalAlpha = 1;
    }
    if (mouse.down && Math.floor(time * 8) % 2 === 0) {
      ctx.drawImage(S.reticle, Math.round(mouse.x) - 2, Math.round(mouse.y) - 2);
    }
  }

  function drawHitFlash(): void {
    const t = Math.max(1, Math.ceil((hitFlash / 0.25) * 3));
    ctx.fillStyle = hitPattern ?? '#e8552d';
    ctx.fillRect(0, 0, VW, t);
    ctx.fillRect(0, VH - t, VW, t);
    ctx.fillRect(0, t, t, VH - t * 2);
    ctx.fillRect(VW - t, t, t, VH - t * 2);
  }

  function drawIris(k: number, cx: number, cy: number): void {
    const px = Math.round(player.x - cx);
    const py = Math.round(player.y - cy - 3);
    const maxR = Math.hypot(Math.max(px, VW - px), Math.max(py, VH - py)) + 2;
    const R = maxR * k;
    ctx.fillStyle = INK;
    for (let y = 0; y < VH; y++) {
      const dy = y - py;
      if (Math.abs(dy) >= R) {
        ctx.fillRect(0, y, VW, 1);
        continue;
      }
      const hw = Math.floor(Math.sqrt(R * R - dy * dy));
      if (px - hw > 0) ctx.fillRect(0, y, px - hw, 1);
      if (px + hw < VW) ctx.fillRect(px + hw, y, VW - px - hw, 1);
    }
  }

  function drawDepthCard(): void {
    const mid = Math.round(VW / 2);
    const y = Math.round(VH / 2) - 14;
    const k = clamp((trans.t - T_CLOSE) / 0.2, 0, 1);
    const slide = Math.round((1 - easeOut(k)) * 8);
    text('DEPTH ' + depth, mid, y + slide, TITLE_COLS, 3, 1);
    if (k >= 1) {
      const tip =
        depth === 2
          ? 'WATER DOUSES YOUR FLAME'
          : depth === 3
            ? 'MOTHS STEAL YOUR LIGHT'
            : depth === BOOK_DEPTH
              ? 'A GUIDE BOOK WAITS NEARBY'
              : depth === 6
                ? 'OCTOPUS LURK IN WATER'
              : TIPS[depth % TIPS.length];
      textWrap(tip, y + 23, '#9a9fb8');
    }
  }

  function controlsHint(): string {
    const mode = activeMode();
    if (mode === 'touch') {
      return staticJoy ? 'STICK MOVE - TAP FLARE OR DASH' : 'DRAG TO MOVE - TAP FLARE OR DASH';
    }
    if (mode === 'pad') return 'STICK MOVE - A FLARE - B DASH';
    return 'WASD MOVE - SPACE FLARE - SHIFT DASH';
  }

  function drawTitle(): void {
    ctx.fillStyle = 'rgba(7,6,22,0.3)';
    ctx.fillRect(0, 0, VW, VH);
    const mid = Math.round(VW / 2);
    const big = VW >= 200 ? 4 : 3;
    const top = safe.t + Math.max(8, Math.round(VH * 0.1));
    waveText('EMBERLING', mid, top, big);
    text('KEEP THE DARK AT BAY', mid, top + big * 5 + 6, '#9a9fb8', 1, 1);
    if (best > 0 && VH > 170) text('DEEPEST DESCENT: ' + best, mid, top + big * 5 + 16, '#6fe3d2', 1, 1);

    const lines = ['YOUR FLAME IS YOUR LIFE', 'LIGHT EVERY BRAZIER', 'LIGHT SLOWS THE SHADES'];
    const hint = controlsHint();
    const hintLines = hint.length > maxChars() ? hint.split(' - ').length : 1;
    const promptY = VH - safe.b - 13;
    let y = promptY - 8 - (lines.length + hintLines) * 8;
    for (const line of lines) y = textWrap(line, y, CREAM);
    textWrap(hint, y, '#ffd15c');
    if (Math.floor(time * 2) % 2 === 0) {
      const mode = activeMode();
      const prompt = mode === 'touch' ? 'TAP TO BEGIN' : mode === 'pad' ? 'PRESS A TO BEGIN' : 'PRESS SPACE OR CLICK';
      text(prompt, mid, promptY, '#ff9a3c', 1, 1);
    }
    const br = btnRects();
    drawBtn(br.admin.x, br.admin.y, S.iconAdmin);
    drawBtn(br.mute.x, br.mute.y, sfx.muted ? S.iconMuted : S.iconSound);
    drawBtn(br.pause.x, br.pause.y, S.iconGear);
  }

  function pauseRows(): { y: number; h: number }[] {
    const cy = Math.round(VH / 2);
    return [
      { y: cy - 12, h: 16 },
      { y: cy + 8, h: 16 },
      { y: cy + 28, h: 16 },
    ];
  }

  function drawPause(): void {
    ctx.fillStyle = 'rgba(7,6,22,0.68)';
    ctx.fillRect(0, 0, VW, VH);
    const mid = Math.round(VW / 2);
    const cy = Math.round(VH / 2);
    text('PAUSED', mid, cy - 36, TITLE_COLS, 2, 1);
    const rows = pauseRows();
    const boxW = Math.min(VW - safe.l - safe.r - 20, 96);
    const boxX = mid - Math.round(boxW / 2);
    const labels = ['RESUME', 'SETTINGS', 'ADMIN PANELS'];
    for (let i = 0; i < labels.length; i++) {
      const r = rows[i];
      const sel = pauseIdx === i && activeMode() !== 'touch';
      ctx.fillStyle = sel ? 'rgba(43,38,72,0.85)' : 'rgba(23,18,46,0.75)';
      ctx.fillRect(boxX, r.y, boxW, r.h);
      ctx.fillStyle = sel ? '#ffd15c' : '#4a4d68';
      ctx.fillRect(boxX, r.y, boxW, 1);
      ctx.fillRect(boxX, r.y + r.h - 1, boxW, 1);
      ctx.fillRect(boxX, r.y, 1, r.h);
      ctx.fillRect(boxX + boxW - 1, r.y, 1, r.h);
      const col = sel ? '#ffd15c' : i === 2 ? '#6fe3d2' : i === 0 ? '#ffd15c' : CREAM;
      text(labels[i], mid, r.y + 5, col, 1, 1);
    }
    const br = btnRects();
    drawBtn(br.admin.x, br.admin.y, S.iconAdmin);
    drawBtn(br.mute.x, br.mute.y, sfx.muted ? S.iconMuted : S.iconSound);
    drawBtn(br.pause.x, br.pause.y, S.iconGear);
  }

  function settingsRows(): { y: number; h: number }[] {
    const cy = Math.round(VH / 2);
    return [
      { y: cy - 26, h: 20 },
      { y: cy - 2, h: 16 },
      { y: cy + 18, h: 16 },
      { y: cy + 38, h: 16 },
    ];
  }

  function drawSettings(): void {
    ctx.fillStyle = 'rgba(7,6,22,0.8)';
    ctx.fillRect(0, 0, VW, VH);
    const mid = Math.round(VW / 2);
    const cy = Math.round(VH / 2);
    text('SETTINGS', mid, cy - 48, TITLE_COLS, 2, 1);

    const rows = settingsRows();
    const boxW = Math.min(VW - safe.l - safe.r - 12, 136);
    const boxX = mid - Math.round(boxW / 2);

    const drawRow = (idx: number, label: string, val: string | null, valCol: string, sub?: string) => {
      const r = rows[idx];
      const sel = settingsIdx === idx && activeMode() !== 'touch';
      ctx.fillStyle = sel ? 'rgba(43,38,72,0.85)' : 'rgba(23,18,46,0.75)';
      ctx.fillRect(boxX, r.y, boxW, r.h);
      ctx.fillStyle = sel ? '#ffd15c' : '#4a4d68';
      ctx.fillRect(boxX, r.y, boxW, 1);
      ctx.fillRect(boxX, r.y + r.h - 1, boxW, 1);
      ctx.fillRect(boxX, r.y, 1, r.h);
      ctx.fillRect(boxX + boxW - 1, r.y, 1, r.h);
      if (val !== null) {
        text(label, boxX + 5, r.y + 4, sel ? '#ffd15c' : CREAM, 1, 0);
        text(val, boxX + boxW - 5, r.y + 4, valCol, 1, 2);
      } else {
        text(label, mid, r.y + 5, sel ? '#ffd15c' : valCol, 1, 1);
      }
      if (sub) text(sub, boxX + 5, r.y + 12, '#9a9fb8', 1, 0);
    };

    drawRow(
      0,
      'STATIC STICK',
      staticJoy ? 'ON' : 'OFF',
      staticJoy ? '#6fe3d2' : '#9a9fb8',
      staticJoy ? 'FIXED + BIGGER' : 'DRAG ANYWHERE',
    );
    drawRow(1, 'SOUND', sfx.muted ? 'OFF' : 'ON', sfx.muted ? '#ff4d6d' : '#6fe3d2');
    drawRow(2, 'ADMIN PANELS', null, '#6fe3d2');
    drawRow(3, 'BACK', null, CREAM);
  }

  function drawOver(): void {
    const a = Math.min(0.55, player.deathT * 0.5);
    ctx.fillStyle = 'rgba(7,6,22,' + a.toFixed(2) + ')';
    ctx.fillRect(0, 0, VW, VH);
    if (player.deathT < 0.8) return;
    const mid = Math.round(VW / 2);
    // the headline drops into place
    const drop = Math.round((1 - easeOut(clamp((player.deathT - 0.8) / 0.3, 0, 1))) * -10);
    let y = Math.round(VH / 2) - 36;
    if (VW >= 170) {
      text('YOUR LIGHT WENT OUT', mid, y + drop, TITLE_COLS, 2, 1);
      y += 18;
    } else {
      text('YOUR LIGHT', mid, y - 8 + drop, TITLE_COLS, 2, 1);
      text('WENT OUT', mid, y + 6 + drop, TITLE_COLS, 2, 1);
      y += 24;
    }
    if (player.deathT < 1.1) return;
    text('DEPTH ' + depth + '   EMBERS ' + embersTotal, mid, y, CREAM, 1, 1);
    y += 10;
    text(newBest ? 'NEW DEEPEST DESCENT!' : 'DEEPEST DESCENT: ' + best, mid, y, '#6fe3d2', 1, 1);
    y += 16;
    if (Math.floor(time * 2) % 2 === 0) {
      const mode = activeMode();
      const prompt = mode === 'touch' ? 'TAP TO REKINDLE' : mode === 'pad' ? 'PRESS A TO REKINDLE' : 'PRESS SPACE TO REKINDLE';
      text(prompt, mid, y, '#ff9a3c', 1, 1);
    }
  }

  function ringAt(x: number, y: number, r: number): void {
    for (let a = 0; a < 12; a++) ctx.fillRect(Math.round(x + RING_X[a] * r), Math.round(y + RING_Y[a] * r), 1, 1);
  }

  /** Admin overlay: the reach within which each thing touches the emberling. */
  function drawHitboxes(cx: number, cy: number): void {
    ctx.fillStyle = '#9cff6b';
    ringAt(player.x - cx, player.y - cy, 4);
    ctx.fillStyle = '#ff4d6d';
    for (const s of shades) if (s.state === 'idle' || s.state === 'hunt') ringAt(s.x - cx, s.y - cy, 8);
    for (const m of moths) ringAt(m.x - cx, m.y - cy + 4, 7);
    ctx.fillStyle = '#eb77a8';
    for (const o of octos) if (o.state === 'lurk') ringAt(o.x - cx, o.y - cy, 9.5);
    ctx.fillStyle = '#ffd15c';
    for (const b of braziers) if (!b.lit) ringAt(b.x - cx, b.y - cy, 14);
    for (const e of embers) ringAt(e.x - cx, e.y - cy - 2, 8);
  }

  /** Admin overlay: frame rate and how much is alive, under the top bar. */
  function drawDebugHud(): void {
    const str = fpsAvg + 'FPS M' + (shades.length + moths.length + octos.length) + ' P' + parts.length;
    const x = Math.round(VW / 2 - textWidth(str) / 2);
    const y = safe.t + 31;
    drawText(ctx, str, x + 1, y + 1, INK);
    drawText(ctx, str, x, y, '#6fe3d2');
  }

  function render(): void {
    const jitter = shake > 0 && !reduceMotion;
    const cx = Math.round(camX + (jitter ? (Math.random() - 0.5) * shake : 0));
    const cy = Math.round(camY + (jitter ? (Math.random() - 0.5) * shake : 0));
    drawnX = cx;
    drawnY = cy;

    ctx.fillStyle = INK;
    ctx.fillRect(0, 0, VW, VH);
    ctx.drawImage(level.canvas, -cx, -cy);
    drawWater(cx, cy);
    drawFx(cx, cy, false);
    drawEntities(cx, cy);
    if (!fullBright) {
      buildLights(cx, cy);
      renderDarkness(cx, cy);
    }
    drawGlows(cx, cy);
    if (showMask) {
      // admin: the open-water stencil every octopus is cut to
      ctx.globalAlpha = 0.5;
      ctx.drawImage(level.mask, -cx, -cy);
      ctx.globalAlpha = 1;
    }
    if (book && nearBook && state === 'play' && !guideOpen) {
      // the prompt floats over the lectern and names the button that opens the book
      const mode = activeMode();
      const label = mode === 'touch' ? 'TAP READ' : mode === 'pad' ? 'A - READ' : 'SPACE - READ';
      const half = textWidth(label) / 2 + 2;
      const bob = reduceMotion ? 0 : Math.round(Math.sin(time * 4) * 1.5);
      text(label, clamp(book.x - cx, half, VW - half), Math.round(book.y - cy) - 24 + bob, '#ffd15c', 1, 1);
    }
    if (hitboxes) drawHitboxes(cx, cy);
    if (hitFlash > 0) drawHitFlash();
    if (debugHud) drawDebugHud();

    if (state === 'play' || state === 'pause' || state === 'transition' || (state === 'settings' && settingsFrom === 'pause')) {
      if (state === 'play') drawIndicator(cx, cy);
      drawHud();
      if (state === 'play') drawControls();
    }
    if (toast.t > 0 && state !== 'title' && state !== 'over' && state !== 'settings' && !nearBook) {
      if (toast.t > 0.4 || Math.floor(time * 14) % 2 === 0) {
        const slide = toast.age < 0.15 ? Math.round((1 - toast.age / 0.15) * -5) : 0;
        textWrap(toast.text, safe.t + 40 + slide, CREAM);
      }
    }
    if (state === 'transition') {
      const k = !trans.swapped
        ? Math.max(0, 1 - trans.t / T_CLOSE)
        : trans.opened
          ? Math.min(1, (trans.t - T_CLOSE - T_HOLD) / T_OPEN)
          : 0;
      drawIris(k, cx, cy);
      if (trans.swapped && !trans.opened) drawDepthCard();
    } else if (state === 'title') drawTitle();
    else if (state === 'pause' && !adminOpen) drawPause();
    else if (state === 'settings' && !adminOpen) drawSettings();
    else if (state === 'over') drawOver();
  }

  // ---------------------------------------------------------------- events
  function toView(e: PointerEvent): { x: number; y: number } {
    const r = canvas.getBoundingClientRect();
    return { x: (e.clientX - r.left) / scale, y: (e.clientY - r.top) / scale };
  }

  function hitBtn(p: { x: number; y: number }, b: { x: number; y: number }): boolean {
    return p.x >= b.x - 4 && p.x <= b.x + 17 && p.y >= b.y - 4 && p.y <= b.y + 17;
  }

  function setJoy(p: { x: number; y: number }): void {
    const R = joyR();
    let dx = p.x - joy.ox;
    let dy = p.y - joy.oy;
    const len = Math.hypot(dx, dy);
    const nx = len > 0 ? dx / len : 0;
    const ny = len > 0 ? dy / len : 0;
    if (len > R) {
      if (!staticJoy) {
        // floating mode: stick base follows the thumb so it never gets lost
        joy.ox += nx * (len - R);
        joy.oy += ny * (len - R);
      }
      dx = nx * R;
      dy = ny * R;
    }
    joy.kx = dx;
    joy.ky = dy;
    // dead zone in the middle, full speed a little before the rim
    const raw = Math.min(1, len / R);
    const m = raw <= deadzone ? 0 : Math.min(1, (raw - deadzone) / 0.6);
    joy.dx = nx * m;
    joy.dy = ny * m;
  }

  function onPointerDown(e: PointerEvent): void {
    e.preventDefault();
    dirty = true;
    sfx.init();
    const touch = e.pointerType !== 'mouse';
    if (touch) inputMode = 'touch';
    const p = toView(e);
    const br = btnRects();
    if ((state === 'title' || state === 'pause') && hitBtn(p, br.admin)) {
      triggerOpenAdmin();
      return;
    }
    if (showHudAdmin && state === 'play' && hitBtn(p, hudAdminRect())) {
      triggerOpenAdmin();
      return;
    }
    if ((state === 'title' || state === 'pause') && hitBtn(p, br.pause)) {
      openSettings(state);
      return;
    }
    if (state !== 'over' && state !== 'transition' && state !== 'settings' && hitBtn(p, br.mute)) {
      sfx.setMuted(!sfx.muted);
      return;
    }
    if (state === 'play' && hitBtn(p, br.pause)) {
      setPaused(true);
      return;
    }
    if (state === 'settings') {
      if (!touch && e.button !== 0) return;
      const rows = settingsRows();
      const mid = Math.round(VW / 2);
      const boxW = Math.min(VW - safe.l - safe.r - 12, 136);
      if (Math.abs(p.x - mid) <= boxW / 2 + 6) {
        for (let i = 0; i < rows.length; i++) {
          if (p.y >= rows[i].y - 2 && p.y <= rows[i].y + rows[i].h + 2) {
            settingsIdx = i;
            activateSettings(i);
            return;
          }
        }
      }
      closeSettings();
      return;
    }
    if (state === 'pause') {
      if (!touch && e.button !== 0) return;
      const rows = pauseRows();
      if (Math.abs(p.x - VW / 2) <= 55) {
        if (p.y >= rows[1].y - 2 && p.y <= rows[1].y + rows[1].h + 2) {
          openSettings('pause');
          return;
        }
        if (p.y >= rows[2].y - 2 && p.y <= rows[2].y + rows[2].h + 2) {
          triggerOpenAdmin();
          return;
        }
      }
      setPaused(false);
      return;
    }
    if (state !== 'play') {
      if (touch || e.button === 0) action();
      return;
    }
    if (!touch && e.button === 2) {
      pressFlare();
      return;
    }
    if (!touch && e.button !== 0) return;

    // on-screen buttons: whichever is nearer wins, with a generous margin
    const fp = flarePos();
    const dp = dashPos();
    const dF = Math.hypot(p.x - fp.x, p.y - fp.y) - 15;
    const dD = Math.hypot(p.x - dp.x, p.y - dp.y) - 11;
    if (Math.min(dF, dD) < 7) {
      if (dD < dF) pressDash();
      else pressFlare();
      if (touch) vibrate(6);
      return;
    }
    if (staticJoy) {
      const sj = staticJoyPos();
      if (Math.hypot(p.x - sj.x, p.y - sj.y) <= joyR() + 18) {
        if (joy.active) {
          pressFlare();
          return;
        }
        joy.active = true;
        joy.id = e.pointerId;
        joy.ox = sj.x;
        joy.oy = sj.y;
        setJoy(p);
        try {
          canvas.setPointerCapture(e.pointerId);
        } catch {
          /* capture not available */
        }
        return;
      }
    }
    if (touch) {
      if (joy.active) {
        // already steering: a second finger anywhere is a flare
        pressFlare();
        return;
      }
      if (!staticJoy) {
        joy.active = true;
        joy.id = e.pointerId;
        joy.ox = p.x;
        joy.oy = p.y;
        joy.dx = 0;
        joy.dy = 0;
        joy.kx = 0;
        joy.ky = 0;
      }
    } else {
      mouse.down = true;
      mouse.x = p.x;
      mouse.y = p.y;
    }
    try {
      canvas.setPointerCapture(e.pointerId);
    } catch {
      /* capture not available */
    }
  }

  function onPointerMove(e: PointerEvent): void {
    const p = toView(e);
    if (joy.active && e.pointerId === joy.id) {
      setJoy(p);
      return;
    }
    if (e.pointerType === 'mouse') {
      mouse.x = p.x;
      mouse.y = p.y;
      if (!(e.buttons & 1)) mouse.down = false;
      // a right-click made while the left button is held arrives as a move event
      if (e.button === 2 && e.buttons & 2 && state === 'play') pressFlare();
    }
  }

  function onPointerUp(e: PointerEvent): void {
    // iOS Safari only unlocks audio on touch end, so try again here
    sfx.init();
    if (joy.active && e.pointerId === joy.id) {
      joy.active = false;
      joy.dx = 0;
      joy.dy = 0;
      joy.kx = 0;
      joy.ky = 0;
      return;
    }
    if (e.pointerType === 'mouse') {
      mouse.down = false;
    }
  }

  function onKeyDown(e: KeyboardEvent): void {
    if (e.metaKey || e.ctrlKey || e.altKey) return;
    const c = e.code;
    if (c === 'Backquote' || c === 'F2') {
      e.preventDefault();
      if (!e.repeat && !guideOpen) {
        sfx.init();
        setAdminVisible(!adminOpen);
      }
      return;
    }
    // while the panel is up it owns the keyboard: its buttons and its list need Space and the arrows
    if (adminModalLock || guideOpen) return;
    if (c.startsWith('Arrow') || c === 'Space') e.preventDefault();
    if (e.repeat) return;
    dirty = true;
    sfx.init();
    inputMode = 'keys';
    keys.add(c);
    if (state === 'settings') {
      if (c === 'ArrowUp' || c === 'KeyW') settingsIdx = (settingsIdx + 3) % 4;
      else if (c === 'ArrowDown' || c === 'KeyS') settingsIdx = (settingsIdx + 1) % 4;
      else if (c === 'ArrowLeft' || c === 'ArrowRight' || c === 'KeyA' || c === 'KeyD') {
        if (settingsIdx < 2) activateSettings(settingsIdx);
      } else if (c === 'Space' || c === 'Enter' || c === 'KeyX' || c === 'KeyJ') activateSettings(settingsIdx);
      else if (c === 'Escape' || c === 'KeyP' || c === 'KeyO') closeSettings();
      else if (c === 'KeyM') sfx.setMuted(!sfx.muted);
      return;
    }
    if (state === 'pause') {
      if (c === 'ArrowUp' || c === 'KeyW') pauseIdx = (pauseIdx + 2) % 3;
      else if (c === 'ArrowDown' || c === 'KeyS') pauseIdx = (pauseIdx + 1) % 3;
      else if (c === 'Space' || c === 'Enter' || c === 'KeyX' || c === 'KeyJ') action();
      else if (c === 'KeyP' || c === 'Escape') setPaused(false);
      else if (c === 'KeyO') openSettings('pause');
      else if (c === 'KeyM') sfx.setMuted(!sfx.muted);
      return;
    }
    if (c === 'Space' || c === 'Enter' || c === 'KeyX' || c === 'KeyJ') action();
    else if (c === 'ShiftLeft' || c === 'ShiftRight' || c === 'KeyK' || c === 'KeyC') {
      if (state === 'play') pressDash();
    } else if (c === 'KeyP' || c === 'Escape') {
      if (state === 'play') setPaused(true);
    } else if (c === 'KeyO') {
      if (state === 'title') openSettings('title');
    } else if (c === 'KeyM') sfx.setMuted(!sfx.muted);
  }

  function onKeyUp(e: KeyboardEvent): void {
    keys.delete(e.code);
  }

  function onBlur(): void {
    keys.clear();
    joy.active = false;
    mouse.down = false;
  }

  function onVisibility(): void {
    if (document.hidden) setPaused(true);
  }

  const prevent = (e: Event) => e.preventDefault();

  canvas.addEventListener('pointerdown', onPointerDown);
  canvas.addEventListener('pointermove', onPointerMove);
  canvas.addEventListener('pointerup', onPointerUp);
  canvas.addEventListener('pointercancel', onPointerUp);
  canvas.addEventListener('contextmenu', prevent);
  canvas.addEventListener('touchstart', prevent, { passive: false });
  window.addEventListener('keydown', onKeyDown);
  window.addEventListener('keyup', onKeyUp);
  window.addEventListener('blur', onBlur);
  window.addEventListener('resize', resize);
  window.addEventListener('orientationchange', resize);
  document.addEventListener('visibilitychange', onVisibility);

  // ------------------------------------------------------------------ loop
  resize();
  loadLevel(1);

  if (import.meta.env.DEV) {
    // development-only hooks used for automated playtesting; stripped from production builds
    (window as unknown as Record<string, unknown>).__ember = {
      player,
      gate,
      joy,
      sprites: S,
      info: () => ({
        state,
        depth,
        gateOpen,
        inputMode,
        staticJoy,
        shades: shades.length,
        moths: moths.length,
        octos: octos.length,
        grabbed: grabOcto !== null,
        embers: embers.length,
        braziers,
        cam: { x: camX, y: camY },
        drawn: { x: drawnX, y: drawnY },
        view: { w: VW, h: VH, scale },
      }),
      shades: () => shades,
      moths: () => moths,
      octos: () => octos,
      embers: () => embers,
      tiles: () => level,
      gen: (d: number, chance?: number) => generateLevel(d, (Math.random() * 0x7fffffff) | 0, chance),
      open: (x: number, y: number) => isOpenWater(level, x, y),
      book: () => book,
      guide: () => ({ open: guideOpen, near: nearBook }),
      setStaticJoy,
      load: (d: number) => {
        depth = d;
        loadLevel(d);
      },
    };
  }

  function findNearFloorTile(): { x: number; y: number } {
    const ptx = Math.floor(player.x / TILE);
    const pty = Math.floor(player.y / TILE);
    for (let rad = 1; rad <= 6; rad++) {
      for (let dy = -rad; dy <= rad; dy++) {
        for (let dx = -rad; dx <= rad; dx++) {
          const tx = ptx + dx;
          const ty = pty + dy;
          if (tx <= 1 || ty <= 1 || tx >= level.w - 2 || ty >= level.h - 2) continue;
          if (level.tiles[ty * level.w + tx] !== T_WALL) return { x: tx, y: ty };
        }
      }
    }
    return { x: ptx, y: pty };
  }

  /** Digs a small pool a few tiles from the emberling, so water things can be tested on any level. */
  function carveNear(): { x: number; y: number } | null {
    const ptx = Math.floor(player.x / TILE);
    const pty = Math.floor(player.y / TILE);
    const spots = [[3, 0], [-3, 0], [0, 3], [0, -3], [3, 3], [-3, 3], [3, -3], [-3, -3], [2, 0], [-2, 0], [0, 2], [0, -2]];
    for (const [ox, oy] of spots) {
      const tx = ptx + ox;
      const ty = pty + oy;
      if (tx > 2 && ty > 2 && tx < level.w - 3 && ty < level.h - 3 && level.tiles[ty * level.w + tx] !== T_WALL) {
        return carveWaterPuddle(level, tx, ty);
      }
    }
    return null;
  }

  /** The closest free water tile that is not right under the emberling; digs a pool if none is near. */
  function findNearbyWater(): { x: number; y: number } | null {
    const pick = (): { p: { x: number; y: number } | null; d: number } => {
      let p: { x: number; y: number } | null = null;
      let d = Infinity;
      for (const w of level.water) {
        const x = w.x * TILE + 8;
        const y = w.y * TILE + 8;
        const dd = Math.hypot(x - player.x, y - player.y);
        if (dd > 14 && dd < d && !octoOn(x, y)) {
          d = dd;
          p = w;
        }
      }
      return { p, d };
    };
    const near = pick();
    if (near.p && near.d < 160) return near.p;
    carveNear();
    return pick().p;
  }

  function reviveHere(): void {
    player.dead = false;
    player.poofed = false;
    player.deathT = 0;
    player.fuel = Math.max(player.fuel, 80);
    player.scale = 1;
    player.spawnT = 0;
    player.inv = 1.5;
    state = 'play';
  }

  function ensurePlaying(): void {
    if (state === 'title') {
      state = 'play';
      player.scale = 1;
      player.spawnT = 0;
      sfx.init();
    } else if (state === 'over') {
      reviveHere();
    }
  }

  function afterAdminLoad(): void {
    state = 'play';
    player.scale = 1;
    player.spawnT = 0;
    dirty = true;
  }

  /** Sets the emberling down `d` pixels from a spot, on dry floor if it can, and snaps the camera over. */
  function placePlayer(x: number, y: number, d: number): void {
    const dirs = [[0, 1], [1, 0], [-1, 0], [0, -1], [1, 1], [-1, 1], [1, -1], [-1, -1]];
    let done = false;
    for (let pass = 0; pass < 2 && !done; pass++) {
      for (const [ox, oy] of dirs) {
        const px = x + ox * d;
        const py = y + oy * d;
        if (boxHits(px, py)) continue;
        if (pass === 0 && tileAt(px, py + 2) === T_WATER) continue;
        player.x = px;
        player.y = py;
        done = true;
        break;
      }
    }
    player.vx = 0;
    player.vy = 0;
    player.dashT = 0;
    if (grabOcto) releaseOcto(grabOcto);
    const c = cameraTarget();
    camX = c.x;
    camY = c.y;
    reveal(player.x, player.y, playerRadius());
    flowT = 0;
  }

  const admin: AdminBridge = {
    getSnapshot: (): AdminSnapshot => ({
      state,
      depth,
      fuel: Math.round(Math.max(0, player.fuel)),
      embers: embersTotal,
      best,
      litBraziers: litCount,
      totalBraziers: braziers.length,
      gateOpen,
      shades: shades.length,
      moths: moths.length,
      octos: octos.length,
      packed: octos.filter((o) => o.pack > 0).length,
      waterTiles: level.water.length,
      grabbed: grabOcto !== null,
      dead: player.dead,
      wet: player.wet,
      fps: fpsAvg,
      particles: parts.length,
      godMode,
      noCooldowns,
      noClip,
      noBurn,
      fullBright,
      revealMap,
      freezeEnemies,
      revealOctos,
      debugHud,
      hitboxes,
      poolMask: showMask,
      hasBook: book !== null,
      speedMult,
      lightMult,
      timeScale,
      trioChance,
      staticJoy,
      joyScale,
      deadzone,
      haptics,
      forcedInput,
      muted: sfx.muted,
      showHudAdmin,
      pauseOnAdmin,
      playerX: Math.round(player.x),
      playerY: Math.round(player.y),
      tileX: Math.floor(player.x / TILE),
      tileY: Math.floor(player.y / TILE),
      levelW: level.w,
      levelH: level.h,
    }),
    setAdminOpen: (open: boolean) => applyAdminOpen(open),
    setModalLock: (locked: boolean) => {
      adminModalLock = locked;
      stepQueue = 0;
      if (locked) {
        joy.active = false;
        mouse.down = false;
        keys.clear();
      }
      dirty = true;
    },

    // ------------------------------------------------------------ player
    setFuel: (fuel: number) => {
      player.fuel = clamp(fuel, 1, 100);
      dirty = true;
    },
    addFuel: (delta: number) => {
      player.fuel = clamp(player.fuel + delta, 1, 100);
      dirty = true;
    },
    addEmbers: (delta: number) => {
      embersTotal = Math.max(0, embersTotal + delta);
      dirty = true;
    },
    flareNow: () => {
      ensurePlaying();
      flares.push({ x: player.x, y: player.y - 3, t: 0, r: 0 });
      player.sq = 0.3;
      lightKick = 6;
      sfx.flare();
      burst(player.x, player.y - 4, 16, FIRE, 70);
      reveal(player.x, player.y, FLARE_R + 20);
      dirty = true;
    },
    killPlayer: () => {
      if (state === 'play' && !player.dead) {
        player.fuel = 0;
        die();
      }
      dirty = true;
    },
    revive: () => {
      if (state === 'over') reviveHere();
      dirty = true;
    },
    freeFromOcto: () => {
      if (grabOcto) {
        releaseOcto(grabOcto);
        player.inv = 0.8;
      }
      dirty = true;
    },
    teleport: (where: TeleportTarget) => {
      ensurePlaying();
      if (where === 'book') {
        if (book) placePlayer(book.x, book.y, 14);
      } else if (where === 'gate') placePlayer(gate.x, gate.y, 20);
      else if (where === 'start') placePlayer(level.start.x * TILE + 8, level.start.y * TILE + 8, 0);
      else if (where === 'brazier') {
        // the nearest one still cold, or failing that any other
        let pick: Brazier | null = null;
        let bd = Infinity;
        for (const b of braziers) {
          const d = Math.hypot(b.x - player.x, b.y - player.y) + (b.lit ? 100000 : 0);
          if (d > 30 && d < bd) {
            bd = d;
            pick = b;
          }
        }
        if (pick) placePlayer(pick.x, pick.y, 18);
      } else {
        const o = octos.find((q) => q.state === 'lurk');
        if (o) placePlayer(o.x, o.y, 24);
        else if (level.water.length) placePlayer(level.water[0].x * TILE + 8, level.water[0].y * TILE + 8, 24);
      }
      dirty = true;
    },
    toggleGodMode: () => {
      godMode = !godMode;
      dirty = true;
    },
    toggleNoCooldowns: () => {
      noCooldowns = !noCooldowns;
      if (noCooldowns) {
        player.flareCd = 0;
        player.dashCd = 0;
      }
      dirty = true;
    },
    toggleNoClip: () => {
      noClip = !noClip;
      if (!noClip && boxHits(player.x, player.y)) {
        // left standing inside the rock: step out onto the nearest floor
        const t = findNearFloorTile();
        player.x = t.x * TILE + 8;
        player.y = t.y * TILE + 8;
      }
      dirty = true;
    },
    toggleNoBurn: () => {
      noBurn = !noBurn;
      dirty = true;
    },
    setSpeedMult: (v: number) => {
      speedMult = clamp(v, 0.5, 2.5);
      dirty = true;
    },
    setLightMult: (v: number) => {
      lightMult = clamp(v, 0.5, 3);
      dirty = true;
    },

    // ------------------------------------------------------------- world
    setDepth: (d: number) => {
      depth = clamp(Math.round(d), 1, 99);
      player.fuel = Math.max(player.fuel, 80);
      loadLevel(depth);
      afterAdminLoad();
    },
    regenLevel: () => {
      player.fuel = Math.max(player.fuel, 40);
      loadLevel(depth);
      afterAdminLoad();
    },
    descendNow: () => {
      depth++;
      player.fuel = Math.min(100, Math.max(50, player.fuel + 25));
      loadLevel(depth);
      afterAdminLoad();
    },
    lightAllBraziers: () => {
      ensurePlaying();
      for (const b of braziers) {
        if (b.lit) continue;
        b.lit = true;
        b.litT = 0;
        litCount++;
        reveal(b.x, b.y - 4, BRAZIER_R);
      }
      if (!gateOpen) {
        gateOpen = true;
        gateT = 0;
        sfx.gate();
        say('THE GATE AWAKENS', 2.4);
      }
      dirty = true;
    },
    unlightBraziers: () => {
      for (const b of braziers) {
        b.lit = false;
        b.litT = 0;
      }
      litCount = 0;
      gateOpen = false;
      gateT = 0;
      dirty = true;
    },
    toggleFullBright: () => {
      fullBright = !fullBright;
      dirty = true;
    },
    toggleRevealMap: () => {
      revealMap = !revealMap;
      if (revealMap) explored.fill(1);
      dirty = true;
    },
    addPuddle: () => {
      ensurePlaying();
      carveNear();
      dirty = true;
    },
    openGuide: () => {
      ensurePlaying();
      setAdminVisible(false);
      openGuide();
    },
    dropEmbers: (count: number) => {
      ensurePlaying();
      for (let i = 0; i < count; i++) {
        const a = (i / count) * Math.PI * 2;
        dropEmber(player.x + Math.cos(a) * 22, player.y + Math.sin(a) * 22, 10);
      }
      dirty = true;
    },

    // ---------------------------------------------------------- monsters
    spawnShade: (count = 1) => {
      ensurePlaying();
      for (let i = 0; i < count; i++) {
        const ang = Math.random() * Math.PI * 2;
        let x = player.x + Math.cos(ang) * 52;
        let y = player.y + Math.sin(ang) * 52;
        if (tileAt(x, y) === T_WALL) {
          const t = findNearFloorTile();
          x = t.x * TILE + 8;
          y = t.y * TILE + 8;
        }
        shades.push({
          x,
          y,
          vx: 0,
          vy: 0,
          state: 'idle',
          t: 0,
          ph: Math.random() * 6,
          lit: false,
          tx: x,
          ty: y,
          wait: 0.4,
          rise: RISE_T,
          alert: 0,
        });
      }
      dirty = true;
    },
    spawnMoth: (count = 1) => {
      ensurePlaying();
      for (let i = 0; i < count; i++) {
        const mx = player.x + rnd(-40, 40);
        const my = player.y - rnd(22, 40);
        moths.push({ x: mx, y: my, vx: 0, vy: 0, hx: mx, hy: my, ph: Math.random() * 6, seed: Math.random() * 6, flee: 0, carry: false });
      }
      dirty = true;
    },
    spawnOcto: () => {
      ensurePlaying();
      const p = findNearbyWater();
      if (p) octos.push(makeOcto(p.x * TILE + 8, p.y * TILE + 8, 0));
      dirty = true;
    },
    spawnOctoPack: () => {
      ensurePlaying();
      // the nearest puddle with room for three, or a freshly dug one
      const nearest = (): { x: number; y: number }[] | null => {
        let pick: { x: number; y: number }[] | null = null;
        let bd = 140;
        for (const pd of findPuddles(level.w, level.h, level.tiles)) {
          if (pd.length < 3) continue;
          let d = Infinity;
          for (const t of pd) d = Math.min(d, Math.hypot(t.x * TILE + 8 - player.x, t.y * TILE + 8 - player.y));
          if (d < bd) {
            bd = d;
            pick = pd;
          }
        }
        return pick;
      };
      let puddle = nearest();
      if (!puddle) {
        carveNear();
        puddle = nearest();
      }
      if (puddle) {
        const free = puddle.filter(
          (t) =>
            !octoOn(t.x * TILE + 8, t.y * TILE + 8) &&
            Math.hypot(t.x * TILE + 8 - player.x, t.y * TILE + 8 - player.y) > 12,
        );
        const id = ++packSeq;
        for (const t of spreadTiles(free.length >= 3 ? free : puddle, 3, Math.random)) {
          octos.push(makeOcto(t.x * TILE + 8, t.y * TILE + 8, id));
        }
      }
      dirty = true;
    },
    triggerOctoGrab: () => {
      ensurePlaying();
      if (grabOcto) {
        grabOcto.t = OCTO_HOLD_T;
        grabOcto.tick = 0;
        dirty = true;
        return;
      }
      const tx = Math.floor(player.x / TILE);
      const ty = Math.floor(player.y / TILE);
      if (!waterAt(tx, ty)) carveWaterPuddle(level, tx, ty);
      const x = tx * TILE + 8;
      const y = ty * TILE + 8;
      let target = octos.find((o) => o.state === 'lurk' && o.x === x && o.y === y);
      if (!target) {
        target = makeOcto(x, y, 0);
        octos.push(target);
      }
      startOctoGrab(target);
      dirty = true;
    },
    relocateOctos: () => {
      for (const o of octos) {
        if (o.state !== 'lurk') continue;
        relocateOcto(o);
        o.state = 'emerge';
        o.t = 0.3;
        o.rise = 0;
      }
      dirty = true;
    },
    peekOctos: () => {
      for (const o of octos) if (o.state === 'lurk') o.ph = (((4.5 - o.x * 0.07) % 5.4) + 5.4) % 5.4;
      dirty = true;
    },
    setTrioChance: (v: number) => {
      trioChance = v < 0 ? -1 : clamp(v, 0, 1);
      dirty = true;
    },
    clearMonsters: () => {
      shades = [];
      moths = [];
      octos = [];
      grabOcto = null;
      dirty = true;
    },
    igniteAllShades: () => {
      for (const s of shades) {
        if (s.state === 'idle' || s.state === 'hunt') igniteShade(s);
      }
      dirty = true;
    },
    toggleFreezeEnemies: () => {
      freezeEnemies = !freezeEnemies;
      dirty = true;
    },
    toggleRevealOctos: () => {
      revealOctos = !revealOctos;
      dirty = true;
    },

    // ------------------------------------------------------------- input
    setStaticJoy,
    setJoyScale,
    setDeadzone: (v: number) => {
      deadzone = clamp(Math.round(v * 20) / 20, 0.05, 0.4);
      dirty = true;
    },
    setHaptics: (v: boolean) => {
      haptics = v;
      if (v) vibrate(20);
      dirty = true;
    },
    setForcedInput: (mode: ForcedInput) => {
      forcedInput = mode;
      if (mode === 'touch') inputMode = 'touch';
      else if (mode === 'keys') inputMode = 'keys';
      dirty = true;
    },
    setMuted: (m: boolean) => {
      sfx.setMuted(m);
      dirty = true;
    },
    setShowHudAdmin: (v: boolean) => {
      showHudAdmin = v;
      dirty = true;
    },

    // ------------------------------------------------------------ system
    setPauseOnAdmin: (v: boolean) => {
      pauseOnAdmin = v;
      stepQueue = 0;
      dirty = true;
    },
    setTimeScale: (v: number) => {
      timeScale = clamp(v, 0.1, 3);
      dirty = true;
    },
    stepFrame: (count: number) => {
      ensurePlaying();
      stepQueue = Math.min(120, stepQueue + count);
      dirty = true;
    },
    toggleDebugHud: () => {
      debugHud = !debugHud;
      dirty = true;
    },
    toggleHitboxes: () => {
      hitboxes = !hitboxes;
      dirty = true;
    },
    togglePoolMask: () => {
      showMask = !showMask;
      dirty = true;
    },
    resetCheats: () => {
      godMode = false;
      noCooldowns = false;
      noBurn = false;
      fullBright = false;
      revealMap = false;
      freezeEnemies = false;
      revealOctos = false;
      debugHud = false;
      hitboxes = false;
      showMask = false;
      speedMult = 1;
      lightMult = 1;
      timeScale = 1;
      trioChance = -1;
      if (noClip) admin.toggleNoClip();
      dirty = true;
    },
    resetBest: () => {
      best = 0;
      newBest = false;
      try {
        localStorage.removeItem('emberling_best');
      } catch {
        /* storage unavailable */
      }
      dirty = true;
    },
  };

  const guide: GuideBridge = {
    portraits: () => {
      if (!portraitCache) portraitCache = makePortraits();
      return portraitCache;
    },
    close: () => closeGuide(),
    turn: () => sfx.page(),
  };

  let raf = 0;
  let last = performance.now();
  let lastDraw = 0;
  function frame(now: number): void {
    raf = requestAnimationFrame(frame);
    const elapsed = now - last;
    // 120 Hz and faster screens: skip refreshes that arrive too soon after the last one
    if (elapsed < MIN_FRAME_MS) return;
    last = now;
    const dt = Math.min(0.05, Math.max(0, elapsed / 1000));
    fpsCount++;
    fpsTimer += elapsed / 1000;
    if (fpsTimer >= 0.5) {
      fpsAvg = Math.round(fpsCount / fpsTimer);
      fpsCount = 0;
      fpsTimer = 0;
    }
    update(dt);
    // nothing moves behind a menu, so only redraw when something was pressed (plus a slow tick)
    if ((state === 'pause' || state === 'settings' || guideOpen || (adminModalLock && pauseOnAdmin)) && !dirty && now - lastDraw < 150) return;
    dirty = false;
    lastDraw = now;
    render();
  }
  raf = requestAnimationFrame(frame);

  return {
    admin,
    guide,
    destroy: () => {
      cancelAnimationFrame(raf);
      canvas.removeEventListener('pointerdown', onPointerDown);
      canvas.removeEventListener('pointermove', onPointerMove);
      canvas.removeEventListener('pointerup', onPointerUp);
      canvas.removeEventListener('pointercancel', onPointerUp);
      canvas.removeEventListener('contextmenu', prevent);
      canvas.removeEventListener('touchstart', prevent);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('blur', onBlur);
      window.removeEventListener('resize', resize);
      window.removeEventListener('orientationchange', resize);
      document.removeEventListener('visibilitychange', onVisibility);
      sfx.dispose();
      probe.remove();
    },
  };
}
