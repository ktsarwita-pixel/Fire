// Procedural cave generation (cellular automata) + pixel-art tile painting.

import { BOOK_DEPTH, mothCount, OCTO_PACK_CHANCE, octoCount, shadeCount } from './rules';

export const TILE = 16;
export const T_FLOOR = 0;
export const T_WALL = 1;
export const T_WATER = 2;

export interface Pt {
  x: number;
  y: number;
}

export interface OctoSpawn extends Pt {
  /** Octopuses crowded into one puddle share a pack number; loners are 0. */
  pack: number;
}

export interface Level {
  w: number;
  h: number;
  tiles: Uint8Array;
  start: Pt;
  exit: Pt;
  braziers: Pt[];
  embers: Pt[];
  shades: Pt[];
  moths: Pt[];
  octos: OctoSpawn[];
  water: Pt[];
  /** Pixel positions of glowing mushrooms and crystals, for twinkles. */
  glints: Pt[];
  /** Where the guide book stands (one depth only). */
  book: Pt | null;
  canvas: HTMLCanvasElement;
  /** A stencil the size of the level: opaque on open water, clear on the banks and on dry land. */
  mask: HTMLCanvasElement;
}

function mulberry32(seed: number): () => number {
  let a = seed | 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// How many pixels of a water tile the bank covers on each side that meets dry land. The
// painters below draw these rims, and the open-water test and stencil leave them out, so
// the three can never disagree about where a pool ends.
const RIM_N = 2;
const RIM_S = 1;
const RIM_W = 1;
const RIM_E = 1;

function isWater(w: number, h: number, tiles: Uint8Array, tx: number, ty: number): boolean {
  return tx >= 0 && ty >= 0 && tx < w && ty < h && tiles[ty * w + tx] === T_WATER;
}

/** True where a pixel is open water: on a water tile, and clear of the bank drawn along its edges. */
export function isOpenWater(level: Pick<Level, 'w' | 'h' | 'tiles'>, x: number, y: number): boolean {
  const { w, h, tiles } = level;
  const tx = Math.floor(x / TILE);
  const ty = Math.floor(y / TILE);
  if (!isWater(w, h, tiles, tx, ty)) return false;
  const lx = x - tx * TILE;
  const ly = y - ty * TILE;
  if (ly < RIM_N && !isWater(w, h, tiles, tx, ty - 1)) return false;
  if (ly >= TILE - RIM_S && !isWater(w, h, tiles, tx, ty + 1)) return false;
  if (lx < RIM_W && !isWater(w, h, tiles, tx - 1, ty)) return false;
  if (lx >= TILE - RIM_E && !isWater(w, h, tiles, tx + 1, ty)) return false;
  return true;
}

/** (Re)paints the open-water stencil for a whole level. */
function paintMask(mask: HTMLCanvasElement, w: number, h: number, tiles: Uint8Array): void {
  mask.width = w * TILE;
  mask.height = h * TILE;
  const g = mask.getContext('2d') as CanvasRenderingContext2D;
  g.fillStyle = '#9cff6b';
  for (let ty = 0; ty < h; ty++) {
    for (let tx = 0; tx < w; tx++) {
      if (tiles[ty * w + tx] !== T_WATER) continue;
      const x0 = isWater(w, h, tiles, tx - 1, ty) ? 0 : RIM_W;
      const x1 = isWater(w, h, tiles, tx + 1, ty) ? TILE : TILE - RIM_E;
      const y0 = isWater(w, h, tiles, tx, ty - 1) ? 0 : RIM_N;
      const y1 = isWater(w, h, tiles, tx, ty + 1) ? TILE : TILE - RIM_S;
      g.fillRect(tx * TILE + x0, ty * TILE + y0, x1 - x0, y1 - y0);
    }
  }
}

/** Groups the water tiles into connected puddles. */
export function findPuddles(w: number, h: number, tiles: Uint8Array): Pt[][] {
  const seen = new Uint8Array(w * h);
  const out: Pt[][] = [];
  for (let i = 0; i < w * h; i++) {
    if (tiles[i] !== T_WATER || seen[i]) continue;
    const stack = [i];
    const puddle: Pt[] = [];
    seen[i] = 1;
    while (stack.length) {
      const c = stack.pop() as number;
      puddle.push({ x: c % w, y: (c / w) | 0 });
      for (const n of [c - 1, c + 1, c - w, c + w]) {
        if (n >= 0 && n < w * h && tiles[n] === T_WATER && !seen[n]) {
          seen[n] = 1;
          stack.push(n);
        }
      }
    }
    out.push(puddle);
  }
  return out;
}

/** Picks up to `n` tiles as far from one another as the set allows. */
export function spreadTiles(tiles: Pt[], n: number, rng: () => number): Pt[] {
  if (!tiles.length) return [];
  const picks: Pt[] = [tiles[(rng() * tiles.length) | 0]];
  while (picks.length < n && picks.length < tiles.length) {
    let best: Pt | null = null;
    let bestD = -1;
    for (const t of tiles) {
      if (picks.includes(t)) continue;
      let d = Infinity;
      for (const p of picks) d = Math.min(d, (t.x - p.x) * (t.x - p.x) + (t.y - p.y) * (t.y - p.y));
      if (d > bestD) {
        bestD = d;
        best = t;
      }
    }
    if (!best) break;
    picks.push(best);
  }
  return picks;
}

/** `trioChance` is how often a cave that holds octopuses crowds three of them into one puddle. */
export function generateLevel(depth: number, seed: number, trioChance = OCTO_PACK_CHANCE): Level {
  const rng = mulberry32(seed);
  const ri = (n: number) => (rng() * n) | 0;
  const w = Math.min(50, 30 + depth * 2);
  const h = Math.min(38, 24 + depth * 2);
  const idx = (x: number, y: number) => y * w + x;

  let tiles = new Uint8Array(w * h);
  let region: number[] = [];

  for (let attempt = 0; attempt < 40; attempt++) {
    let cur = new Uint8Array(w * h);
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const border = x < 2 || y < 2 || x >= w - 2 || y >= h - 2;
        cur[idx(x, y)] = border || rng() < 0.455 ? 1 : 0;
      }
    }
    for (let it = 0; it < 5; it++) {
      const nx = new Uint8Array(w * h);
      for (let y = 0; y < h; y++) {
        for (let x = 0; x < w; x++) {
          if (x < 1 || y < 1 || x >= w - 1 || y >= h - 1) {
            nx[idx(x, y)] = 1;
            continue;
          }
          let n = 0;
          for (let dy = -1; dy <= 1; dy++) {
            for (let dx = -1; dx <= 1; dx++) {
              if (dx || dy) n += cur[idx(x + dx, y + dy)];
            }
          }
          nx[idx(x, y)] = n > 4 || (cur[idx(x, y)] === 1 && n === 4) ? 1 : 0;
        }
      }
      cur = nx;
    }
    // keep only the largest connected cavern
    const seen = new Uint8Array(w * h);
    let best: number[] = [];
    for (let i = 0; i < w * h; i++) {
      if (cur[i] !== 0 || seen[i]) continue;
      const stack = [i];
      const reg: number[] = [];
      seen[i] = 1;
      while (stack.length) {
        const c = stack.pop() as number;
        reg.push(c);
        const nb = [c - 1, c + 1, c - w, c + w];
        for (const n of nb) {
          if (n >= 0 && n < w * h && cur[n] === 0 && !seen[n]) {
            seen[n] = 1;
            stack.push(n);
          }
        }
      }
      if (reg.length > best.length) best = reg;
    }
    tiles = new Uint8Array(w * h).fill(1);
    for (const c of best) tiles[c] = 0;
    region = best;
    if (best.length >= w * h * 0.34) break;
  }

  if (region.length < 80) {
    // extremely unlikely fallback: carve one big hall
    region = [];
    for (let y = 4; y < h - 4; y++) {
      for (let x = 4; x < w - 4; x++) {
        tiles[idx(x, y)] = 0;
        region.push(idx(x, y));
      }
    }
  }

  const walkable = (x: number, y: number) =>
    x >= 0 && y >= 0 && x < w && y < h && tiles[idx(x, y)] !== T_WALL;
  const open3 = (c: number) => {
    const x = c % w;
    const y = (c / w) | 0;
    for (let dy = -1; dy <= 1; dy++) {
      for (let dx = -1; dx <= 1; dx++) if (!walkable(x + dx, y + dy)) return false;
    }
    return true;
  };
  const toPt = (c: number): Pt => ({ x: c % w, y: (c / w) | 0 });
  const sq = (a: Pt, b: Pt) => (a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y);

  const opens = region.filter(open3);
  const pool = opens.length > 12 ? opens : region;
  const startIdx = pool[ri(pool.length)];
  const start = toPt(startIdx);

  // walking distance from the start
  const dist = new Int32Array(w * h).fill(-1);
  const queue = [startIdx];
  dist[startIdx] = 0;
  for (let qi = 0; qi < queue.length; qi++) {
    const c = queue[qi];
    for (const n of [c - 1, c + 1, c - w, c + w]) {
      if (tiles[n] !== T_WALL && dist[n] < 0) {
        dist[n] = dist[c] + 1;
        queue.push(n);
      }
    }
  }

  let exitIdx = startIdx;
  for (const c of pool) if (dist[c] > dist[exitIdx]) exitIdx = c;
  const exit = toPt(exitIdx);

  // braziers: farthest-point sampling so they spread through the cave
  const nB = Math.min(6, 2 + depth);
  let cands = pool.filter((c) => dist[c] >= 5 && c !== exitIdx);
  if (cands.length < nB * 3) cands = region.filter((c) => c !== startIdx && c !== exitIdx);
  const anchors: Pt[] = [start, exit];
  const braziers: Pt[] = [];
  for (let i = 0; i < nB && cands.length; i++) {
    let bestC = cands[0];
    let bestD = -1;
    for (const c of cands) {
      const p = toPt(c);
      let m = Infinity;
      for (const a of anchors) m = Math.min(m, sq(p, a));
      m += rng() * 6;
      if (m > bestD) {
        bestD = m;
        bestC = c;
      }
    }
    const p = toPt(bestC);
    braziers.push(p);
    anchors.push(p);
  }

  // one depth keeps a guide book on a lectern, a short walk from where the emberling arrives
  let book: Pt | null = null;
  if (depth === BOOK_DEPTH) {
    const clear = (c: number) => c !== exitIdx && !braziers.some((b) => sq(toPt(c), b) < 9);
    let spots = pool.filter((c) => dist[c] >= 3 && dist[c] <= 6 && clear(c));
    if (!spots.length) spots = region.filter((c) => dist[c] >= 2 && dist[c] <= 12 && clear(c));
    if (spots.length) book = toPt(spots[ri(spots.length)]);
  }

  const nearKey = (p: Pt, r: number) => {
    const r2 = r * r;
    if (sq(p, start) <= r2 * 2 || sq(p, exit) <= r2) return true;
    for (const b of braziers) if (sq(p, b) <= r2) return true;
    // puddles and embers keep clear of the book as well
    if (book && sq(p, book) <= r2) return true;
    return false;
  };

  // puddles
  if (depth >= 2) {
    const blobs = Math.min(9, depth * 2);
    for (let b = 0; b < blobs; b++) {
      let p = toPt(region[ri(region.length)]);
      const len = 5 + ri(8);
      for (let s = 0; s < len; s++) {
        if (tiles[idx(p.x, p.y)] === T_FLOOR && !nearKey(p, 1.5)) tiles[idx(p.x, p.y)] = T_WATER;
        const dir = ri(4);
        const np = { x: p.x + (dir === 0 ? 1 : dir === 1 ? -1 : 0), y: p.y + (dir === 2 ? 1 : dir === 3 ? -1 : 0) };
        if (walkable(np.x, np.y)) p = np;
      }
    }
  }

  // ember pickups
  const embers: Pt[] = [];
  const nE = Math.min(30, 12 + depth * 2);
  for (let tries = 0; tries < 3000 && embers.length < nE; tries++) {
    const c = region[ri(region.length)];
    if (tiles[c] !== T_FLOOR || dist[c] < 3) continue;
    const p = toPt(c);
    if (nearKey(p, 1.5)) continue;
    if (embers.some((e) => sq(e, p) < 7)) continue;
    embers.push(p);
  }

  const pickFar = (count: number, minDist: number): Pt[] => {
    const out: Pt[] = [];
    let far = region.filter((c) => dist[c] >= minDist);
    if (far.length < count * 2) far = region.filter((c) => dist[c] >= Math.min(6, minDist));
    for (let i = 0; i < count && far.length; i++) out.push(toPt(far[ri(far.length)]));
    return out;
  };
  const shades = pickFar(shadeCount(depth), 11);
  const moths = pickFar(mothCount(depth), 8);

  // collect all water tiles for octopuses (levels 6-10, max 5 per level)
  const water: Pt[] = [];
  for (let i = 0; i < w * h; i++) {
    if (tiles[i] === T_WATER) water.push(toPt(i));
  }
  // octopuses lurk in the puddles of depths 6-10, five at most. Now and then three of
  // them crowd into a single pool.
  const octos: OctoSpawn[] = [];
  const want = octoCount(depth);
  if (want > 0 && water.length > 0) {
    const target = Math.min(want, water.length);
    const far = (p: Pt) => dist[idx(p.x, p.y)] >= 4;
    const taken = new Set<number>();
    const place = (p: Pt, pack: number) => {
      octos.push({ x: p.x, y: p.y, pack });
      taken.add(idx(p.x, p.y));
    };
    if (target >= 3 && rng() < trioChance) {
      const roomy = findPuddles(w, h, tiles).filter((pd) => pd.length >= 3);
      const safe = roomy.filter((pd) => pd.every(far));
      const pool = safe.length ? safe : roomy;
      if (pool.length) {
        for (const p of spreadTiles(pool[ri(pool.length)], 3, rng)) place(p, 1);
      }
    }
    const candidates = water.filter(far);
    const poolW = candidates.length >= target ? candidates : water;
    for (let guard = 0; octos.length < target && guard < 40; guard++) {
      let bestP: Pt | null = null;
      let bestScore = -1;
      for (let t = 0; t < 25; t++) {
        const cand = poolW[ri(poolW.length)];
        if (taken.has(idx(cand.x, cand.y))) continue;
        let minD = 999;
        for (const o of octos) minD = Math.min(minD, sq(cand, o));
        if (minD > bestScore) {
          bestScore = minD;
          bestP = cand;
        }
      }
      if (bestP) place(bestP, 0);
    }
  }

  const art = paint(w, h, tiles, rng);
  const mask = document.createElement('canvas');
  paintMask(mask, w, h, tiles);
  return {
    w,
    h,
    tiles,
    start,
    exit,
    braziers,
    embers,
    shades,
    moths,
    octos,
    water,
    glints: art.glints,
    book,
    canvas: art.canvas,
    mask,
  };
}

// ---------------------------------------------------------------------------
// Tile painting
// ---------------------------------------------------------------------------

const C = {
  floor: '#2a3048',
  floorLo: '#232840',
  floorHi: '#333a56',
  slab: '#303654',
  slabHi: '#3b4365',
  moss: '#2f6b55',
  mossHi: '#47936b',
  roof: '#15122b',
  roofSpeck: '#1e1a3c',
  roofEdge: '#4a4284',
  roofRim: '#272250',
  face: '#4a4279',
  faceHi: '#574e8c',
  lip: '#7067ad',
  mortar: '#2f2a55',
  water: '#1d3f66',
  waterHi: '#2e6396',
  waterEdge: '#17304f',
  cyan: '#6fe3d2',
  teal: '#2f8f9a',
  bone: '#9a9fb8',
  cream: '#fff1c2',
};

function paint(
  w: number,
  h: number,
  tiles: Uint8Array,
  rng: () => number,
): { canvas: HTMLCanvasElement; glints: Pt[] } {
  const glints: Pt[] = [];
  const canvas = document.createElement('canvas');
  canvas.width = w * TILE;
  canvas.height = h * TILE;
  const g = canvas.getContext('2d') as CanvasRenderingContext2D;
  const ri = (n: number) => (rng() * n) | 0;
  const at = (x: number, y: number) => (x < 0 || y < 0 || x >= w || y >= h ? T_WALL : tiles[y * w + x]);
  const wall = (x: number, y: number) => at(x, y) === T_WALL;
  const px = (c: string, x: number, y: number, ww = 1, hh = 1) => {
    g.fillStyle = c;
    g.fillRect(x, y, ww, hh);
  };

  for (let ty = 0; ty < h; ty++) {
    for (let tx = 0; tx < w; tx++) {
      const x = tx * TILE;
      const y = ty * TILE;
      const t = at(tx, ty);

      if (t === T_WALL) {
        px(C.roof, x, y, TILE, TILE);
        for (let i = 0; i < 5; i++) px(C.roofSpeck, x + ri(15), y + ri(16), 1 + ri(2), 1);
        if (rng() < 0.35) {
          // a crack in the rock
          const kx = x + 3 + ri(8);
          const ky = y + 3 + ri(8);
          px(C.roofSpeck, kx, ky, 3, 1);
          px(C.roofSpeck, kx + 2, ky + 1, 2, 1);
        }
        const face = !wall(tx, ty + 1);
        // rims wherever the rock meets open floor, so cave edges read clearly
        if (!wall(tx, ty - 1)) {
          px(C.roofRim, x, y, TILE, 3);
          px(C.roofEdge, x, y, TILE, 1);
        }
        if (!wall(tx - 1, ty)) {
          px(C.roofRim, x, y, 2, TILE);
          px(C.roofEdge, x, y, 1, TILE);
        }
        if (!wall(tx + 1, ty)) {
          px(C.roofRim, x + 14, y, 2, TILE);
          px(C.roofEdge, x + 15, y, 1, TILE);
        }
        if (face) {
          px(C.face, x, y + 6, TILE, 10);
          // a few lighter bricks
          if (rng() < 0.6) px(C.faceHi, x + (rng() < 0.5 ? 0 : 8), y + 7, 7, 4);
          if (rng() < 0.6) px(C.faceHi, x + 4, y + 12, 8, 3);
          px(C.lip, x, y + 6, TILE, 1);
          px(C.roofEdge, x, y + 5, TILE, 1);
          px(C.mortar, x, y + 11, TILE, 1);
          px(C.mortar, x, y + 15, TILE, 1);
          px(C.mortar, x + 7, y + 7, 1, 4);
          px(C.mortar, x + 15, y + 7, 1, 4);
          px(C.mortar, x + 3, y + 12, 1, 3);
          px(C.mortar, x + 12, y + 12, 1, 3);
          if (!wall(tx - 1, ty)) px(C.mortar, x, y + 6, 1, 10);
          if (!wall(tx + 1, ty)) px(C.mortar, x + 15, y + 6, 1, 10);
          if (rng() < 0.3) {
            // moss hanging over the lip
            const mx = x + 1 + ri(11);
            px(C.moss, mx, y + 5, 4, 2);
            px(C.mossHi, mx + 1, y + 5, 2, 1);
            px(C.moss, mx + ri(3), y + 7, 1, 1 + ri(3));
          }
          if (rng() < 0.07) {
            // crystal growing from the wall
            const cx = x + 3 + ri(9);
            px(C.teal, cx, y + 9, 3, 4);
            px(C.cyan, cx + 1, y + 8, 1, 4);
            px(C.cream, cx + 1, y + 9, 1, 1);
            glints.push({ x: cx + 1, y: y + 9 });
          }
        }
        continue;
      }

      if (t === T_WATER) {
        px(C.water, x, y, TILE, TILE);
        for (let i = 0; i < 3; i++) px(C.waterHi, x + 1 + ri(11), y + 2 + ri(12), 2 + ri(2), 1);
        if (at(tx, ty - 1) !== T_WATER) px(C.waterEdge, x, y, TILE, RIM_N);
        if (at(tx, ty + 1) !== T_WATER) px(C.waterHi, x, y + TILE - RIM_S, TILE, RIM_S);
        if (at(tx - 1, ty) !== T_WATER) px(C.waterEdge, x, y, RIM_W, TILE);
        if (at(tx + 1, ty) !== T_WATER) px(C.waterEdge, x + TILE - RIM_E, y, RIM_E, TILE);
        continue;
      }

      // floor
      px(C.floor, x, y, TILE, TILE);
      for (let i = 0; i < 6; i++) px(C.floorHi, x + ri(16), y + ri(16));
      for (let i = 0; i < 6; i++) px(C.floorLo, x + ri(16), y + ri(16));
      if (rng() < 0.4) {
        const sx = x + 1 + ri(8);
        const sy = y + 3 + ri(8);
        const sw = 4 + ri(3);
        const sh = 3 + ri(2);
        px(C.slab, sx, sy, sw, sh);
        px(C.slabHi, sx, sy, sw - 1, 1);
        px(C.floorLo, sx + 1, sy + sh, sw, 1);
      }
      if (rng() < 0.12) {
        const cx = x + 2 + ri(11);
        const cy = y + 4 + ri(9);
        px(C.floorLo, cx, cy, 2, 1);
        px(C.floorLo, cx + 2, cy + 1, 2, 1);
      }
      const nearWall = wall(tx - 1, ty) || wall(tx + 1, ty) || wall(tx, ty + 1) || wall(tx, ty - 1);
      if (nearWall && rng() < 0.45) {
        const n = 2 + ri(3);
        for (let i = 0; i < n; i++) {
          let mx = x + ri(14);
          let my = y + 5 + ri(9);
          if (wall(tx - 1, ty) && rng() < 0.6) mx = x + ri(3);
          else if (wall(tx + 1, ty) && rng() < 0.6) mx = x + 12 + ri(3);
          else if (wall(tx, ty + 1)) my = y + 12 + ri(3);
          px(C.moss, mx, my, 2, 1);
          px(C.mossHi, mx, my - 1, 1, 1);
        }
      }
      const deco = rng();
      if (deco < 0.035) {
        // glowcap mushroom
        const mx = x + 3 + ri(9);
        const my = y + 6 + ri(6);
        px(C.teal, mx, my + 1, 3, 1);
        px(C.cyan, mx + 1, my, 1, 1);
        px(C.cyan, mx, my + 1, 1, 1);
        px(C.cream, mx + 1, my + 2, 1, 2);
        glints.push({ x: mx + 1, y: my });
      } else if (deco < 0.07) {
        // grass tuft
        const mx = x + 3 + ri(9);
        const my = y + 7 + ri(6);
        px(C.moss, mx, my, 1, 3);
        px(C.mossHi, mx + 1, my - 1, 1, 4);
        px(C.moss, mx + 2, my + 1, 1, 2);
      } else if (deco < 0.085) {
        // old bones
        const mx = x + 3 + ri(8);
        const my = y + 7 + ri(5);
        px(C.bone, mx, my, 4, 1);
        px(C.bone, mx - 1, my - 1, 1, 1);
        px(C.bone, mx + 4, my + 1, 1, 1);
      }
      if (wall(tx, ty - 1)) {
        px('rgba(7,6,22,0.5)', x, y, TILE, 3);
        px('rgba(7,6,22,0.25)', x, y + 3, TILE, 2);
      }
    }
  }
  return { canvas, glints };
}

/**
 * Admin tool: turns the 3x3 block round a tile into water. Every water tile in reach is then
 * repainted, so banks appear and vanish wherever the shoreline changed, and the stencil is
 * rebuilt to match.
 */
export function carveWaterPuddle(level: Level, cx: number, cy: number): Pt | null {
  let carved: Pt | null = null;
  for (let dy = -1; dy <= 1; dy++) {
    for (let dx = -1; dx <= 1; dx++) {
      const tx = cx + dx;
      const ty = cy + dy;
      if (tx <= 1 || ty <= 1 || tx >= level.w - 2 || ty >= level.h - 2) continue;
      const idx = ty * level.w + tx;
      if (level.tiles[idx] === T_WALL) continue;
      // never drown the guide book
      if (level.book && level.book.x === tx && level.book.y === ty) continue;
      if (level.tiles[idx] !== T_WATER) {
        level.tiles[idx] = T_WATER;
        level.water.push({ x: tx, y: ty });
      }
      if (!carved || (dx === 0 && dy === 0)) carved = { x: tx, y: ty };
    }
  }
  if (!carved) return null;
  const g = level.canvas.getContext('2d') as CanvasRenderingContext2D;
  const wet = (x: number, y: number) => isWater(level.w, level.h, level.tiles, x, y);
  for (let ty = cy - 2; ty <= cy + 2; ty++) {
    for (let tx = cx - 2; tx <= cx + 2; tx++) {
      if (!wet(tx, ty)) continue;
      const x = tx * TILE;
      const y = ty * TILE;
      g.fillStyle = C.water;
      g.fillRect(x, y, TILE, TILE);
      g.fillStyle = C.waterHi;
      g.fillRect(x + 3 + ((tx * 5) % 6), y + 5, 3, 1);
      g.fillRect(x + 9, y + 8 + ((ty * 3) % 4), 2, 1);
      g.fillRect(x + 4 + ((tx + ty) % 5), y + 12, 3, 1);
      if (!wet(tx, ty - 1)) {
        g.fillStyle = C.waterEdge;
        g.fillRect(x, y, TILE, RIM_N);
      }
      if (!wet(tx, ty + 1)) {
        g.fillStyle = C.waterHi;
        g.fillRect(x, y + TILE - RIM_S, TILE, RIM_S);
      }
      if (!wet(tx - 1, ty)) {
        g.fillStyle = C.waterEdge;
        g.fillRect(x, y, RIM_W, TILE);
      }
      if (!wet(tx + 1, ty)) {
        g.fillStyle = C.waterEdge;
        g.fillRect(x + TILE - RIM_E, y, RIM_E, TILE);
      }
    }
  }
  paintMask(level.mask, level.w, level.h, level.tiles);
  return carved;
}
