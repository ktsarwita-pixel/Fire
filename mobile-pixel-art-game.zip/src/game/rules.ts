// The numbers that decide how the emberling and each creature behave. The game reads them
// from here and so does the guide book, which is how the book stays true to the game.

// ---------------------------------------------------------------- emberling
/** Pixels a second on dry ground. */
export const PLAYER_SPEED = 66;
export const WATER_SPEED = 46;
/** How many times faster the flame burns down while wading. */
export const WATER_BURN = 3.5;
export const FLARE_COST = 14;
export const FLARE_R = 62;
export const DASH_COST = 3;
export const BRAZIER_R = 66;
/** Flame lost each second just by burning. */
export const flameBurn = (depth: number): number => Math.min(2.4, 1.45 + depth * 0.08);

// -------------------------------------------------------------------- shade
export const SHADE_BITE = 16;
/** Its speed once the emberling's light is on it. */
export const SHADE_SPEED_LIT = 9;
/** The ember a burnt shade leaves behind. */
export const SHADE_EMBER = 10;
export const shadeSpeed = (depth: number): number => Math.min(50, 36 + depth * 1.6);
export const shadeCount = (depth: number): number => Math.min(16, 3 + depth * 2);

// --------------------------------------------------------------------- moth
export const MOTH_DEPTH = 3;
export const MOTH_STEAL = 7;
/** Seconds it flees after stealing. */
export const MOTH_FLEE_T = 2.5;
export const mothCount = (depth: number): number => (depth >= MOTH_DEPTH ? Math.min(8, depth - 1) : 0);

// ------------------------------------------------------------ water octopus
export const OCTO_DEPTH_MIN = 6;
export const OCTO_DEPTH_MAX = 10;
export const OCTO_MAX = 5;
/** Seconds it holds the emberling. */
export const OCTO_HOLD_T = 4;
/** Flame it squeezes out each second of the hold. */
export const OCTO_DRAIN = 10;
/** How often a cave with octopuses crowds three of them into one pool. */
export const OCTO_PACK_CHANCE = 0.15;
export const octoCount = (depth: number): number =>
  depth >= OCTO_DEPTH_MIN && depth <= OCTO_DEPTH_MAX ? Math.min(OCTO_MAX, depth - 3) : 0;

// --------------------------------------------------------------- guide book
/** The one depth where the guide book stands. */
export const BOOK_DEPTH = 5;
